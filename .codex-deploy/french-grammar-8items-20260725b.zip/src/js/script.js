// L1/bridge/interface language and L2/target language helpers
// (getInterfaceLabel/getSupportText/getTargetContent/getLanguagePairLabel) -
// see src/js/language-pair.js for the full definitions. bridgeLanguage IS
// the interface language in this architecture (one field, not two) - it is
// the language the platform's navigation, instructions, explanations, help
// and system messages appear in, not merely "a language the student already
// knows". Persisted server-side as profiles.bridge_language, paired with
// preferred_language/learningPathState.language (the target language being
// learned).
//
// Both live on learningPathState (learningPathState.bridgeLanguage /
// .language) - there used to be separate currentBridgeLanguage/
// currentTargetLanguage globals that had to be kept in sync by hand on every
// write; that duplication caused a real bug (the home cards/#languages tabs
// once updated only the target mirror, never learningPathState.language, so
// the two disagreed - see normalizeLanguageKey's comment below) and has been
// removed. learningPathState is the single source of truth for both.
const LanguagePair = window.AndergoLanguagePair;

// Whether the student has manually changed the Traductor's OWN source/target
// selects this session - once true, syncTranslatorLanguagesFromState() stops
// overwriting them on every visit to #translator, since the Traductor is
// intentionally able to translate a different pair than the one being
// studied (see setupTranslator()). Reset to false whenever the platform's
// own bridge/target pair changes, so the next visit to Traductor re-syncs to
// the new pair instead of staying stuck on a stale manual choice.
let translatorUserAdjustedPair = false;
// { hash, label } set by openTranslator() when it's opened from a lesson
// shortcut - drives #translatorReturnLink ("‹ Volver a la lección").
let translatorReturnContext = null;

// Fallback values only, used for the very first paint before GET /api/plans
// resolves below - lib/plansConfig.js on the server is the single source of
// truth for these numbers; nothing in this file should hardcode a price
// anywhere else. Kept as strings (already formatted, e.g. '4.99') since
// every call site below just interpolates them into "USD ${...}" text.
let premiumMonthlyPriceUsd = '4.99';
let premiumYearlyPriceUsd = '39.99';
// Back-compat alias for the few call sites below that only ever showed the
// monthly figure - avoids touching every interpolation site individually.
let premiumPriceUsd = premiumMonthlyPriceUsd;

// Re-applies the fetched prices to any already-painted markup that shows
// them as static text (the #premium pricing section) - everything else
// below reads the `premium*PriceUsd` variables directly at render time, so
// only DOM already in the page before loadPlans() resolves needs patching.
function refreshPremiumPricingUI() {
  document.querySelectorAll('[data-premium-monthly-price]').forEach((el) => {
    el.textContent = `USD ${premiumMonthlyPriceUsd}`;
  });
  document.querySelectorAll('[data-premium-yearly-price]').forEach((el) => {
    el.textContent = `USD ${premiumYearlyPriceUsd}`;
  });
}

async function loadPlans() {
  try {
    const res = await fetch('/api/plans');
    if (!res.ok) return;
    const { plans } = await res.json();
    const premium = plans?.find((plan) => plan.slug === 'premium');
    if (!premium) return;
    premiumMonthlyPriceUsd = Number(premium.monthlyPriceUsd).toFixed(2);
    premiumYearlyPriceUsd = Number(premium.yearlyPriceUsd).toFixed(2);
    premiumPriceUsd = premiumMonthlyPriceUsd;
    refreshPremiumPricingUI();
  } catch {
    // Keep the fallback values above - pricing display must never block
    // or break the rest of the page on a network hiccup.
  }
}
loadPlans();

const targetLanguageMap = {
  english: 'english',
  espanol: 'spanish',
  frances: 'french',
  italiano: 'italian',
  deutsch: 'german',
  'ai-tutor': 'ai'
};

const authModal = document.getElementById('authModal');
const authTabs = document.querySelectorAll('.auth-tab');
const authForms = document.querySelectorAll('.auth-form');
document.querySelectorAll('.auth-form .auth-note').forEach((note) => {
  note.dataset.defaultText = note.textContent;
});
const authTriggers = document.querySelectorAll('[data-action="open-auth"]');
const closeModal = document.querySelector('.close-modal');
const menuToggle = document.querySelector('.menu-toggle');
const siteMenu = document.getElementById('siteMenu');
const userChip = document.querySelector('.user-chip');
const logoutButton = document.querySelector('.logout-btn');
const footerYearEl = document.getElementById('footerYear');
if (footerYearEl) footerYearEl.textContent = String(new Date().getFullYear());
const backendBaseUrl =
  typeof window !== 'undefined' && window.location.protocol === 'file:'
    ? 'http://127.0.0.1:3000'
    : '';
const authStatus = {
  user: null,
  session: null,
  // Populated only from GET /api/dashboard's `entitlements` field (see
  // lib/entitlementsService.js) - never set from username/email/localStorage,
  // so the CEO/Premium badge below can only ever reflect what the server
  // just verified, not a client-side guess.
  entitlements: null
};

// Holds the aal1 session while a second factor is pending, in memory only -
// never written to localStorage/authStatus, since it isn't a valid signed-in
// session yet (see the login handler and the mfaChallengeForm submit below).
let pendingMfa = null;

function clearPendingMfa() {
  pendingMfa = null;
}

const goalOptions = {
  daily: {
    label: 'Practicar 15 min al día',
    helper: 'Meta de constancia para estudiar todos los días.',
    progressBoost: 0
  },
  conversation: {
    label: 'Completar 3 conversaciones',
    helper: 'Meta de fluidez para practicar speaking y listening.',
    progressBoost: 8
  },
  exam: {
    label: 'Preparar una evaluación',
    helper: 'Meta intensiva para reforzar lectura, gramática y escritura.',
    progressBoost: 14
  }
};

let currentProgress = 0;

function gamificationKeyFor(user) {
  return user?.id || user?.email || 'guest';
}

function saveSession(user, session) {
  authStatus.user = user || null;
  authStatus.session = session || null;
  renderAuthState();
  loadDashboard();
  window.AndergoGamification?.load(gamificationKeyFor(authStatus.user));
  if (!session?.access_token) return;
  localStorage.setItem('andergoSession', JSON.stringify({ user, session }));
}

// Runs once at page load (the closest equivalent this app's own
// REST-backed session model has to supabase-js's INITIAL_SESSION event -
// see saveSession()/logout() above and below for the SIGNED_IN/SIGNED_OUT
// equivalents). A valid restored session must never show the Auth modal or
// leave one open - closeAllAuthUI() is a no-op here in every current flow
// (authModal starts closed on a fresh load) but stays defensive on purpose,
// so this keeps holding even if some future deep link opens it before this
// runs.
function restoreSession() {
  try {
    const stored = JSON.parse(localStorage.getItem('andergoSession') || 'null');
    if (stored?.session?.access_token) {
      authStatus.user = stored.user || null;
      authStatus.session = stored.session;
      closeAllAuthUI();
    }
  } catch {
    localStorage.removeItem('andergoSession');
  }
  renderAuthState();
  loadDashboard();
  window.AndergoGamification?.load(gamificationKeyFor(authStatus.user));
}

// Supabase access tokens expire (~1h) but the app never refreshed them, so
// any long-lived tab started silently 401ing on every requireAuth route
// ("Debes iniciar sesión para continuar.") while the UI still showed the
// user as signed in - saveSession()/restoreSession() only ever stored
// session.refresh_token, nothing ever spent it. Called from authFetch()
// below on a 401; a quiet background swap, not a full saveSession() (no
// loadDashboard()/gamification reload needed just to renew a token).
async function refreshAuthSession() {
  const refreshToken = authStatus.session?.refresh_token;
  if (!refreshToken) return false;
  try {
    const response = await fetch(`${backendBaseUrl}/api/auth/refresh`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ refreshToken })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok || !data.session?.access_token) return false;

    authStatus.user = data.user || authStatus.user;
    authStatus.session = data.session;
    localStorage.setItem(
      'andergoSession',
      JSON.stringify({ user: authStatus.user, session: authStatus.session })
    );
    return true;
  } catch {
    return false;
  }
}

// fetch() wrapper for requireAuth-gated routes: attaches the current
// access token, and on a 401 tries refreshAuthSession() once, retrying the
// original request with the renewed token before giving up. Everything
// else about the response (ok/not-ok, body shape) is left for the caller
// to handle exactly as if this were a plain fetch.
async function authFetch(url, options = {}) {
  const withAuth = (opts) => ({
    ...opts,
    headers: { ...(opts.headers || {}), ...authHeaders() }
  });

  let response = await fetch(url, withAuth(options));
  if (response.status === 401 && authStatus.session?.refresh_token) {
    const refreshed = await refreshAuthSession();
    if (refreshed) response = await fetch(url, withAuth(options));
  }
  return response;
}

// The backend's user.name is upstream data we don't control here - if it's
// malformed (e.g. truncated to something like "aos") this guard keeps it off
// screen instead of rendering "Hola, aos": falls back to the email's local
// part, and to an empty string (bare "Hola", no dangling comma) if that's
// missing too.
function getDisplayName() {
  const rawName = authStatus.user?.name;
  const looksLikeName =
    typeof rawName === 'string' && /^[\p{L}][\p{L}\s'-]{1,49}$/u.test(rawName.trim());
  if (looksLikeName) return rawName.trim();
  return authStatus.user?.email?.split('@')[0] || '';
}

function renderAuthState() {
  const isSignedIn = Boolean(authStatus.session?.access_token);
  const name = getDisplayName();

  if (userChip) {
    userChip.hidden = !isSignedIn;
    const greeting = name ? `Hola, ${name}` : 'Hola';
    // entitlements.role comes straight from GET /api/dashboard, computed
    // server-side by getUserEntitlements() - this only ever renders what the
    // backend already decided, it never decides authorization itself.
    const roleBadge =
      isSignedIn && authStatus.entitlements?.role === 'ceo' ? ' · CEO · Premium' : '';
    userChip.textContent = isSignedIn ? `${greeting}${roleBadge}` : '';
  }

  if (logoutButton) logoutButton.hidden = !isSignedIn;

  authTriggers.forEach((trigger) => {
    trigger.hidden = isSignedIn;
  });

  document.querySelectorAll('.nav-group-visitor').forEach((group) => {
    group.hidden = isSignedIn;
  });
  document.querySelectorAll('.nav-group-member').forEach((group) => {
    group.hidden = !isSignedIn;
  });

  const greeting = document.querySelector('.student-greeting');
  if (greeting) {
    greeting.textContent = isSignedIn
      ? name
        ? `${name}, esta es tu ruta personalizada.`
        : 'Esta es tu ruta personalizada.'
      : 'Inicia sesión para ver tu progreso, racha y objetivo.';
  }
  renderCurrentPlanSummary();
}

function renderCurrentPlanSummary() {
  const premium = isPremiumUser();
  const name = document.querySelector('[data-current-plan-name]');
  const price = document.querySelector('[data-current-plan-price]');
  if (name) name.textContent = premium ? 'Premium' : 'Free';
  if (price) price.textContent = premium ? `USD ${premiumPriceUsd}/mes` : 'USD 0/mes';
}

function setPricingExpanded(expanded) {
  const details = document.querySelector('.pricing-details');
  const section = document.getElementById('premium');
  const toggle = document.querySelector('.current-plan-toggle');
  if (section) section.hidden = !expanded;
  if (details) details.hidden = !expanded;
  if (toggle) {
    toggle.setAttribute('aria-expanded', String(expanded));
    toggle.textContent = expanded ? 'Ocultar planes' : 'Ver planes';
  }
}

// Single source of truth for the bridge (already-known) language - keeps
// the learning-path #pathBridgeSelect in sync and persists the change.
// bridgeName === target is allowed (spec §3: direct/immersion learning mode,
// L1 === L2) - only an actually-unsupported pair (see
// LanguagePair.isLanguagePairSupported) is rejected. Rejects and reverts the
// visible select if the pair is invalid, instead of silently accepting an
// impossible combination.
function setBridgeLanguage(bridgeName, options = {}) {
  const target = learningPathState.language;
  if (LanguagePair && !LanguagePair.isLanguagePairSupported(bridgeName, target)) {
    showHomeToast('Esta combinación estará disponible próximamente.');
    const staleBridgeSelect = document.getElementById('pathBridgeSelect');
    if (staleBridgeSelect) staleBridgeSelect.value = learningPathState.bridgeLanguage;
    return false;
  }

  learningPathState.bridgeLanguage = bridgeName;
  syncLearningMode();
  translatorUserAdjustedPair = false;
  const bridgeSelect = document.getElementById('pathBridgeSelect');
  if (bridgeSelect) bridgeSelect.value = bridgeName;
  applyInterfaceLanguage(bridgeName);
  updatePathPairPreview();
  if (options.persist !== false) {
    savePreferences(learningPathState.language, learningPathState.level, bridgeName);
  }
  return true;
}

// Refreshes every static interface-chrome label tied to the bridge/target
// pair (selector labels, pill label prefixes, the AI tutor's "Idioma" pill)
// to the current bridgeLanguage - see src/js/language-pair.js's
// getInterfaceLabel and the data-field="...Label" spans added alongside
// each one in index.html. Safe to call as often as needed and from any
// screen; a querySelectorAll pass only ever touches elements that exist on
// the current page, so no caller needs to know which ones are present.
function refreshLanguagePairChrome() {
  if (!LanguagePair) return;
  const interfaceLanguage = getEffectiveInterfaceLanguage();
  [
    'bridgeSelectLabel',
    'targetSelectLabel',
    'levelSelectLabel',
    'bridgeLabel',
    'targetLabel',
    'levelLabel',
    'aiLanguageLabel'
  ].forEach((key) => {
    document.querySelectorAll(`[data-field="${key}"]`).forEach((el) => {
      el.textContent = LanguagePair.getInterfaceLabel(key, interfaceLanguage);
    });
  });
}

// L1/bridgeLanguage -> <html lang="..."> code, for accessibility/SEO only
// (screen readers, browser translate prompts). Falls back to Spanish, same
// rule as every other lookup in this file's language-pair layer.
const bridgeLanguageToHtmlLang = { spanish: 'es', english: 'en', french: 'fr', italian: 'it', german: 'de' };

function isAdvancedImmersionLevel(level = learningPathState.level) {
  return level === 'B2' || level === 'C1' || level === 'C2';
}

function isFrenchAdvancedImmersion() {
  return learningPathState.language === 'french' && isAdvancedImmersionLevel();
}

function isFrenchTargetLanguage() {
  return learningPathState.language === 'french';
}

function advancedFrenchText(defaultText, frenchText) {
  return isFrenchAdvancedImmersion() ? frenchText : defaultText;
}

function getEffectiveInterfaceLanguage() {
  return isAdvancedImmersionLevel()
    ? learningPathState.language
    : learningPathState.bridgeLanguage;
}

// Applies the platform-wide interface language (spec §2: L1 controls
// navigation, buttons, instructions, system messages, dashboard, auth,
// Premium, tutor, translator, footer, About - everything except the L2
// learning content itself). Patches every element carrying a data-i18n*
// attribute in place via LanguagePair.t() (src/js/language-pair.js) rather
// than re-rendering, so it's safe to call on every bridgeLanguage change
// without disturbing focus, scroll position or in-progress input. Also
// refreshes the narrower language-pair-selector chrome (refreshLanguagePairChrome)
// and <html lang> so the two interface-language mechanisms never disagree.
function applyInterfaceLanguage(bridgeLanguage) {
  if (!LanguagePair) return;
  const interfaceLanguage = getEffectiveInterfaceLanguage() || bridgeLanguage;
  document.documentElement.lang = bridgeLanguageToHtmlLang[interfaceLanguage] || 'es';
  document.querySelectorAll('[data-i18n]').forEach((el) => {
    el.textContent = LanguagePair.t(el.dataset.i18n, interfaceLanguage);
  });
  document.querySelectorAll('[data-i18n-aria-label]').forEach((el) => {
    el.setAttribute('aria-label', LanguagePair.t(el.dataset.i18nAriaLabel, interfaceLanguage));
  });
  document.querySelectorAll('[data-i18n-placeholder]').forEach((el) => {
    el.setAttribute('placeholder', LanguagePair.t(el.dataset.i18nPlaceholder, interfaceLanguage));
  });
  refreshLanguagePairChrome();
}

// A1-A2-B1 keep bilingual support. B2-C1-C2 use L2 immersion throughout the
// interface; Vocabulary remains bilingual because its cards derive their
// translations from the distinct L1/L2 pair rather than this UI mode.
function syncLearningMode() {
  learningPathState.learningMode = isAdvancedImmersionLevel() ? 'direct' : 'bilingual';
}

function syncLanguagePairSelectOptions() {
  const targetSelect = document.getElementById('pathLanguageSelect');
  const bridgeSelect = document.getElementById('pathBridgeSelect');
  if (!targetSelect || !bridgeSelect) return;

  Array.from(targetSelect.options).forEach((option) => {
    option.disabled = option.value === learningPathState.bridgeLanguage;
  });
  Array.from(bridgeSelect.options).forEach((option) => {
    option.disabled = option.value === learningPathState.language;
  });
}

function updatePathPairPreview() {
  syncLanguagePairSelectOptions();
  refreshLanguagePairChrome();
  updateStartLearningButton();
  const preview = document.getElementById('pathPairPreview');
  if (preview) {
    preview.textContent = LanguagePair
      ? LanguagePair.getLanguagePairLabel(
          learningPathState.bridgeLanguage,
          learningPathState.language,
          getEffectiveInterfaceLanguage()
        )
      : `Aprenderás ${languageDisplayNames[learningPathState.language] || learningPathState.language} con apoyo en ${languageDisplayNames[learningPathState.bridgeLanguage] || learningPathState.bridgeLanguage}.`;
  }

}

// Accepts either a real language key (english/spanish/french/italian/german,
// as used by #pathLanguageSelect) or the older tab-id spelling used by the
// home language cards (frances/espanol/italiano/deutsch) and normalizes both
// to the same key, so every caller feeds the same canonical value into
// learningPathState.language - the single field updatePathPairPreview reads.
// This is the fix for the "Aprenderás English..." bug: previously the home
// cards and #languages tabs only ever updated the separate
// currentTargetLanguage variable, never learningPathState.language.
function normalizeLanguageKey(lang) {
  if (lang && languageDisplayNames[lang] && lang !== 'ai') return lang;
  return targetLanguageMap[lang] || lang;
}

function setTargetLanguage(lang, options = {}) {
  const resolved = normalizeLanguageKey(lang);
  if (!resolved || !languageDisplayNames[resolved] || resolved === 'ai') return false;

  if (LanguagePair && !LanguagePair.isLanguagePairSupported(learningPathState.bridgeLanguage, resolved)) {
    showHomeToast('Esta combinación estará disponible próximamente.');
    return false;
  }

  // recognition.lang is fixed for the life of a SpeechRecognition instance -
  // a language switch mid-dictation would otherwise keep listening in the
  // old language.
  stopTutorDictation();

  learningPathState.language = resolved;
  syncLearningMode();
  translatorUserAdjustedPair = false;

  const pathLanguageSelect = document.getElementById('pathLanguageSelect');
  if (pathLanguageSelect) pathLanguageSelect.value = resolved;
  updateLanguagePreviewSelection();

  const level = options.level || learningPathState.level;
  loadLearningPath({ language: resolved, level });
  updatePathPairPreview();
  updateAiTutorContext();
  updateLevelTabLabels();
  if (options.persist !== false) savePreferences(resolved, level, learningPathState.bridgeLanguage);
  return true;
}

// Swaps bridge<->target (Español -> Inglés becomes Inglés -> Español) for the
// prominent pair selector's ⇄ button. Deliberately not just two calls to
// setBridgeLanguage()/setTargetLanguage() in sequence - each of those checks
// its new value against the OTHER field's CURRENT value, so calling them
// back-to-back mid-swap would see the not-yet-updated other side and reject
// a perfectly valid swapped pair (new bridge === still-old target). Updates
// both fields together, then runs the same side effects setTargetLanguage
// does (select sync, reload lessons, persist, refresh chrome).
function swapLearningPathLanguages() {
  if (!LanguagePair) return false;
  const swapped = LanguagePair.swapLanguagePair(
    learningPathState.bridgeLanguage,
    learningPathState.language
  );
  if (!swapped) {
    showHomeToast('Esta combinación estará disponible próximamente.');
    return false;
  }

  stopTutorDictation();
  learningPathState.bridgeLanguage = swapped.bridge;
  learningPathState.language = swapped.target;
  syncLearningMode();
  translatorUserAdjustedPair = false;

  const bridgeSelect = document.getElementById('pathBridgeSelect');
  if (bridgeSelect) bridgeSelect.value = swapped.bridge;
  const pathLanguageSelect = document.getElementById('pathLanguageSelect');
  if (pathLanguageSelect) pathLanguageSelect.value = swapped.target;
  applyInterfaceLanguage(swapped.bridge);

  loadLearningPath({ language: swapped.target, level: learningPathState.level });
  updatePathPairPreview();
  updateAiTutorContext();
  updateLevelTabLabels();
  savePreferences(swapped.target, learningPathState.level, swapped.bridge);
  return true;
}

// Only the Spanish translation is real, authored data (lib/seed-lessons.json
// vocabulary is translated into Spanish only, regardless of target
// language - confirmed, there is no per-bridge-language dictionary yet).
// For any other bridge language, label the Spanish text as a reference
// instead of presenting it as a translation into the student's actual
// bridge language - never fabricate a translation that isn't real data.
function resolveVocabTranslation(item, bridgeLanguage = learningPathState.bridgeLanguage) {
  if (!item?.translation) return item?.translation || '';
  if (bridgeLanguage === 'spanish') return item.translation;
  return `${item.translation} (referencia en español)`;
}

function renderMcqItem(question, index, languageKey) {
  // Backward compatible: older content used plain strings with no options.
  if (typeof question === 'string') {
    return `<li><strong>${index + 1}.</strong> ${escapeHtml(question)}</li>`;
  }

  const options = question.options || [];
  const optionsHtml = options
    .map(
      (option, optionIndex) => `
    <button type="button" class="mcq-option" data-option-index="${optionIndex}">${escapeHtml(option)}</button>
  `
    )
    .join('');

  return `
    <li class="mcq-question" data-language="${escapeHtml(languageKey || '')}">
      <strong>${index + 1}.</strong> ${escapeHtml(question.q || '')}
      <div class="mcq-options">${optionsHtml}</div>
      <span class="mcq-feedback" aria-live="polite"></span>
    </li>
  `;
}

function getLanguageTabFromHash() {
  const hash = window.location.hash.replace('#', '');
  if (!hash) return null;

  const normalized = hash.startsWith('language-') ? hash.replace('language-', '') : hash;
  return targetLanguageMap[normalized] ? normalized : null;
}

let authModalReturnFocus = null;

function openModal(panel) {
  authModalReturnFocus = document.activeElement;
  authModal.classList.add('open');
  authModal.setAttribute('aria-hidden', 'false');
  authModal.removeAttribute('inert');
  document.body.classList.add('modal-open');
  authTabs.forEach((tab) => {
    const active = tab.dataset.form === panel;
    tab.classList.toggle('active', active);
  });
  authForms.forEach((form) => {
    form.classList.toggle('active', form.id === `${panel}Form`);
  });
  // "forgotPassword" and "mfaChallenge" aren't real tabs (reached via a link
  // or automatically after login, not .auth-tabs) - hide the tab row
  // entirely while either is open instead of showing both tabs as unselected.
  document
    .querySelector('.auth-tabs')
    ?.classList.toggle('is-hidden', panel === 'forgotPassword' || panel === 'mfaChallenge');
  clearAuthMessages();
  resetSignupPending();
  authModal.querySelector('.auth-form.active input')?.focus();
}

// Single shared close for every Auth-entry panel - login, signup (including
// its OTP verification step), forgotPassword and mfaChallenge all live as
// tabs/steps inside this one #authModal dialog, so hiding it once closes all
// of them at once. Called both for a manual close (X button/Escape/backdrop,
// via the closeAuth() alias below) and right after a successful
// login/MFA/confirmation-then-login or a valid restored session (see
// afterAuthSuccess and restoreSession) so the modal can never linger visible
// over an already-signed-in UI.
function closeAllAuthUI() {
  authModal.classList.remove('open');
  authModal.setAttribute('aria-hidden', 'true');
  authModal.setAttribute('inert', '');
  // Only ever removed here, never set unconditionally: logoutConfirmModal/
  // paywallModal/usernameOnboardingModal toggle this same body class for
  // their own open state, but none of them can be open at the same time as
  // authModal in this app's actual flows (see the modals' own open*() -
  // each is only ever triggered from a state where authModal is already
  // closed), so this never fights another modal's lock.
  document.body.classList.remove('modal-open');
  (authModalReturnFocus || document.querySelector('[data-action="open-auth"]'))?.focus();
  authModalReturnFocus = null;
  clearPendingMfa();
  clearAuthMessages();
  // Never leave a password/OTP value sitting in the DOM once the panel that
  // collected it is hidden - a later reopen (or a screen reader landing on
  // stale text) must never show a previous attempt's sensitive input.
  ['loginPassword', 'signupPassword', 'signupConfirmPassword', 'mfaChallengeCode'].forEach((id) => {
    const el = document.getElementById(id);
    if (el) el.value = '';
  });
  document.querySelectorAll('#otpInputRow .otp-digit').forEach((input) => {
    input.value = '';
  });
}

function closeAuth() {
  closeAllAuthUI();
}

const logoutConfirmModal = document.getElementById('logoutConfirmModal');
let logoutConfirmReturnFocus = null;

function openLogoutConfirm() {
  if (!logoutConfirmModal) return;
  logoutConfirmReturnFocus = document.activeElement;
  logoutConfirmModal.classList.add('open');
  logoutConfirmModal.setAttribute('aria-hidden', 'false');
  logoutConfirmModal.removeAttribute('inert');
  document.body.classList.add('modal-open');
  logoutConfirmModal.querySelector('[data-action="cancel-logout"]')?.focus();
}

function closeLogoutConfirm() {
  if (!logoutConfirmModal) return;
  logoutConfirmModal.classList.remove('open');
  logoutConfirmModal.setAttribute('aria-hidden', 'true');
  logoutConfirmModal.setAttribute('inert', '');
  document.body.classList.remove('modal-open');
  (logoutConfirmReturnFocus || logoutButton)?.focus();
  logoutConfirmReturnFocus = null;
}

logoutConfirmModal?.addEventListener('click', (event) => {
  if (event.target === logoutConfirmModal) {
    closeLogoutConfirm();
    return;
  }
  const action = event.target.closest('[data-action]')?.dataset.action;
  if (action === 'cancel-logout') {
    closeLogoutConfirm();
  } else if (action === 'confirm-logout') {
    closeLogoutConfirm();
    logout();
  }
});

// Shown when a Free-tier monthly cap (Tutor IA: 30/mes, voz: 10/mes) is
// reached - see openPaywallModal() below for what fills its content, and
// the /api/ai/tutor and /api/speech/synthesize callers further down for
// where USAGE_LIMIT_REACHED triggers it. Never fakes a purchase: the
// "Obtener Premium" button only scrolls to #premium (see the existing
// .upgrade-btn delegated handler) - no gateway exists yet (lib/billingService.js
// is a stub), so nothing here calls changePlan or flips the user to Premium.
const paywallModal = document.getElementById('paywallModal');
let paywallReturnFocus = null;

// Short, curated subset of lib/plansConfig.js's premium feature list (the
// full list lives in the #premium pricing section) - just enough for the
// "qué obtiene Premium" bullet the spec asks the modal to show.
const PAYWALL_PREMIUM_HIGHLIGHTS = [
  'Tutor IA y conversación por voz sin límites',
  'Todos los idiomas y todos los niveles',
  'Corrección de pronunciación',
  'Certificados y estadísticas completas'
];

// authStatus.entitlements is only ever populated from GET /api/dashboard
// (see saveSession() above) - never derived from localStorage/username, so
// this is safe to gate real features on (e.g. the Tutor's hands-free
// conversation mode below), not just cosmetic copy.
function isPremiumUser() {
  return Boolean(authStatus.entitlements?.isPremium);
}

// title/message let a caller override the two spots worded around a usage
// cap ("Has alcanzado el límite...") for cases that aren't a cap at all -
// e.g. a Premium-only lesson a Free account just tapped into (see the
// lesson workspace's 'open-lesson-paywall' handler below).
function openPaywallModal({ featureLabel, used, limit, title, message } = {}) {
  if (!paywallModal) return;
  paywallReturnFocus = document.activeElement;

  const titleEl = document.getElementById('paywallModalTitle');
  if (titleEl) titleEl.textContent = title || 'Has alcanzado el límite de tu plan gratuito.';

  const usageLine = document.getElementById('paywallUsageLine');
  if (usageLine) {
    usageLine.textContent =
      message ||
      (used != null && limit != null
        ? `Usaste ${used} de ${limit} ${featureLabel} este mes.`
        : `Alcanzaste el límite de ${featureLabel} de tu plan gratuito.`);
  }

  const featuresList = document.getElementById('paywallFeatures');
  if (featuresList) {
    featuresList.innerHTML = PAYWALL_PREMIUM_HIGHLIGHTS.map(
      (item) => `<li>${escapeHtml(item)}</li>`
    ).join('');
  }

  // Prices are never hardcoded here - refreshPremiumPricingUI() (see
  // loadPlans() near the top of this file) fills in the same
  // [data-premium-monthly-price]/[data-premium-yearly-price] spans this
  // modal's markup uses, from GET /api/plans.
  refreshPremiumPricingUI();

  paywallModal.classList.add('open');
  paywallModal.setAttribute('aria-hidden', 'false');
  paywallModal.removeAttribute('inert');
  document.body.classList.add('modal-open');
  paywallModal.querySelector('[data-action="dismiss-paywall"]')?.focus();
}

function closePaywallModal() {
  if (!paywallModal) return;
  paywallModal.classList.remove('open');
  paywallModal.setAttribute('aria-hidden', 'true');
  paywallModal.setAttribute('inert', '');
  document.body.classList.remove('modal-open');
  paywallReturnFocus?.focus();
  paywallReturnFocus = null;
}

paywallModal?.addEventListener('click', (event) => {
  if (event.target === paywallModal) {
    closePaywallModal();
    return;
  }
  const action = event.target.closest('[data-action]')?.dataset.action;
  if (action === 'dismiss-paywall') {
    closePaywallModal();
  } else if (action === 'paywall-upgrade') {
    // Navigation to #premium is handled by the global .upgrade-btn
    // delegated click handler (this button carries that class too) - this
    // listener only closes the modal so it doesn't stay open over the
    // pricing section.
    closePaywallModal();
  }
});

document.addEventListener('keydown', (event) => {
  if (event.key !== 'Escape') return;
  if (logoutConfirmModal?.classList.contains('open')) {
    closeLogoutConfirm();
  } else if (authModal?.classList.contains('open')) {
    closeAuth();
  } else if (paywallModal?.classList.contains('open')) {
    closePaywallModal();
  } else if (document.getElementById('tutorDrawer')?.classList.contains('open')) {
    closeTutorDrawer();
  } else if (document.getElementById('changeComboPopover')?.hidden === false) {
    closeChangeCombinationPopover();
  }
});

async function postJson(path, payload, { auth = false } = {}) {
  const response = await fetch(`${backendBaseUrl}${path}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...(auth ? authHeaders() : {})
    },
    body: JSON.stringify(payload)
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    // Two response shapes exist across our own /api routes: plain auth
    // errors (POST /api/auth) put the human message in `error` and the
    // machine code in `code`; ok:false-wrapped endpoints (username-available,
    // verify-otp, profile/username, rate limiters, ...) put the code in
    // `error` and the human message in `message`. Handle both instead of
    // occasionally surfacing a raw code like "USERNAME_NOT_AVAILABLE" as
    // user-facing text.
    const message = data.message || data.error || 'Request failed';
    const code = data.code || (data.message ? data.error : undefined);
    const error = new Error(message);
    if (code) error.code = code;
    // Only ever present on the EMAIL_NOT_CONFIRMED login error (see
    // lib/authService.js) - undefined everywhere else, so this never adds a
    // field to any other endpoint's thrown error.
    if (data.email) error.email = data.email;
    throw error;
  }

  return data;
}

// Drives the home hero card's states (spec: never show fake stats to a
// guest, show a loading state while the real numbers are in flight, an
// explicit error state if the fetch fails - never a fabricated 0% that's
// indistinguishable from a real, freshly-signed-up 0% - then the real numbers.
function updateProgressDisplay(
  { progress = 0, streak = 0 } = {},
  isSignedIn = false,
  isLoading = false,
  isError = false
) {
  const normalizedProgress = Math.max(0, Math.min(100, Number(progress) || 0));
  currentProgress = normalizedProgress;
  const progressCircle = document.querySelector('.progress-circle');
  const streakCount = document.querySelector('.streak-flame-count');
  const progressText = document.getElementById('homeProgressText');
  const summaryRow = document.getElementById('homeSummaryRow');
  const goalSummary = document.getElementById('homeGoalSummary');
  const guestActions = document.getElementById('homeGuestActions');
  const continueBtn = document.querySelector('.continue-lesson-btn');
  const name = getDisplayName();

  if (summaryRow) summaryRow.hidden = !isSignedIn;
  if (goalSummary) goalSummary.hidden = !isSignedIn;
  if (guestActions) guestActions.hidden = isSignedIn;
  if (continueBtn) continueBtn.hidden = !isSignedIn;

  if (progressCircle)
    progressCircle.textContent = isLoading || isError ? '…' : `${normalizedProgress}%`;
  if (streakCount) streakCount.textContent = isLoading || isError ? '…' : String(streak);
  if (progressText) {
    progressText.hidden = !isSignedIn;
    if (isSignedIn) {
      if (isLoading)
        progressText.textContent = LanguagePair.t('dashboardLoadingProgress', learningPathState.bridgeLanguage);
      else if (isError)
        progressText.textContent = LanguagePair.t('progressLoadFailed', learningPathState.bridgeLanguage);
      else
        progressText.textContent = `${name ? `${name}: ` : ''}${normalizedProgress}% completado · ${streak} días de racha`;
    }
  }
}

async function loadProgress() {
  try {
    if (!authStatus.session?.access_token) {
      updateProgressDisplay();
      return;
    }

    updateProgressDisplay({}, true, true);
    const response = await fetch(`${backendBaseUrl}/api/progress`, {
      headers: {
        Authorization: `Bearer ${authStatus.session.access_token}`
      }
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      updateProgressDisplay({}, true, false, true);
      return;
    }

    updateProgressDisplay(data, true, false);
    // Supabase is the source of truth once signed in: merge it into the
    // local gamification engine so XP/streak/badges survive a logout+login
    // or a fresh browser, instead of only reflecting this device's localStorage.
    window.AndergoGamification?.syncFromServer(data);
  } catch (error) {
    console.warn('Could not load backend progress', error);
    updateProgressDisplay({}, true, false, true);
  }
}

// Returns the signed-in user's saved language/level, or null for guests or
// on any failure - callers keep using learningPathState's current defaults
// in that case, so a failed fetch never blocks navigation.
//
// username MUST be forwarded here - it used to be silently dropped (this
// function only returned language/level/bridgeLanguage), which meant
// maybeShowUsernameOnboarding() below always saw preferences.username as
// undefined and opened the modal for every single login, even for accounts
// that already had a real username (e.g. profiles.username = 'anderson2026').
// See shouldShowUsernameOnboarding()'s profileStatus state machine for how
// this is now evaluated safely.
async function loadPreferences() {
  if (!authStatus.session?.access_token) return null;
  try {
    const response = await fetch(`${backendBaseUrl}/api/preferences`, { headers: authHeaders() });
    if (!response.ok) return null;
    const data = await response.json().catch(() => null);
    if (!data?.language || !data?.level) return null;
    return {
      language: data.language,
      level: data.level,
      bridgeLanguage: data.bridgeLanguage || 'spanish',
      username: data.username ?? null
    };
  } catch (error) {
    console.warn('Could not load saved preferences', error);
    return null;
  }
}

// LocalStorage mirror of the language pair (bridge/target/level) - Supabase
// profiles.bridge_language/preferred_language/preferred_level remain the
// source of truth once signed in (see savePreferences/loadPreferences below),
// but a signed-out visitor has no account to save to at all: without this,
// every L1/L2/level choice a guest made only ever lived in the in-memory
// learningPathState and was lost on reload, a section change, or a fresh tab,
// always reverting to the hardcoded spanish/english defaults. Reads/writes
// merge with whatever is already stored rather than overwriting blindly,
// since some callers (the level select's change handler) only ever pass
// language+level, never bridgeLanguage - same "omitting a field leaves it
// unchanged" contract savePreferences already has with the backend.
const LANGUAGE_PAIR_STORAGE_KEY = 'andergo_language_pair';

function getSavedLanguagePairLocally() {
  try {
    const parsed = JSON.parse(localStorage.getItem(LANGUAGE_PAIR_STORAGE_KEY) || 'null');
    return parsed && typeof parsed === 'object' ? parsed : null;
  } catch {
    return null;
  }
}

function saveLanguagePairLocally(language, level, bridgeLanguage) {
  try {
    const current = getSavedLanguagePairLocally() || {};
    localStorage.setItem(
      LANGUAGE_PAIR_STORAGE_KEY,
      JSON.stringify({
        language: language ?? current.language,
        level: level ?? current.level,
        bridgeLanguage: bridgeLanguage ?? current.bridgeLanguage
      })
    );
  } catch {
    /* private-mode/unavailable localStorage - guest preference just won't persist across reloads */
  }
}

function applyPreferencesToSelects(preferences) {
  if (!preferences) return;
  const languageSelect = document.getElementById('pathLanguageSelect');
  const levelSelect = document.getElementById('pathLevelSelect');
  const bridgeSelect = document.getElementById('pathBridgeSelect');

  preferences.bridgeLanguage = preferences.bridgeLanguage || 'spanish';

  // A stored/shared pair can be unsupported (saved before a validation fix,
  // or written directly through the API bypassing the client) - never apply
  // it as-is, same rule every interactive change already enforces
  // (setBridgeLanguage/setTargetLanguage/swapLearningPathLanguages below).
  // Corrects `preferences` in place (not just local variables) because both
  // call sites (afterAuthSuccess, bootstrapLearningPath) reuse this same
  // object for their own loadLearningPath() call right after this one.
  if (
    LanguagePair &&
    !LanguagePair.isLanguagePairSupported(preferences.bridgeLanguage, preferences.language)
  ) {
    const resolved = LanguagePair.normalizeLanguagePair(
      preferences.bridgeLanguage,
      preferences.language
    );
    preferences.bridgeLanguage = resolved.bridge;
    preferences.language = resolved.target;
    showHomeToast('Esta combinación estará disponible próximamente.');
  }

  if (languageSelect) languageSelect.value = preferences.language;
  if (levelSelect) levelSelect.value = preferences.level;
  if (bridgeSelect) bridgeSelect.value = preferences.bridgeLanguage;
  // Both fields are written straight to learningPathState here, not left for
  // a caller's follow-up loadLearningPath() call to patch up - this is the
  // one place restored preferences become learningPathState, so it has to be
  // complete on its own instead of relying on call-order elsewhere.
  learningPathState.bridgeLanguage = preferences.bridgeLanguage;
  learningPathState.language = preferences.language;
  learningPathState.level = preferences.level;
  syncLearningMode();
  applyInterfaceLanguage(learningPathState.bridgeLanguage);
  updatePathPairPreview();
}

// Fire-and-forget: the dropdowns already reflect the choice locally, so a
// failed save shouldn't interrupt the student's navigation. bridgeLanguage
// is optional - omitting it (undefined) drops it from both the localStorage
// mirror (saveLanguagePairLocally merges instead of overwriting) and the PUT
// body (the backend leaves that field unchanged). The localStorage write
// always runs, signed in or not; Supabase is only reachable once signed in.
function savePreferences(language, level, bridgeLanguage) {
  saveLanguagePairLocally(language, level, bridgeLanguage);
  if (!authStatus.session?.access_token) return;
  fetch(`${backendBaseUrl}/api/preferences`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json', ...authHeaders() },
    body: JSON.stringify({ language, level, bridgeLanguage })
  }).catch((error) => console.warn('Could not save preferences', error));
}

// XP/level/streak have exactly one source of truth: the client-side
// gamification engine (src/js/gamification/*, already reconciled with the
// server via syncFromServer). This line is the only place Progreso shows
// them, so it never disagrees with what Logros shows for the same numbers.
function renderProgressGamificationSummary() {
  const line = document.getElementById('progressGamificationLine');
  if (!line) return;
  const state = window.AndergoGamification?.getState();
  if (!state) {
    line.textContent = '';
    return;
  }
  line.textContent = `Nivel ${state.level} · ${state.xp} XP · 🔥 ${state.streak} días de racha`;
}

function renderDashboardStats(data) {
  const grid = document.getElementById('dashboardStatsGrid');
  const courseProgress = data.courseProgress;
  if (grid) {
    const langLabel =
      languageDisplayNames[data.preferences?.language] || data.preferences?.language || '—';
    const stats = [
      ['Idioma', escapeHtml(langLabel)],
      ['Nivel', escapeHtml(data.preferences?.level || '—')],
      ['Progreso', `${data.progress}%`],
      ['Próxima lección', escapeHtml(data.nextLesson || '—')],
      [
        'Actividades evaluadas',
        courseProgress
          ? `${courseProgress.completedActivities}/${courseProgress.totalActivities}`
          : `${data.completedLessonsCount}`
      ]
    ];
    grid.innerHTML = stats
      .map(
        ([label, value]) => `
      <div class="dashboard-stat"><span>${label}</span><strong>${value}</strong></div>
    `
      )
      .join('');
  }
  const unitGrid = document.getElementById('courseProgressUnits');
  if (unitGrid) {
    unitGrid.innerHTML = courseProgress?.units?.length
      ? `
        <div class="course-progress-heading">
          <h3>Progreso por lección</h3>
          <span>Cada lección incluye 7 actividades · score sobre 100</span>
        </div>
        <div class="course-progress-unit-grid">
          ${courseProgress.units
            .map(
              (unit) => `
                <article class="course-progress-unit-card">
                  <span>Lección ${escapeHtml(String(unit.order))}</span>
                  <strong>${escapeHtml(unit.title)}</strong>
                  <div class="course-progress-unit-bar" role="progressbar" aria-valuenow="${unit.progressPercent}" aria-valuemin="0" aria-valuemax="100">
                    <div style="width:${unit.progressPercent}%"></div>
                  </div>
                  <p>${unit.completedActivities}/${unit.totalActivities} actividades · ${unit.progressPercent}/100</p>
                </article>
              `
            )
            .join('')}
        </div>`
      : '<p class="skill-graph-empty">El progreso por lección aparecerá cuando comiences una ruta organizada por unidades.</p>';
  }
  renderProgressGamificationSummary();
}

function renderDashboardGoal(goal, preferences) {
  const body = document.getElementById('goalsCrudBody');
  const homeGoalSummary = document.querySelector('#homeGoalSummary strong');

  const goalOptionsHtml = (selectedKey) =>
    Object.entries(goalOptions)
      .map(
        ([key, opt]) =>
          `<option value="${key}" ${key === selectedKey ? 'selected' : ''}>${escapeHtml(opt.label)}</option>`
      )
      .join('');

  if (!goal) {
    if (body) {
      body.innerHTML = `
        <p class="skill-graph-empty">Todavía no tienes un objetivo activo.</p>
        <div class="dashboard-goal-form">
          <select id="dashboardGoalSelect">${goalOptionsHtml('daily')}</select>
          <button type="button" data-goal-action="create">Crear objetivo</button>
        </div>
      `;
    }
    if (homeGoalSummary) homeGoalSummary.textContent = 'Sin objetivo activo';
    return;
  }

  const label = goalOptions[goal.goalKey]?.label || goal.goalKey;
  if (homeGoalSummary) homeGoalSummary.textContent = label;
  if (!body) return;

  const dateFormat = { day: 'numeric', month: 'short', year: 'numeric' };
  const createdText = new Date(goal.selectedAt).toLocaleDateString('es', dateFormat);
  const completedText = goal.completedAt
    ? new Date(goal.completedAt).toLocaleDateString('es', dateFormat)
    : null;
  const langLabel = languageDisplayNames[preferences?.language] || preferences?.language || '—';

  body.innerHTML = `
    <div data-goal-id="${escapeHtml(goal.id)}">
      <p class="dashboard-goal-label">${goal.completedAt ? '✅' : '🎯'} <strong>${escapeHtml(label)}</strong></p>
      <p class="dashboard-goal-meta">Creado el ${createdText}${completedText ? ` · Completado el ${completedText}` : ''}</p>
      <p class="dashboard-goal-meta">Idioma y nivel: ${escapeHtml(langLabel)} · ${escapeHtml(preferences?.level || '—')}</p>
      <div class="dashboard-goal-form" data-goal-edit-form hidden>
        <select id="dashboardGoalSelect">${goalOptionsHtml(goal.goalKey)}</select>
        <button type="button" data-goal-action="save-edit">Guardar</button>
      </div>
      <div class="dashboard-goal-actions">
        <button type="button" data-goal-action="edit">Editar</button>
        ${goal.completedAt ? '' : '<button type="button" data-goal-action="complete">Marcar como completado</button>'}
        <button type="button" data-goal-action="delete">Eliminar</button>
      </div>
    </div>
  `;
}

function renderDashboardActivity(activity) {
  const list = document.getElementById('dashboardActivityList');
  if (!list) return;

  if (!activity || activity.length === 0) {
    list.innerHTML =
      '<li class="skill-graph-empty">Aún no tienes actividad reciente. Completa tu primera lección para comenzar.</li>';
    return;
  }

  list.innerHTML = activity
    .map((entry) => {
      const date = new Date(entry.at).toLocaleDateString('es', { day: 'numeric', month: 'short' });
      let icon = '📌';
      let text = '';
      if (entry.type === 'lesson_completed') {
        icon = '🎉';
        const xpText = entry.xp ? ` · +${entry.xp} XP` : '';
        text = `Completaste "${escapeHtml(entry.title)}"${xpText}`;
      } else if (entry.type === 'goal_created') {
        icon = '🎯';
        text = `Nuevo objetivo: ${escapeHtml(goalOptions[entry.goalKey]?.label || entry.goalKey)}`;
      } else if (entry.type === 'goal_completed') {
        icon = '✅';
        text = `Objetivo completado: ${escapeHtml(goalOptions[entry.goalKey]?.label || entry.goalKey)}`;
      }
      return `<li class="dashboard-activity-item"><span class="dashboard-activity-icon">${icon}</span><span class="dashboard-activity-text">${text}</span><span class="dashboard-activity-date">${date}</span></li>`;
    })
    .join('');
}

function renderDashboardLoading() {
  const lang = learningPathState.bridgeLanguage;
  const grid = document.getElementById('dashboardStatsGrid');
  if (grid)
    grid.innerHTML = `<p class="skill-graph-empty">${escapeHtml(LanguagePair.t('dashboardLoadingPanel', lang))}</p>`;
  const goalBody = document.getElementById('goalsCrudBody');
  if (goalBody)
    goalBody.innerHTML = `<p class="skill-graph-empty">${escapeHtml(LanguagePair.t('dashboardLoadingGoal', lang))}</p>`;
  const activityList = document.getElementById('dashboardActivityList');
  if (activityList)
    activityList.innerHTML = `<li class="skill-graph-empty">${escapeHtml(LanguagePair.t('dashboardLoadingActivity', lang))}</li>`;
  // The home hero's goal one-liner is a separate DOM node (renderDashboardGoal
  // only touches it once real data arrives) - without this it would keep
  // showing the static "Sin objetivo activo" placeholder while this loads.
  const homeGoalSummary = document.querySelector('#homeGoalSummary strong');
  if (homeGoalSummary) homeGoalSummary.textContent = LanguagePair.t('genericLoading', lang);
}

function renderDashboardError() {
  const lang = learningPathState.bridgeLanguage;
  const grid = document.getElementById('dashboardStatsGrid');
  if (grid)
    grid.innerHTML = `<p class="skill-graph-empty">${escapeHtml(LanguagePair.t('panelLoadFailed', lang))}</p>`;
  const homeGoalSummary = document.querySelector('#homeGoalSummary strong');
  if (homeGoalSummary) homeGoalSummary.textContent = LanguagePair.t('genericLoadFailed', lang);
}

function renderDashboardSignedOut() {
  const grid = document.getElementById('dashboardStatsGrid');
  if (grid) grid.innerHTML = '<p class="skill-graph-empty">Inicia sesión para ver tu progreso.</p>';
  const goalBody = document.getElementById('goalsCrudBody');
  if (goalBody)
    goalBody.innerHTML =
      '<p class="skill-graph-empty">Inicia sesión para crear y guardar tu objetivo.</p>';
  const activityList = document.getElementById('dashboardActivityList');
  if (activityList)
    activityList.innerHTML =
      '<li class="skill-graph-empty">Inicia sesión para ver tu actividad.</li>';
  const line = document.getElementById('progressGamificationLine');
  if (line) line.textContent = '';
  const courseProgressUnits = document.getElementById('courseProgressUnits');
  if (courseProgressUnits)
    courseProgressUnits.innerHTML =
      '<p class="skill-graph-empty">Inicia sesión para ver el score y progreso de cada lección.</p>';
}

let dashboardPreferences = null;

function renderDashboard(data) {
  if (!data) {
    dashboardPreferences = null;
    authStatus.entitlements = null;
    renderDashboardSignedOut();
    return;
  }

  dashboardPreferences = data.preferences;
  // Defense-in-depth for shouldShowUsernameOnboarding()'s race-condition
  // rule: if the dashboard's own preferences (also carrying username)
  // resolve while the onboarding modal happens to still be open, close it
  // immediately rather than leaving a stale "create your username" prompt
  // up for an account that already has one.
  closeUsernameOnboardingIfNowSatisfied(data.preferences);
  if (data.entitlements) {
    authStatus.entitlements = data.entitlements;
    renderAuthState();
  }
  renderDashboardStats(data);
  renderDashboardGoal(data.goal, data.preferences);
  renderDashboardActivity(data.activity);
}

// Never throws - a failed load just leaves the panel showing its error state,
// it doesn't block anything else on the page (same convention as loadProgress).
// Feeds both #progress (stats/activity) and #goals (goal CRUD), since both
// views need the same /api/dashboard payload - see renderDashboardGoal.
async function loadDashboard() {
  if (!authStatus.session?.access_token) {
    renderDashboard(null);
    return;
  }

  renderDashboardLoading();

  try {
    const response = await fetch(`${backendBaseUrl}/api/dashboard`, { headers: authHeaders() });
    if (!response.ok) throw new Error('Request failed');
    const data = await response.json();
    renderDashboard(data);
  } catch (error) {
    console.warn('Could not load dashboard', error);
    renderDashboardError();
  }
}

document.getElementById('goalsCrudBody')?.addEventListener('click', async (event) => {
  const button = event.target.closest('[data-goal-action]');
  if (!button) return;
  const action = button.dataset.goalAction;
  const container = button.closest('[data-goal-id]');
  const goalId = container?.dataset.goalId;
  const select = document.getElementById('dashboardGoalSelect');

  try {
    if (action === 'create') {
      await fetch(`${backendBaseUrl}/api/goals`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...authHeaders() },
        body: JSON.stringify({ goalKey: select?.value || 'daily' })
      });
      showHomeToast('Objetivo creado.');
    } else if (action === 'edit') {
      container?.querySelector('[data-goal-edit-form]')?.removeAttribute('hidden');
      return;
    } else if (action === 'save-edit') {
      await fetch(`${backendBaseUrl}/api/goals/${goalId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', ...authHeaders() },
        body: JSON.stringify({ goalKey: select?.value })
      });
      showHomeToast('Objetivo actualizado.');
    } else if (action === 'complete') {
      await fetch(`${backendBaseUrl}/api/goals/${goalId}/complete`, {
        method: 'POST',
        headers: authHeaders()
      });
      showHomeToast('¡Objetivo marcado como completado!');
    } else if (action === 'delete') {
      if (!window.confirm('¿Eliminar tu objetivo actual?')) return;
      await fetch(`${backendBaseUrl}/api/goals/${goalId}`, {
        method: 'DELETE',
        headers: authHeaders()
      });
      showHomeToast('Objetivo eliminado.');
    }
    await loadDashboard();
  } catch (error) {
    console.warn('Could not update goal', error);
    showHomeToast('No se pudo actualizar el objetivo. Intenta de nuevo.');
  }
});

// Scoped to the currently active form - #loginForm and #signupForm each have
// their own .auth-note, and only one is visible (.auth-form.active) at a
// time. An unscoped querySelector('.auth-note') always grabs the login
// form's note (first in the DOM) even while the signup tab is showing,
// silently writing register errors into a hidden element.
function setAuthMessage(message, isError = false) {
  const note = document.querySelector('.auth-form.active .auth-note');
  if (!note) return;
  note.textContent = message;
  note.style.color = isError ? '#dc2626' : '#0f766e';
}

// Relabels "Enviar enlace" to a counting-down "Reenviar enlace (Ns)" after a
// successful send, instead of re-enabling immediately - the visible
// countdown the spec asks for, using the same button rather than adding a
// second one. Any pending countdown is always cleared first, so reopening
// the panel or submitting again never stacks two intervals.
let forgotPasswordCooldownInterval = null;
function resetForgotPasswordForm() {
  window.clearInterval(forgotPasswordCooldownInterval);
  forgotPasswordCooldownInterval = null;
  const submitBtn = document.getElementById('forgotPasswordSubmit');
  const statusEl = document.getElementById('forgotPasswordStatus');
  if (submitBtn) {
    submitBtn.disabled = false;
    submitBtn.textContent = LanguagePair.t('authSendLink', learningPathState.bridgeLanguage);
  }
  if (statusEl) {
    statusEl.textContent = '';
    statusEl.classList.remove('is-error');
    statusEl.setAttribute('role', 'status');
  }
}

function startForgotPasswordCooldown(button, seconds = 30) {
  if (!button) return;
  window.clearInterval(forgotPasswordCooldownInterval);
  let remaining = seconds;
  const resendLabel = LanguagePair.t('authResendLink', learningPathState.bridgeLanguage);
  button.disabled = true;
  button.textContent = `${resendLabel} (${remaining}s)`;
  forgotPasswordCooldownInterval = window.setInterval(() => {
    remaining -= 1;
    if (remaining <= 0) {
      window.clearInterval(forgotPasswordCooldownInterval);
      forgotPasswordCooldownInterval = null;
      button.disabled = false;
      button.textContent = resendLabel;
      return;
    }
    button.textContent = `${resendLabel} (${remaining}s)`;
  }, 1000);
}

function clearAuthMessages() {
  document.querySelectorAll('.auth-form .auth-note').forEach((note) => {
    note.textContent = note.dataset.defaultText || '';
    note.style.color = '';
  });
}

// Views that only ever show an "Inicia sesión para..." placeholder for a
// guest (see renderDashboardSignedOut/loadSecurityStatus) - unlike 'learn'
// and 'tutor', which stay genuinely usable signed out (free lessons, an
// uncapped Tutor IA chat) and so are deliberately left off this list.
const MEMBER_ONLY_VIEWS_AFTER_LOGOUT = ['progress', 'achievements', 'goals', 'security'];

async function logout() {
  try {
    if (authStatus.session?.access_token) {
      await fetch(`${backendBaseUrl}/api/auth/logout`, {
        method: 'POST',
        headers: authHeaders()
      }).catch(() => {});
    }
  } finally {
    authStatus.user = null;
    authStatus.session = null;
    localStorage.removeItem('andergoSession');
    // A dismissal only ever applies to the account that dismissed it - the
    // next login (same tab or not) re-evaluates fresh instead of inheriting
    // a previous account's "Ahora no".
    sessionStorage.removeItem(USERNAME_ONBOARDING_DISMISSED_KEY);
    profileStatus = 'idle';
    renderAuthState();
    updateProgressDisplay();
    renderDashboard(null);
    window.AndergoGamification?.load('guest');
    // "Volver a la página pública" (spec §8) - never leave a signed-out
    // student stranded on a now-empty member-only view; never opens the
    // login modal automatically either (that stays the student's choice).
    if (MEMBER_ONLY_VIEWS_AFTER_LOGOUT.includes(getViewFromHash())) {
      if (window.location.hash !== '#home') history.pushState(null, '', '#home');
      showView('home');
    }
    // Verbos stays public (list/Conjugador) even after logout - only its
    // Practicar/Mi progreso subtabs re-gate, and only if one of them happens
    // to be the currently open subtab.
    window.regateVerbsFeatureTabs?.();
  }
}

// Tracks the GET /api/preferences fetch that maybeShowUsernameOnboarding()
// depends on - 'loading'/'error'/a preferences object still in flight or a
// transient failure must never be read as "no username", or the modal would
// wrongly open for an account that has a real username the moment a request
// is merely slow or a network blip returns null. See afterAuthSuccess() for
// the only place this transitions away from 'idle'.
let profileStatus = 'idle';

const USERNAME_ONBOARDING_DISMISSED_KEY = 'username_onboarding_dismissed';

// Single source of truth for "does this account already have a username" -
// profiles.username_normalized/profiles.username (loaded via
// GET /api/preferences into `profile`) is authoritative; user.username (from
// the login/register response's user_metadata.username, see
// lib/authService.js) is only ever a fallback for the brief window right
// after login before that preferences fetch resolves.
function hasValidUsername({ profile, user }) {
  const profileUsername = profile?.username;
  const metadataUsername = user?.username;
  return Boolean(String(profileUsername || metadataUsername || '').trim());
}

// Centralizes every condition that must hold before the "create your
// username" onboarding is allowed to open - see the equivalent checklist in
// the task this was written against: no session, no confirmed email, a
// profile fetch that hasn't finished (or failed) yet, or an account that
// already has a username must all block it, not just "preferences.username
// was falsy" (that one omission is what caused the modal to reopen for
// every account, including ones with a real username - see loadPreferences()
// above).
function shouldShowUsernameOnboarding({ session, user, profile, profileStatus: status }) {
  if (!session?.access_token) return false;
  if (!user?.emailConfirmedAt) return false;
  if (status !== 'loaded') return false;
  if (sessionStorage.getItem(USERNAME_ONBOARDING_DISMISSED_KEY) === 'true') return false;
  if (hasValidUsername({ profile, user })) return false;
  return true;
}

// Shows the "create your username" onboarding once, right after a
// successful login, but only for accounts that predate this feature (no
// username anywhere yet) - never blocks anything else. See
// shouldShowUsernameOnboarding() for the full gate.
//
// One extra step before that gate: if profiles has no username yet but the
// signup metadata does (user.username - see lib/authService.js), try to
// persist it server-side first instead of either trusting it forever or
// discarding it (§9) - claimUsername() only succeeds if that exact username
// is still available, so this can never silently steal/overwrite one. This
// is most commonly the rare handle_new_user() collision case (see the
// 202607150001 migration's comments) where the metadata username was
// already claimed by someone else in the same instant; then the sync fails
// and onboarding is the correct outcome, not a silently-skipped prompt.
async function maybeShowUsernameOnboarding(preferences) {
  let user = authStatus.user;

  // profileStatus !== 'loaded' already makes shouldShowUsernameOnboarding()
  // return false below regardless - skip the sync network call too in that
  // case (profile fetch still in flight or failed) rather than firing it
  // pointlessly.
  if (profileStatus === 'loaded' && !preferences?.username && user?.username) {
    try {
      await postJson('/api/profile/username', { username: user.username }, { auth: true });
      preferences = { ...preferences, username: user.username };
    } catch {
      // That exact username wasn't usable - it must stop counting as
      // "valid" below, or a failed sync would be treated the same as a
      // successful one and onboarding would never open for this account.
      user = { ...user, username: null };
    }
  }

  if (
    !shouldShowUsernameOnboarding({
      session: authStatus.session,
      user,
      profile: preferences,
      profileStatus
    })
  ) {
    return;
  }
  const modal = document.getElementById('usernameOnboardingModal');
  if (!modal) return;
  modal.classList.add('open');
  modal.setAttribute('aria-hidden', 'false');
  modal.removeAttribute('inert');
  document.body.classList.add('modal-open');
  modal.querySelector('input')?.focus();
}

// Safety net for the (rare, non-racy-today, but worth guarding) case where a
// username becomes known - e.g. profile data resolves after the modal was
// already opened, or the account gets a username via another path this
// session - while the onboarding modal is still open: close it immediately
// rather than leaving a stale prompt up for a username that already exists.
function closeUsernameOnboardingIfNowSatisfied(preferences) {
  const modal = document.getElementById('usernameOnboardingModal');
  if (!modal || !modal.classList.contains('open')) return;
  if (hasValidUsername({ profile: preferences, user: authStatus.user })) {
    closeUsernameOnboarding();
  }
}

function closeUsernameOnboarding() {
  const modal = document.getElementById('usernameOnboardingModal');
  if (!modal) return;
  modal.classList.remove('open');
  modal.setAttribute('aria-hidden', 'true');
  modal.setAttribute('inert', '');
  document.body.classList.remove('modal-open');
}

// Loads the official supabase-js UMD bundle from a CDN - the one exception
// to "the frontend never talks to Supabase directly" (see server.js's
// /api/auth/client-config comment for why this specific screen needs it:
// the password-recovery token Supabase appends to the redirect URL only
// ever reaches the browser, never our backend).
function loadSupabaseJs() {
  if (window.supabase?.createClient) return Promise.resolve();
  return new Promise((resolve, reject) => {
    const existing = document.querySelector('script[data-supabase-js]');
    if (existing) {
      existing.addEventListener('load', () => resolve());
      existing.addEventListener('error', () => reject(new Error('load failed')));
      return;
    }
    const script = document.createElement('script');
    script.src = 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/dist/umd/supabase.js';
    script.dataset.supabaseJs = 'true';
    script.addEventListener('load', () => resolve());
    script.addEventListener('error', () => reject(new Error('load failed')));
    document.head.appendChild(script);
  });
}

// Drives /reset-password: the link Supabase emails (via
// authService.requestPasswordReset's resetPasswordForEmail call) lands here
// with a recovery token in the URL that only supabase-js can read and turn
// into a session - our backend never sees it. Everything else in ANDERGO
// goes through our own /api/*; this one screen is the deliberate exception.
async function initResetPasswordPage() {
  const form = document.getElementById('resetPasswordForm');
  const successEl = document.getElementById('resetPasswordSuccess');
  const invalidEl = document.getElementById('resetPasswordInvalid');
  const statusEl = document.getElementById('resetPasswordStatus');
  if (!form || !successEl || !invalidEl) return;

  function showInvalid() {
    form.hidden = true;
    successEl.hidden = true;
    invalidEl.hidden = false;
  }

  let clientConfig;
  try {
    const res = await fetch(`${backendBaseUrl}/api/auth/client-config`);
    clientConfig = await res.json();
  } catch {
    showInvalid();
    return;
  }
  if (!clientConfig?.supabaseUrl || !clientConfig?.supabaseAnonKey) {
    showInvalid();
    return;
  }

  try {
    await loadSupabaseJs();
  } catch {
    showInvalid();
    return;
  }
  if (!window.supabase?.createClient) {
    showInvalid();
    return;
  }

  const client = window.supabase.createClient(
    clientConfig.supabaseUrl,
    clientConfig.supabaseAnonKey
  );
  let recoveryReady = false;

  const revealForm = () => {
    if (recoveryReady) return;
    recoveryReady = true;
    form.hidden = false;
    form.querySelector('input')?.focus();
  };

  client.auth.onAuthStateChange((event) => {
    if (event === 'PASSWORD_RECOVERY') revealForm();
  });

  // Some Supabase configurations establish the recovery session before the
  // listener above attaches - check directly instead of only reacting to
  // the event, and only give up if neither ever shows a session.
  window.setTimeout(async () => {
    if (recoveryReady) return;
    const { data } = await client.auth.getSession();
    if (data?.session) {
      revealForm();
    } else {
      showInvalid();
    }
  }, 2500);

  setupPasswordStrengthMeter('resetNewPassword', 'resetPasswordStrength');

  const setResetStatus = (message, isError) => {
    statusEl.textContent = message;
    statusEl.classList.toggle('is-error', isError);
    statusEl.setAttribute('role', isError ? 'alert' : 'status');
  };

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const password = document.getElementById('resetNewPassword')?.value || '';
    const confirmPassword = document.getElementById('resetConfirmPassword')?.value || '';

    if (!password || !confirmPassword) {
      setResetStatus('Completa ambos campos.', true);
      return;
    }
    if (password !== confirmPassword) {
      setResetStatus('Las contraseñas no coinciden.', true);
      return;
    }
    // Supabase's own default minimum (6 chars) - a friendly pre-check only;
    // the actual policy is still enforced server-side by updateUser() below,
    // whatever it's configured to be.
    if (password.length < 6) {
      setResetStatus('La contraseña debe tener al menos 6 caracteres.', true);
      return;
    }

    const submitBtn = form.querySelector('button[type="submit"]');
    if (submitBtn) submitBtn.disabled = true;
    setResetStatus('Guardando…', false);

    try {
      const { error } = await client.auth.updateUser({ password });
      if (error) throw error;

      // End the recovery-only session (never leave the student signed in
      // via the one-time recovery token) and strip it from the URL before
      // showing success - the success panel itself stays up until the
      // student clicks "Ir a iniciar sesión", per spec (never auto-navigate
      // away before they can read the confirmation).
      await client.auth.signOut().catch(() => {});
      window.history.replaceState(null, '', '/');

      setResetStatus('', false);
      form.hidden = true;
      successEl.hidden = false;
      successEl.focus?.();
    } catch {
      setResetStatus('No se pudo actualizar la contraseña. Solicita un nuevo enlace.', true);
    } finally {
      if (submitBtn) submitBtn.disabled = false;
    }
  });
}

// Guards initEmailConfirmedPage() below against ever processing the same
// confirmation `code` twice: it runs exactly once today (called once at
// load - see the bottom of this file), but a `code` is single-use on
// Supabase's side, so a second run (e.g. a bfcache restore replaying this
// script) must short-circuit instead of sending an already-spent code back
// to exchangeCodeForSession().
let emailConfirmationCallbackHandled = false;

// Drives the confirmation-LINK variant landing (#emailConfirmedSection,
// ?auth=confirmed) - the 6-digit OTP in showSignupPending() is the primary
// confirmation path; this only covers a student tapping the email's link
// instead. Supabase's confirmation link can arrive either as a PKCE `code`
// query param (exchangeCodeForSession) or with the session already
// established via the URL fragment (supabase-js's detectSessionInUrl reads
// that automatically on client creation) - both are handled the same way
// below: confirm a session exists, then immediately sign it back out. That
// session is never adopted as this app's own signed-in state (which only
// ever comes from POST /api/auth - see login() in lib/authService.js) and
// never left lingering - per spec, confirming an email must never auto-log
// the student in or land them on a password form; it only ever shows the
// confirmation message and sends them to the normal login.
async function initEmailConfirmedPage() {
  if (emailConfirmationCallbackHandled) return;
  emailConfirmationCallbackHandled = true;

  const successEl = document.getElementById('emailConfirmedSuccess');
  const invalidEl = document.getElementById('emailConfirmedInvalid');
  const invalidMessageEl = document.getElementById('emailConfirmedInvalidMessage');
  if (!successEl || !invalidEl) return;

  // The URL's callback params (?auth=confirmed / code / error*) are only
  // ever meaningful for this one load - stripped once, after processing
  // finishes (success or not), never before, so a reload never re-attempts
  // an already-spent code and never leaves a stale error dangling in the
  // address bar either.
  function showInvalid(message) {
    window.history.replaceState(null, '', '/');
    successEl.hidden = true;
    invalidEl.hidden = false;
    if (invalidMessageEl && message) invalidMessageEl.textContent = message;
  }

  function showSuccess(email) {
    window.history.replaceState(null, '', '/');
    successEl.hidden = false;
    invalidEl.hidden = true;
    const loginIdentifierInput = document.getElementById('loginIdentifier');
    if (loginIdentifierInput && email) loginIdentifierInput.value = email;
  }

  // Supabase's own error redirect (expired/already-used/invalid link) lands
  // here with ?error&error_code&error_description instead of a `code` -
  // that request never reaches exchangeCodeForSession at all, so this must
  // be checked first, before even loading supabase-js.
  const callbackParams = new URLSearchParams(window.location.search);
  const errorCode = callbackParams.get('error_code');
  if (callbackParams.get('error') || errorCode) {
    showInvalid(
      errorCode === 'otp_expired'
        ? 'El enlace de confirmación expiró. Solicita uno nuevo.'
        : undefined
    );
    return;
  }

  let clientConfig;
  try {
    const res = await fetch(`${backendBaseUrl}/api/auth/client-config`);
    clientConfig = await res.json();
  } catch {
    showInvalid();
    return;
  }
  if (!clientConfig?.supabaseUrl || !clientConfig?.supabaseAnonKey) {
    showInvalid();
    return;
  }

  try {
    await loadSupabaseJs();
  } catch {
    showInvalid();
    return;
  }
  if (!window.supabase?.createClient) {
    showInvalid();
    return;
  }

  const client = window.supabase.createClient(
    clientConfig.supabaseUrl,
    clientConfig.supabaseAnonKey
  );

  // Registered immediately, before any of the getSession()/
  // exchangeCodeForSession() calls below - a purely observational
  // safeguard: this app's REST-backed session model (see login() in
  // lib/authService.js) never adopts a supabase-js session as its own
  // signed-in state, so nothing here reacts to the event itself, but it
  // must exist from the start rather than risk missing a SIGNED_IN that
  // fires while the client is still finishing setup.
  client.auth.onAuthStateChange(() => {});

  try {
    const code = callbackParams.get('code');
    let { data } = await client.auth.getSession();
    // Only exchange if there's a code AND no session yet - never re-run
    // this for a code that already produced a session (see
    // emailConfirmationCallbackHandled above for the same guarantee across
    // repeated calls to this function).
    if (code && !data?.session) {
      const { error } = await client.auth.exchangeCodeForSession(code);
      if (error) throw error;
      ({ data } = await client.auth.getSession());
    }
    if (!data?.session) throw new Error('No confirmation session');
    if (!data.session.user?.email_confirmed_at) throw new Error('Email not confirmed');
    const email = data.session.user?.email || null;

    await client.auth.signOut().catch(() => {});
    showSuccess(email);
  } catch {
    showInvalid();
  }
}

document.getElementById('emailConfirmedSuccess')?.addEventListener('click', (event) => {
  if (!event.target.closest('[data-action="email-confirmed-login"]')) return;
  if (window.location.hash !== '#home') history.pushState(null, '', '#home');
  showView('home');
  openModal('login');
});

// Called right after saveSession() on every successful sign-in path (plain
// login, MFA-completed login, and register()'s immediate-session dev-store
// fallback) - see loginForm/mfaChallengeForm/signupForm's submit handlers
// below. The session is already saved by the time this runs, so the modal
// closes immediately, before any of the slower per-account loads below -
// previously closeAuth() only ran after all of them resolved, so a slow or
// failed loadProgress()/loadPreferences()/loadLearningPath() left the Auth
// modal sitting open over an already-signed-in page instead of closing on
// login as expected.
async function afterAuthSuccess() {
  closeAllAuthUI();

  try {
    await loadProgress();

    // profileStatus gates maybeShowUsernameOnboarding() below - it must reach
    // 'loaded' (a real preferences object, username included) before the
    // onboarding modal is even considered, never while the fetch is still
    // 'loading' or ended in 'error' (loadPreferences() only ever returns null
    // on a genuine fetch/parse failure here, since every profile row already
    // has language/level defaults - see preferencesService.js).
    profileStatus = 'loading';
    const preferences = await loadPreferences();
    profileStatus = preferences ? 'loaded' : 'error';

    applyPreferencesToSelects(preferences);
    await loadLearningPath(preferences || {});
    await maybeShowUsernameOnboarding(preferences);
  } catch (error) {
    // The signed-in UI itself (header/dashboard) is already showing - never
    // let a hiccup in one of these secondary loads throw back up into the
    // caller and look like the login itself failed.
    console.warn('Post-login setup failed', error);
  }

  // No-op unless the student reached Auth via the Verbos Practicar/Mi
  // progreso guard (verbs-view.js) - restores that exact subtab instead of
  // leaving it on the access-required panel it briefly showed.
  window.restoreVerbsPendingRoute?.();
}

function attachAuthHandlers() {
  document.getElementById('loginForm')?.addEventListener('submit', async (event) => {
    event.preventDefault();
    const identifier = document.getElementById('loginIdentifier')?.value.trim() || '';
    const password = document.getElementById('loginPassword')?.value || '';

    try {
      const data = await postJson('/api/auth', { action: 'login', identifier, password });
      if (data.requiresMfa) {
        // aal1 only - held in memory until the TOTP code below elevates it
        // to aal2 (mfaService.verifyFactor's session), never saved/shown as
        // a signed-in state.
        pendingMfa = { user: data.user, session: data.session };
        openModal('mfaChallenge');
        return;
      }
      saveSession(data.user, data.session);
      await afterAuthSuccess();
    } catch (error) {
      // Existing account, correct password, just never confirmed - route to
      // the same OTP panel signup uses instead of a dead-end inline message,
      // per spec section 7. error.email is only ever set on this exact error
      // (see authService.login/postJson above) and is safe to use here: the
      // password already checked out, so this isn't an enumeration leak.
      if (error.code === 'EMAIL_NOT_CONFIRMED' && error.email) {
        openModal('signup');
        showSignupPending(error.email, { source: 'login-unconfirmed' });
        return;
      }
      setAuthMessage(error.message, true);
    }
  });

  document.getElementById('mfaChallengeForm')?.addEventListener('submit', async (event) => {
    event.preventDefault();
    const statusEl = document.getElementById('mfaChallengeStatus');
    const codeInput = document.getElementById('mfaChallengeCode');
    const code = codeInput?.value.trim() || '';
    const submitBtn = event.target.querySelector('button[type="submit"]');

    if (!pendingMfa?.session?.access_token) {
      openModal('login');
      return;
    }

    if (statusEl) {
      statusEl.textContent = '';
      statusEl.classList.remove('is-error');
    }
    if (submitBtn) submitBtn.disabled = true;

    try {
      const authHeader = { Authorization: `Bearer ${pendingMfa.session.access_token}` };
      const factorsResponse = await fetch(`${backendBaseUrl}/api/mfa/factors`, {
        headers: authHeader
      });
      const factorsData = await factorsResponse.json().catch(() => ({}));
      const activeFactor = factorsData.totp?.find((factor) => factor.status === 'verified');
      if (!factorsResponse.ok || !activeFactor) {
        throw new Error('No se pudo iniciar la verificación en dos pasos.');
      }

      const challengeResponse = await fetch(`${backendBaseUrl}/api/mfa/totp/challenge`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...authHeader },
        body: JSON.stringify({ factorId: activeFactor.id })
      });
      const challengeData = await challengeResponse.json().catch(() => ({}));
      if (!challengeResponse.ok || !challengeData.challengeId) {
        throw new Error(challengeData.message || 'No se pudo generar el desafío de verificación.');
      }

      const verifyResponse = await fetch(`${backendBaseUrl}/api/mfa/totp/verify`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...authHeader },
        body: JSON.stringify({
          factorId: activeFactor.id,
          challengeId: challengeData.challengeId,
          code
        })
      });
      const verifyData = await verifyResponse.json().catch(() => ({}));
      if (!verifyResponse.ok || !verifyData.ok) {
        throw new Error(verifyData.message || 'Código incorrecto. Intenta de nuevo.');
      }

      const verifiedUser = pendingMfa.user;
      clearPendingMfa();
      if (codeInput) codeInput.value = '';
      saveSession(verifiedUser, verifyData.session);
      await afterAuthSuccess();
    } catch (error) {
      if (statusEl) {
        statusEl.textContent = error.message || 'Código incorrecto. Intenta de nuevo.';
        statusEl.classList.add('is-error');
      }
    } finally {
      if (submitBtn) submitBtn.disabled = false;
    }
  });

  document.getElementById('signupForm')?.addEventListener('submit', async (event) => {
    event.preventDefault();
    // The only type="submit" control lives in step 2 (Crear cuenta), but
    // guard anyway against any stray native submit reaching here while step 1
    // is still showing - account creation must never fire before the
    // password step's own validation has run.
    if (signupStep !== 2) return;

    const usernameInput = document.getElementById('signupUsername');
    const usernameStatusEl = document.getElementById('signupUsernameStatus');
    const rawUsername = usernameInput?.value || '';
    const email = document.getElementById('signupEmail')?.value.trim() || '';
    const password = document.getElementById('signupPassword')?.value || '';
    const confirmPassword = document.getElementById('signupConfirmPassword')?.value || '';

    if (password !== confirmPassword) {
      setAuthMessage('Las contraseñas no coinciden.', true);
      return;
    }

    const submitBtn = event.target.querySelector('button[type="submit"]');
    if (submitBtn) submitBtn.disabled = true;

    try {
      // Username availability was already confirmed with the server when
      // advancing from step 1 (see handleSignupContinue) - the partial
      // unique index on username_normalized is still the real, final
      // authority, so no need to re-check it a second time here before
      // attempting to create the account.
      const data = await postJson('/api/auth', {
        action: 'register',
        username: rawUsername.trim(),
        email,
        password
      });

      // Pending email confirmation is not a signed-in state: no session,
      // no dashboard/progress load. Only now - after Supabase has actually
      // created the account and sent the code - does the modal switch from
      // the registration fields to the OTP verification step.
      if (data.requiresEmailConfirmation) {
        showSignupPending(email);
        return;
      }

      saveSession(data.user, data.session);
      await afterAuthSuccess();
    } catch (error) {
      // Someone else claimed this exact username in the moment between our
      // last check and this submit (rare race) - surface it through the
      // same status element as every other username message, and send the
      // student back to step 1 so that element (and the input) are visible.
      if (error.code === 'USERNAME_NOT_AVAILABLE') {
        setUsernameStatus(
          'signupUsername',
          usernameStatusEl,
          'unavailable',
          window.AndergoUsernameRules?.normalizeUsername(rawUsername) || '',
          'Este nombre de usuario ya no está disponible. Elige otro.'
        );
        goToSignupStep(1);
        return;
      }
      setAuthMessage(error.message, true);
    } finally {
      if (submitBtn) submitBtn.disabled = false;
    }
  });

  document.getElementById('forgotPasswordForm')?.addEventListener('submit', async (event) => {
    event.preventDefault();
    const email = document.getElementById('forgotEmail')?.value.trim() || '';
    const submitBtn = document.getElementById('forgotPasswordSubmit');
    const statusEl = document.getElementById('forgotPasswordStatus');
    // Guards double-submit both while the request is in flight and during
    // the post-send cooldown started by startForgotPasswordCooldown() below.
    if (submitBtn?.disabled) return;

    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.textContent = 'Enviando…';
    }
    if (statusEl) {
      statusEl.textContent = '';
      statusEl.classList.remove('is-error');
      statusEl.setAttribute('role', 'status');
    }

    try {
      const data = await postJson('/api/auth/request-password-reset', { email });
      if (statusEl) {
        statusEl.classList.remove('is-error');
        statusEl.setAttribute('role', 'status');
        statusEl.textContent =
          data.message ||
          'Si existe una cuenta asociada a este correo, recibirás un enlace para restablecer tu contraseña. Revisa también Spam o Correo no deseado.';
      }
      // Modal stays open on purpose (see spec) - only the button becomes a
      // cooldown-gated "Reenviar enlace" instead of re-enabling immediately.
      startForgotPasswordCooldown(submitBtn);
    } catch (error) {
      // requestPasswordReset itself is designed to never throw a
      // distinguishing error - this only ever catches passwordResetLimiter's
      // own 429 (error.code === 'RATE_LIMITED', see lib/server.js) or a
      // genuine network failure reaching our own backend, so those two get
      // their own distinct message instead of collapsing into one.
      if (statusEl) {
        statusEl.classList.add('is-error');
        statusEl.setAttribute('role', 'alert');
        statusEl.textContent =
          error.code === 'RATE_LIMITED'
            ? 'Espera un momento antes de solicitar otro correo.'
            : 'No pudimos procesar el envío en este momento. Inténtalo nuevamente.';
      }
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.textContent = LanguagePair.t('authSendLink', learningPathState.bridgeLanguage);
      }
    }
  });

  document.getElementById('usernameOnboardingForm')?.addEventListener('submit', async (event) => {
    event.preventDefault();
    const input = document.getElementById('onboardingUsername');
    const statusEl = document.getElementById('onboardingUsernameStatus');
    const rawUsername = input?.value || '';
    const submitBtn = event.target.querySelector('button[type="submit"]');
    if (submitBtn) submitBtn.disabled = true;
    try {
      const usernameOk = await ensureUsernameAvailableForSubmit(
        'onboardingUsername',
        'onboardingUsernameStatus'
      );
      if (!usernameOk) return;

      await postJson('/api/profile/username', { username: rawUsername.trim() }, { auth: true });
      closeUsernameOnboarding();
      showHomeToast('Nombre de usuario guardado.');
    } catch (error) {
      if (error.code === 'USERNAME_NOT_AVAILABLE') {
        setUsernameStatus(
          'onboardingUsername',
          statusEl,
          'unavailable',
          window.AndergoUsernameRules?.normalizeUsername(rawUsername) || '',
          'Este nombre de usuario ya no está disponible. Elige otro.'
        );
        input?.focus();
        return;
      }
      if (statusEl) {
        renderUsernameStatus(statusEl, 'error', error.message || 'No se pudo guardar el nombre de usuario.');
      }
    } finally {
      if (submitBtn) submitBtn.disabled = false;
    }
  });

  document.querySelectorAll('[data-password-toggle]').forEach((toggleBtn) => {
    toggleBtn.addEventListener('click', () => {
      const target = document.getElementById(toggleBtn.dataset.passwordToggle);
      if (!target) return;
      const showing = target.type === 'text';
      target.type = showing ? 'password' : 'text';
      toggleBtn.setAttribute('aria-label', showing ? 'Mostrar contraseña' : 'Ocultar contraseña');
      toggleBtn.textContent = showing ? '👁' : '🙈';
    });
  });

  setupUsernameAvailabilityCheck('signupUsername', 'signupUsernameStatus');
  setupUsernameAvailabilityCheck('onboardingUsername', 'onboardingUsernameStatus');
  setupPasswordStrengthMeter('signupPassword', 'signupPasswordStrength');
}

// Single source of truth for each username field's real-time state - keyed
// by inputId so the signup and onboarding fields (which share this same
// logic) don't interfere with each other. Every reader (the status <p>, the
// submit handler) reads from here instead of re-deriving anything from the
// DOM, so the UI can never show "available" and "not available" at once.
// Possible statuses: idle | checking | available | unavailable | invalid | error.
const usernameCheckState = new Map();

const USERNAME_STATUS_MESSAGES = {
  checking: 'Comprobando disponibilidad…',
  available: (username) => `"${username}" está disponible.`,
  unavailable: 'Este nombre de usuario no está disponible.',
  error: 'No se pudo comprobar la disponibilidad. Intenta de nuevo.'
};

// Exactly one message, exactly one color class - never both is-available
// and is-error, and never a leftover message from a previous state.
function renderUsernameStatus(statusEl, status, message) {
  if (!statusEl) return;
  statusEl.classList.remove('is-available', 'is-error');
  statusEl.textContent = message || '';
  if (status === 'available') {
    statusEl.classList.add('is-available');
  } else if (status === 'unavailable' || status === 'invalid' || status === 'error') {
    statusEl.classList.add('is-error');
  }
}

function setUsernameStatus(inputId, statusEl, status, normalizedUsername, message) {
  const entry = usernameCheckState.get(inputId) || {};
  entry.status = status;
  entry.normalizedUsername = normalizedUsername;
  usernameCheckState.set(inputId, entry);
  renderUsernameStatus(statusEl, status, message);
}

// The actual GET /api/auth/username-available call, factored out of the
// debounced input handler so submit-time re-validation (see
// ensureUsernameAvailableForSubmit) can trigger the exact same check
// on demand instead of trusting a possibly-stale visual state.
async function queryUsernameAvailability(inputId, statusEl, rawValue) {
  const entry = usernameCheckState.get(inputId) || {};
  if (entry.abortController) entry.abortController.abort();

  const abortController = new AbortController();
  const thisToken = (entry.requestToken || 0) + 1;
  entry.abortController = abortController;
  entry.requestToken = thisToken;
  usernameCheckState.set(inputId, entry);

  try {
    const response = await fetch(
      `${backendBaseUrl}/api/auth/username-available?u=${encodeURIComponent(rawValue)}`,
      { signal: abortController.signal }
    );
    const data = await response.json().catch(() => ({}));

    // A newer keystroke (or a submit-time re-check) already superseded this
    // one - ignore it even if it happens to resolve after the newer one did.
    const current = usernameCheckState.get(inputId);
    if (!current || current.requestToken !== thisToken) return;

    if (!response.ok || !data.ok) {
      setUsernameStatus(inputId, statusEl, 'invalid', '', data.message || 'Nombre de usuario no válido.');
      return;
    }
    const status = data.available ? 'available' : 'unavailable';
    setUsernameStatus(
      inputId,
      statusEl,
      status,
      data.normalizedUsername,
      status === 'available'
        ? USERNAME_STATUS_MESSAGES.available(data.normalizedUsername)
        : USERNAME_STATUS_MESSAGES.unavailable
    );
  } catch (error) {
    if (error?.name === 'AbortError') return;
    const current = usernameCheckState.get(inputId);
    if (!current || current.requestToken !== thisToken) return;
    setUsernameStatus(inputId, statusEl, 'error', '', USERNAME_STATUS_MESSAGES.error);
  }
}

// Debounced (450ms) availability check - purely advisory (the note under
// the field already says so): the partial unique index on
// username_normalized is the real, final authority, this only avoids
// making the student wait until they submit the whole form to find out
// their pick is invalid or already taken. Format is checked locally first
// (via the rules shared with the server) so an obviously-malformed value
// never even reaches the network.
function setupUsernameAvailabilityCheck(inputId, statusId) {
  const input = document.getElementById(inputId);
  const statusEl = document.getElementById(statusId);
  const rules = window.AndergoUsernameRules;
  if (!input || !statusEl || !rules) return;

  usernameCheckState.set(inputId, { status: 'idle', normalizedUsername: '' });
  let debounceId = null;

  input.addEventListener('input', () => {
    if (debounceId) window.clearTimeout(debounceId);
    const rawValue = input.value;

    if (!rawValue.trim()) {
      setUsernameStatus(inputId, statusEl, 'idle', '', '');
      return;
    }

    const formatCheck = rules.validateUsernameFormat(rawValue);
    if (!formatCheck.valid) {
      setUsernameStatus(inputId, statusEl, 'invalid', '', formatCheck.message);
      return;
    }

    setUsernameStatus(
      inputId,
      statusEl,
      'checking',
      rules.normalizeUsername(rawValue),
      USERNAME_STATUS_MESSAGES.checking
    );
    debounceId = window.setTimeout(() => {
      queryUsernameAvailability(inputId, statusEl, rawValue);
    }, 450);
  });
}

// Re-validates format, then confirms with the server one last time before
// letting the form submit - never trusts the visual "available" state alone
// (it could be stale if the student clicked submit mid-debounce, or never
// triggered an input event at all, e.g. browser autofill).
async function ensureUsernameAvailableForSubmit(inputId, statusId) {
  const input = document.getElementById(inputId);
  const statusEl = document.getElementById(statusId);
  const rules = window.AndergoUsernameRules;
  if (!input || !statusEl || !rules) return false;

  const rawValue = input.value;
  const formatCheck = rules.validateUsernameFormat(rawValue);
  if (!formatCheck.valid) {
    setUsernameStatus(inputId, statusEl, 'invalid', '', formatCheck.message);
    input.focus();
    return false;
  }

  const normalizedUsername = rules.normalizeUsername(rawValue);
  const state = usernameCheckState.get(inputId);
  if (state?.status !== 'available' || state.normalizedUsername !== normalizedUsername) {
    await queryUsernameAvailability(inputId, statusEl, rawValue);
  }

  const freshState = usernameCheckState.get(inputId);
  if (freshState?.status === 'available' && freshState.normalizedUsername === normalizedUsername) {
    return true;
  }
  input.focus();
  return false;
}

// Client-side-only signal (never the source of truth for whether a
// password is "good enough" - Supabase Auth's own password policy is what
// actually enforces that) - just gives the student quick visual feedback.
function setupPasswordStrengthMeter(inputId, statusId) {
  const input = document.getElementById(inputId);
  const statusEl = document.getElementById(statusId);
  if (!input || !statusEl) return;

  input.addEventListener('input', () => {
    const value = input.value;
    if (!value) {
      statusEl.textContent = '';
      statusEl.className = 'password-strength';
      return;
    }
    let score = 0;
    if (value.length >= 8) score += 1;
    if (value.length >= 12) score += 1;
    if (/[a-z]/.test(value) && /[A-Z]/.test(value)) score += 1;
    if (/\d/.test(value)) score += 1;
    if (/[^a-zA-Z0-9]/.test(value)) score += 1;

    const levels = [
      { label: 'Muy débil', className: 'is-weak' },
      { label: 'Débil', className: 'is-weak' },
      { label: 'Aceptable', className: 'is-fair' },
      { label: 'Buena', className: 'is-good' },
      { label: 'Fuerte', className: 'is-strong' },
      { label: 'Muy fuerte', className: 'is-strong' }
    ];
    const level = levels[Math.min(score, levels.length - 1)];
    statusEl.textContent = level.label;
    statusEl.className = `password-strength ${level.className}`;
  });
}

let lastSignupEmail = '';
let resendOtpCooldownId = null;

// "a******@correo.com" - first character of the local part kept, everything
// else (local part and domain) masked, per the requested UI copy. Falls back
// to the raw string if it doesn't look like an email at all.
function maskEmail(email) {
  const match = /^(.)([^@]*)@(.+)$/.exec(email || '');
  if (!match) return email || '';
  const [, first, rest, domain] = match;
  return `${first}${'*'.repeat(Math.max(rest.length, 1))}@${domain}`;
}

function getOtpDigitInputs() {
  return Array.from(document.querySelectorAll('#otpInputRow .otp-digit'));
}

function getOtpCode() {
  return getOtpDigitInputs()
    .map((input) => input.value.trim())
    .join('');
}

function clearOtpDigits() {
  const inputs = getOtpDigitInputs();
  inputs.forEach((input) => (input.value = ''));
  inputs[0]?.focus();
}

function setResendOtpCooldown(seconds) {
  const button = document.getElementById('resendOtpBtn');
  if (!button) return;
  if (resendOtpCooldownId) window.clearInterval(resendOtpCooldownId);

  let remaining = seconds;
  button.disabled = true;
  button.textContent = `Reenviar código (${remaining}s)`;
  resendOtpCooldownId = window.setInterval(() => {
    remaining -= 1;
    if (remaining <= 0) {
      window.clearInterval(resendOtpCooldownId);
      resendOtpCooldownId = null;
      button.disabled = false;
      button.textContent = 'Reenviar código';
      return;
    }
    button.textContent = `Reenviar código (${remaining}s)`;
  }, 1000);
}

// source distinguishes the two ways this same panel gets shown:
//  - 'register' (default): right after signUp(), account has no password to
//    lose track of, heading reassures "Verifica tu cuenta".
//  - 'login-unconfirmed': an *existing* account with a correct password hit
//    EMAIL_NOT_CONFIRMED at login (see the loginForm handler below) - the
//    heading instead reads "Tu cuenta está pendiente de verificación." per
//    spec, since this isn't a brand-new signup.
let signupPendingSource = 'register';

function showSignupPending(email, { source = 'register' } = {}) {
  lastSignupEmail = email;
  signupPendingSource = source;
  const fields = document.querySelector('#signupForm .signup-fields');
  const pending = document.getElementById('signupPending');
  const verifyStep = document.getElementById('verifyAccountStep');
  const verifySuccess = document.getElementById('verifyAccountSuccess');
  const statusEl = document.getElementById('otpStatus');
  const headingEl = document.getElementById('verifyAccountHeading');
  if (fields) fields.hidden = true;
  if (headingEl) {
    headingEl.textContent =
      source === 'login-unconfirmed'
        ? 'Tu cuenta está pendiente de verificación.'
        : 'Verifica tu cuenta';
  }
  if (pending) {
    pending.hidden = false;
    const messageEl = pending.querySelector('.signup-pending-message');
    if (messageEl) {
      messageEl.textContent = `Te enviamos un código de 6 dígitos a ${maskEmail(email)}. Revisa también la carpeta de spam.`;
    }
  }
  if (verifyStep) verifyStep.hidden = false;
  if (verifySuccess) verifySuccess.hidden = true;
  if (statusEl) {
    statusEl.textContent = '';
    statusEl.classList.remove('is-error');
  }
  clearOtpDigits();
  setResendOtpCooldown(60);
}

function resetSignupPending() {
  const fields = document.querySelector('#signupForm .signup-fields');
  const pending = document.getElementById('signupPending');
  if (fields) fields.hidden = false;
  if (pending) pending.hidden = true;
  if (resendOtpCooldownId) {
    window.clearInterval(resendOtpCooldownId);
    resendOtpCooldownId = null;
  }
  // Whenever the editable fields come back into view (fresh modal open,
  // "Volver al inicio", or "Cambiar correo"), always start from step 1 -
  // never leave the student stranded on the password step with no visible
  // way back to it.
  goToSignupStep(1, { focus: false });
}

// Which half of #signupForm is currently visible - the account-info fields
// (step 1) or the password fields (step 2). Reset to 1 by resetSignupPending
// above, advanced/rewound only via goToSignupStep below.
let signupStep = 1;

function goToSignupStep(step, { focus = true } = {}) {
  signupStep = step;
  const step1El = document.getElementById('signupStep1');
  const step2El = document.getElementById('signupStep2');
  if (step1El) step1El.hidden = step !== 1;
  if (step2El) step2El.hidden = step !== 2;
  document.querySelectorAll('#signupStepIndicator .step-dot').forEach((dot) => {
    dot.classList.toggle('active', Number(dot.dataset.stepDot) === step);
  });
  const labelEl = document.getElementById('signupStepLabel');
  if (labelEl) labelEl.textContent = `Paso ${step} de 2`;
  if (!focus) return;
  if (step === 1) {
    document.getElementById('signupUsername')?.focus();
  } else {
    document.getElementById('signupPassword')?.focus();
  }
}

// Step 1 -> step 2: confirms the account-info fields are valid (and the
// username still available) but never calls Supabase here - account
// creation only ever happens from the step-2 submit handler below.
async function handleSignupContinue() {
  if (signupStep !== 1) return;
  const usernameInput = document.getElementById('signupUsername');
  const emailInput = document.getElementById('signupEmail');
  const continueBtn = document.getElementById('signupContinueBtn');
  if (!usernameInput || !emailInput || continueBtn?.disabled) return;

  if (!emailInput.checkValidity()) {
    emailInput.reportValidity();
    emailInput.focus();
    return;
  }
  if (!usernameInput.checkValidity()) {
    usernameInput.reportValidity();
    usernameInput.focus();
    return;
  }

  if (continueBtn) continueBtn.disabled = true;
  try {
    const usernameOk = await ensureUsernameAvailableForSubmit(
      'signupUsername',
      'signupUsernameStatus'
    );
    if (!usernameOk) return;
    goToSignupStep(2);
  } finally {
    if (continueBtn) continueBtn.disabled = false;
  }
}

document.getElementById('signupContinueBtn')?.addEventListener('click', handleSignupContinue);

document.getElementById('signupBackBtn')?.addEventListener('click', () => {
  goToSignupStep(1);
});

// Enter should always drive whichever step is currently visible instead of
// the browser's own implicit-submission pick (unreliable once one step's
// button is hidden) - scoped to .signup-fields so it never fires for Enter
// inside the separate OTP-verification step further down this same form.
document.querySelector('#signupForm .signup-fields')?.addEventListener('keydown', (event) => {
  if (event.key !== 'Enter' || event.target.tagName === 'BUTTON') return;
  event.preventDefault();
  if (signupStep === 1) {
    handleSignupContinue();
  } else {
    document.getElementById('signupForm')?.requestSubmit();
  }
});

// Auto-advance/backspace/paste across the 6 individual digit boxes - kept
// scoped to #otpInputRow so it never interferes with any other input on the
// page.
document.getElementById('otpInputRow')?.addEventListener('input', (event) => {
  const input = event.target.closest('.otp-digit');
  if (!input) return;
  input.value = input.value.replace(/\D/g, '').slice(0, 1);
  if (input.value) {
    const inputs = getOtpDigitInputs();
    const next = inputs[inputs.indexOf(input) + 1];
    next?.focus();
  }
});

document.getElementById('otpInputRow')?.addEventListener('keydown', (event) => {
  const input = event.target.closest('.otp-digit');
  if (!input) return;

  if (event.key === 'Enter') {
    event.preventDefault();
    document
      .querySelector('#verifyAccountStep [data-action="confirm-otp"]')
      ?.click();
    return;
  }

  if (event.key !== 'Backspace' || input.value) return;
  const inputs = getOtpDigitInputs();
  const prev = inputs[inputs.indexOf(input) - 1];
  prev?.focus();
});

document.getElementById('otpInputRow')?.addEventListener('paste', (event) => {
  const input = event.target.closest('.otp-digit');
  if (!input) return;
  event.preventDefault();
  const digits = (event.clipboardData?.getData('text') || '').replace(/\D/g, '').slice(0, 6);
  const inputs = getOtpDigitInputs();
  digits.split('').forEach((digit, index) => {
    if (inputs[index]) inputs[index].value = digit;
  });
  (inputs[digits.length] || inputs[inputs.length - 1])?.focus();
});

document.getElementById('signupPending')?.addEventListener('click', async (event) => {
  const button = event.target.closest('[data-action]');
  if (!button) return;

  if (button.dataset.action === 'go-to-login') {
    resetSignupPending();
    openModal('login');
    // Carry the email over (never the password) so the student doesn't
    // have to retype it - it's the same address they just registered with.
    const loginIdentifierInput = document.getElementById('loginIdentifier');
    if (loginIdentifierInput) loginIdentifierInput.value = lastSignupEmail;
    return;
  }

  if (button.dataset.action === 'change-email') {
    if (signupPendingSource === 'login-unconfirmed') {
      // This account already exists - "changing" the email here means going
      // back to the login form to try a different identifier, not editing a
      // signup form that was never filled in for this flow.
      resetSignupPending();
      openModal('login');
      const loginIdentifierInput = document.getElementById('loginIdentifier');
      loginIdentifierInput?.focus();
      loginIdentifierInput?.select();
    } else {
      // Fresh signup: keep the username/password already typed, just let
      // them correct the email address before re-submitting.
      resetSignupPending();
      const emailInput = document.getElementById('signupEmail');
      emailInput?.focus();
      emailInput?.select();
    }
    return;
  }

  if (button.dataset.action === 'confirm-otp') {
    const statusEl = document.getElementById('otpStatus');
    const code = getOtpCode();
    if (!/^\d{6}$/.test(code)) {
      if (statusEl) {
        statusEl.textContent = LanguagePair.t('authEnterCode', learningPathState.bridgeLanguage);
        statusEl.classList.add('is-error');
      }
      return;
    }

    button.disabled = true;
    if (statusEl) {
      statusEl.textContent = '';
      statusEl.classList.remove('is-error');
    }
    try {
      const response = await fetch(`${backendBaseUrl}/api/auth/verify-otp`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: lastSignupEmail, token: code, purpose: 'signup' })
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok || !data.ok) {
        throw new Error(data.message || 'El código no es válido.');
      }

      const verifyStep = document.getElementById('verifyAccountStep');
      const verifySuccess = document.getElementById('verifyAccountSuccess');
      if (verifyStep) verifyStep.hidden = true;
      if (verifySuccess) verifySuccess.hidden = false;
    } catch (error) {
      if (statusEl) {
        statusEl.textContent = error.message || 'El código no es válido.';
        statusEl.classList.add('is-error');
      }
      clearOtpDigits();
    } finally {
      button.disabled = false;
    }
    return;
  }

  if (button.dataset.action === 'resend-otp') {
    // idle -> sending -> sent | rate-limited | error (spec §4) - button text
    // itself carries the "sending" state; the other three only ever differ
    // in otpStatus's text, never a second indicator.
    button.disabled = true;
    const originalLabel = button.textContent;
    button.textContent = 'Enviando…';
    const statusEl = document.getElementById('otpStatus');
    if (statusEl) statusEl.classList.remove('is-error');
    try {
      const response = await fetch(`${backendBaseUrl}/api/auth/resend-otp`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: lastSignupEmail })
      });
      // Same neutral-response design as /api/auth/resend-confirmation - the
      // backend never distinguishes "sent" from "no such pending account" in
      // its own message, so only the rate-limit (429) case gets a different,
      // safe-to-show status here.
      if (response.status === 429) {
        if (statusEl) statusEl.textContent = 'Espera un momento antes de solicitar otro correo.';
      } else {
        if (statusEl)
          statusEl.textContent = LanguagePair.t('authCodeResent', learningPathState.bridgeLanguage);
      }
    } catch (error) {
      console.warn('Could not resend OTP', error);
      if (statusEl) {
        statusEl.textContent = 'No pudimos procesar el envío en este momento. Inténtalo nuevamente.';
        statusEl.classList.add('is-error');
      }
    } finally {
      button.textContent = originalLabel;
      clearOtpDigits();
      setResendOtpCooldown(60);
    }
  }
});

// "Seguridad de la cuenta" - TOTP enrollment (#security). factorId is only
// ever held here in memory for the duration of one enroll attempt; nothing
// about the factor (secret, QR, codes) is ever sent anywhere but Supabase.
let pendingEnrollFactorId = null;

function renderSecurityActivateButton() {
  const status = document.getElementById('securityMfaStatus');
  if (!status) return;
  status.innerHTML = `
    <p>No tienes activada la verificación en dos pasos.</p>
    <button type="button" class="primary-btn" data-security-action="start-enroll">
      Activar verificación en dos pasos
    </button>
  `;
}

function renderSecurityActiveState(factor) {
  const status = document.getElementById('securityMfaStatus');
  if (!status) return;
  status.innerHTML = `
    <p>✅ Verificación en dos pasos activada${factor.friendlyName ? ` (${escapeHtml(factor.friendlyName)})` : ''}.</p>
    <button type="button" class="secondary-btn" data-security-action="unenroll" data-factor-id="${escapeHtml(factor.id)}">
      Desactivar
    </button>
  `;
}

async function loadSecurityStatus() {
  const status = document.getElementById('securityMfaStatus');
  const enrollFlow = document.getElementById('mfaEnrollFlow');
  if (enrollFlow) enrollFlow.hidden = true;
  if (!authStatus.session?.access_token) {
    if (status)
      status.innerHTML = '<p class="skill-graph-empty">Inicia sesión para ver tu seguridad.</p>';
    return;
  }
  if (status) status.innerHTML = '<p class="skill-graph-empty">Cargando estado de seguridad…</p>';

  try {
    const response = await fetch(`${backendBaseUrl}/api/mfa/factors`, { headers: authHeaders() });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error('Request failed');
    const activeFactor = (data.totp || []).find((factor) => factor.status === 'verified');
    if (activeFactor) renderSecurityActiveState(activeFactor);
    else renderSecurityActivateButton();
  } catch (error) {
    console.warn('Could not load security status', error);
    if (status)
      status.innerHTML = `<p class="skill-graph-empty">${escapeHtml(LanguagePair.t('securityLoadFailed', learningPathState.bridgeLanguage))}</p>`;
  }
}

function resetMfaEnrollFlow() {
  pendingEnrollFactorId = null;
  const enrollFlow = document.getElementById('mfaEnrollFlow');
  if (enrollFlow) enrollFlow.hidden = true;
  const codeInput = document.getElementById('mfaEnrollCode');
  if (codeInput) codeInput.value = '';
  const enrollStatus = document.getElementById('mfaEnrollStatus');
  if (enrollStatus) {
    enrollStatus.textContent = '';
    enrollStatus.classList.remove('is-error');
  }
}

document.getElementById('securityMfaStatus')?.addEventListener('click', async (event) => {
  const button = event.target.closest('[data-security-action]');
  if (!button) return;

  if (button.dataset.securityAction === 'start-enroll') {
    button.disabled = true;
    try {
      const response = await fetch(`${backendBaseUrl}/api/mfa/totp/enroll`, {
        method: 'POST',
        headers: authHeaders()
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok || !data.ok) {
        throw new Error(data.message || 'No se pudo iniciar la activación.');
      }
      pendingEnrollFactorId = data.factorId;
      const qrWrap = document.getElementById('mfaQrWrap');
      if (qrWrap) {
        qrWrap.innerHTML = `<img src="${escapeHtml(data.qrCode)}" alt="Código QR para configurar tu aplicación autenticadora" width="200" height="200" />`;
      }
      const manualKey = document.getElementById('mfaManualKey');
      if (manualKey) manualKey.textContent = data.secret || '';
      const enrollFlow = document.getElementById('mfaEnrollFlow');
      if (enrollFlow) enrollFlow.hidden = false;
      document.getElementById('mfaEnrollCode')?.focus();
    } catch (error) {
      showHomeToast(error.message || 'No se pudo iniciar la activación.');
    } finally {
      button.disabled = false;
    }
    return;
  }

  if (button.dataset.securityAction === 'unenroll') {
    if (!window.confirm('¿Desactivar la verificación en dos pasos?')) return;
    button.disabled = true;
    try {
      const response = await fetch(`${backendBaseUrl}/api/mfa/totp/unenroll`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...authHeaders() },
        body: JSON.stringify({ factorId: button.dataset.factorId })
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok || !data.ok) throw new Error('No se pudo desactivar.');
      showHomeToast('Verificación en dos pasos desactivada.');
      await loadSecurityStatus();
    } catch (error) {
      showHomeToast(error.message || 'No se pudo desactivar. Intenta de nuevo.');
      button.disabled = false;
    }
  }
});

document.getElementById('mfaCancelEnrollBtn')?.addEventListener('click', async () => {
  if (pendingEnrollFactorId) {
    try {
      await fetch(`${backendBaseUrl}/api/mfa/totp/unenroll`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...authHeaders() },
        body: JSON.stringify({ factorId: pendingEnrollFactorId })
      });
    } catch (error) {
      console.warn('Could not clean up cancelled enrollment', error);
    }
  }
  resetMfaEnrollFlow();
});

document.getElementById('mfaVerifyEnrollBtn')?.addEventListener('click', async () => {
  const codeInput = document.getElementById('mfaEnrollCode');
  const enrollStatus = document.getElementById('mfaEnrollStatus');
  const code = codeInput?.value.trim() || '';
  const button = document.getElementById('mfaVerifyEnrollBtn');

  if (!pendingEnrollFactorId) {
    resetMfaEnrollFlow();
    return;
  }
  if (!/^\d{6}$/.test(code)) {
    if (enrollStatus) {
      enrollStatus.textContent = LanguagePair.t('authEnterCode', learningPathState.bridgeLanguage);
      enrollStatus.classList.add('is-error');
    }
    return;
  }

  if (button) button.disabled = true;
  if (enrollStatus) {
    enrollStatus.textContent = '';
    enrollStatus.classList.remove('is-error');
  }

  try {
    const challengeResponse = await fetch(`${backendBaseUrl}/api/mfa/totp/challenge`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...authHeaders() },
      body: JSON.stringify({ factorId: pendingEnrollFactorId })
    });
    const challengeData = await challengeResponse.json().catch(() => ({}));
    if (!challengeResponse.ok || !challengeData.challengeId) {
      throw new Error(challengeData.message || 'No se pudo generar el desafío de verificación.');
    }

    const verifyResponse = await fetch(`${backendBaseUrl}/api/mfa/totp/verify`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...authHeaders() },
      body: JSON.stringify({
        factorId: pendingEnrollFactorId,
        challengeId: challengeData.challengeId,
        code
      })
    });
    const verifyData = await verifyResponse.json().catch(() => ({}));
    if (!verifyResponse.ok || !verifyData.ok) {
      throw new Error(verifyData.message || 'Código incorrecto. Intenta de nuevo.');
    }

    // Verifying a brand new factor invalidates the account's other sessions
    // (Supabase's own enroll() docs) - swap in the new tokens this call
    // returns instead of keeping the ones from before enrollment.
    if (verifyData.session) saveSession(authStatus.user, verifyData.session);

    resetMfaEnrollFlow();
    showHomeToast('Verificación en dos pasos activada.');
    await loadSecurityStatus();
  } catch (error) {
    if (enrollStatus) {
      enrollStatus.textContent = error.message || 'Código incorrecto. Intenta de nuevo.';
      enrollStatus.classList.add('is-error');
    }
  } finally {
    if (button) button.disabled = false;
  }
});

const learningPathState = {
  lessons: [],
  // Thematic units for the current language+level (e.g. English A1's 12
  // units). Empty for every language/level that doesn't have units yet -
  // see hasUnits() below, which every unit-aware render path is gated on.
  units: [],
  activeSlug: null,
  // id of the unit currently selected in the unit accordion / skill library
  // (english-a1-unit-02, etc.) - null for languages/levels without units
  // (see hasUnits()). This is the single source of truth for "which unit is
  // open"; selectUnit() below is the only place that should write it.
  unitId: null,
  language: 'english',
  // The learner's bridge/interface language (see the comment near
  // LanguagePair above) - was a separate learningPathState.bridgeLanguage global,
  // folded in here so bridge/target/level all live on one object.
  bridgeLanguage: 'spanish',
  level: 'A1',
  // 'bilingual' | 'direct' (spec §3) - derived from bridgeLanguage/language,
  // never written to directly. See syncLearningMode(), called after every
  // assignment to either field. Initialized consistently with the two
  // defaults above (spanish !== english -> bilingual).
  learningMode: 'bilingual',
  // The seventh activity in every unit is Verbos. Its scored attempts live
  // in user_unit_verb_progress (separate from course_lessons because the
  // conjugator/practice engine is shared across units).
  verbProgressByUnit: {},
  // Practice results recorded locally as the student answers, keyed by
  // lesson slug -> exercise index -> { selectedOption } | { practiced: true }.
  // Only used to drive the UI (which exercises are left, when "Completar"
  // unlocks); the backend re-grades everything from scratch on submit and
  // never trusts this client-side copy.
  exerciseResults: {}
};

// True only for language/level combos that have thematic units (English A1
// today). Every unit-aware render path (unit accordion, skill libraries)
// branches on this so every other language/level keeps today's exact
// single-lesson-per-skill behavior untouched.
function hasUnits() {
  return learningPathState.units.length > 0;
}

// Listening biblioteca: only these units have an official recording
// registered in public.lesson_audio (verified against the real "lesson-audio"
// Storage bucket, not assumed) - see docs/audio-architecture.md. Every other
// unit's Listening activity is left out of the biblioteca entirely rather
// than shown as a dead link. Extend this map (never remove existing entries)
// as further levels/languages get real audio recorded and registered.
function getSkillActivities(skill) {
  const activities = learningPathState.lessons
    .filter((item) => item.skill === skill)
    .sort((a, b) => {
      const unitA = learningPathState.units.find((u) => u.id === a.unitId);
      const unitB = learningPathState.units.find((u) => u.id === b.unitId);
      return (unitA?.order ?? 0) - (unitB?.order ?? 0);
    });

  return activities;
}

const UNIT_LEARNING_SEQUENCE = ['reading', 'listening', 'vocabulary', 'grammar', 'speaking', 'writing'];

function unitSkillOrder(skill) {
  const index = UNIT_LEARNING_SEQUENCE.indexOf(String(skill || '').toLowerCase());
  return index === -1 ? UNIT_LEARNING_SEQUENCE.length : index;
}

function getUnitActivities(unitId) {
  return learningPathState.lessons
    .filter((item) => item.unitId === unitId)
    .sort((a, b) => unitSkillOrder(a.skill) - unitSkillOrder(b.skill) || (a.orderIndex || 0) - (b.orderIndex || 0));
}

function getUnitProgressMetrics(unitId) {
  const activities = getUnitActivities(unitId);
  const verbProgress = learningPathState.verbProgressByUnit[unitId] || null;
  const completedCount =
    activities.filter((item) => item.completed).length +
    (verbProgress?.status === 'completed' ? 1 : 0);
  const total = activities.length + 1;
  const scoreTotal =
    activities.reduce((sum, item) => sum + Number(item.bestScore || 0), 0) +
    Number(verbProgress?.bestScore || 0);
  return {
    activities,
    verbProgress,
    completedCount,
    total,
    progressPercent: total ? Math.round(scoreTotal / total) : 0
  };
}

function getLessonGamificationContext(lesson) {
  if (!lesson) return {};
  const metrics = lesson.unitId ? getUnitProgressMetrics(lesson.unitId) : null;
  return {
    skill: lesson.skill || '',
    unitId: lesson.unitId || '',
    unitCompleted: Boolean(metrics && metrics.total > 0 && metrics.completedCount === metrics.total)
  };
}

function getCourseProgressMetrics() {
  const lessonScoreTotal = learningPathState.lessons.reduce(
    (sum, item) => sum + Number(item.bestScore || 0),
    0
  );
  const verbRows = learningPathState.units.map(
    (unit) => learningPathState.verbProgressByUnit[unit.id] || null
  );
  const total = learningPathState.lessons.length + learningPathState.units.length;
  const completedCount =
    learningPathState.lessons.filter((item) => item.completed).length +
    verbRows.filter((item) => item?.status === 'completed').length;
  const verbScoreTotal = verbRows.reduce((sum, item) => sum + Number(item?.bestScore || 0), 0);
  return {
    total,
    completedCount,
    progressPercent: total ? Math.round((lessonScoreTotal + verbScoreTotal) / total) : 0
  };
}

function renderUnitSequenceStepsHtml(unitId, currentSkill = '') {
  const activities = getUnitActivities(unitId);
  const steps = activities
    .map((lesson, index) => {
      const isCurrent = lesson.skill === currentSkill;
      const state = lesson.completed ? 'completed' : isCurrent ? 'current' : lesson.locked ? 'locked' : 'available';
      return `
        <button type="button" class="unit-sequence-step unit-sequence-step--${state}" data-sequence-skill="${escapeHtml(lesson.skill)}" data-lesson-slug="${escapeHtml(lesson.slug)}" ${isCurrent ? 'aria-current="step"' : ''}>
          <span class="unit-sequence-number">${lesson.completed ? '✓' : index + 1}</span>
          <span>${escapeHtml(getSkillLabel(lesson.skill))}</span>
        </button>
      `;
    })
    .join('');
  const verbsNumber = activities.length + 1;
  const verbProgress = learningPathState.verbProgressByUnit[unitId];
  const verbState =
    currentSkill === 'verbs'
      ? 'current'
      : verbProgress?.status === 'completed'
        ? 'completed'
        : 'available';
  return `${steps}
    <button type="button" class="unit-sequence-step unit-sequence-step--verbs unit-sequence-step--${verbState}" data-sequence-skill="verbs" ${currentSkill === 'verbs' ? 'aria-current="step"' : ''}>
      <span class="unit-sequence-number">${verbProgress?.status === 'completed' ? '✓' : verbsNumber}</span>
      <span>Verbos</span>
    </button>`;
}

function openUnitSequenceStep(skill, lessonSlug = '') {
  if (skill === 'verbs') {
    showView('verbs');
    const verbLanguage = ['english', 'french', 'spanish'].includes(learningPathState.language)
      ? learningPathState.language
      : 'english';
    history.pushState(null, '', `#verbs/${verbLanguage}/list`);
    renderUnitVerbContext();
    return;
  }
  if (skill === 'dialogue' && lessonSlug) {
    const dialogueLesson = learningPathState.lessons.find((item) => item.slug === lessonSlug);
    const speakingLesson =
      learningPathState.lessons.find(
        (item) => item.unitId === dialogueLesson?.unitId && item.skill === 'speaking'
      ) || dialogueLesson;
    if (!speakingLesson) return;
    setActiveLesson(speakingLesson.slug);
    speakingViewState = {
      lessonSlug: speakingLesson.slug,
      mode: 'dialogue',
      guidedTurnIndex: 0
    };
    showView('speaking');
    renderSkillView('speaking');
    updateLearnHash('speaking');
    return;
  }
  if (!SKILL_VIEWS.includes(skill) || !lessonSlug) return;
  setActiveLesson(lessonSlug);
  showView(skill);
  renderSkillView(skill);
  updateLearnHash(skill);
}

function wireUnitSequence(container) {
  container?.querySelectorAll('.unit-sequence-step').forEach((button) => {
    button.addEventListener('click', () =>
      openUnitSequenceStep(button.dataset.sequenceSkill, button.dataset.lessonSlug || '')
    );
  });
}

function renderSkillUnitSequence(section, lesson) {
  section.querySelector('.unit-learning-sequence')?.remove();
  if (!lesson?.unitId) return;
  const content = section.querySelector('.skill-view-content');
  if (!content) return;
  const nav = document.createElement('nav');
  nav.className = 'unit-learning-sequence';
  nav.setAttribute('aria-label', 'Secuencia de aprendizaje de la unidad');
  nav.innerHTML = `
    <div class="unit-sequence-heading">
      <strong>Ruta de esta unidad</strong>
      <span>Avanza de la comprensión a la producción.</span>
    </div>
    <div class="unit-sequence-steps">${renderUnitSequenceStepsHtml(lesson.unitId, lesson.skill)}</div>
  `;
  content.before(nav);
  wireUnitSequence(nav);
}

function renderUnitVerbContext() {
  const section = document.getElementById('verbs');
  if (!section) return;
  section.querySelector('.unit-verbs-context')?.remove();
  const unit = learningPathState.units.find((item) => item.id === learningPathState.unitId);
  if (!unit) return;
  const banner = document.createElement('div');
  banner.className = 'unit-verbs-context';
  banner.innerHTML = `
    <div>
      <span>Verbos dentro de tu ruta</span>
      <strong>${escapeHtml(unit.title)}</strong>
      <p>Explora y practica verbos para completar esta unidad. Después continúa con la siguiente actividad disponible.</p>
    </div>
    <button type="button" class="secondary-btn unit-verbs-return-btn">← Volver a la unidad</button>
  `;
  section.querySelector('.section-heading')?.after(banner);
  banner.querySelector('.unit-verbs-return-btn')?.addEventListener('click', () => {
    const activities = getUnitActivities(unit.id);
    const target = [...activities].reverse().find((item) => !item.locked) || activities[0];
    if (target) openUnitSequenceStep(target.skill, target.slug);
    else showView('learn');
  });
}

// Single place that writes activeSlug - keeps it in sync with unitId so a
// lesson picked from anywhere (unit accordion, skill library) always moves
// learningPathState.unitId to that lesson's unit too. Before this, only
// activeSlug was tracked; nothing recorded which unit was selected, so
// selecting a unit with no lesson click left every unit-scoped fallback
// (getActiveLearningLesson, getNextRecommendedLesson, the accordion's
// open/closed state) still resolving against whatever unit came first.
function setActiveLesson(slug) {
  learningPathState.activeSlug = slug || '';
  if (slug) {
    const lesson = learningPathState.lessons.find((item) => item.slug === slug);
    if (lesson?.unitId) learningPathState.unitId = lesson.unitId;
  }
}

// Wired to unit accordion header clicks. See the comment on
// renderLessonWorkspace/renderUnitOverviewCard for why switching units
// clears activeSlug (rather than auto-picking a lesson) instead of leaving
// the content panel pointed at the previous unit's lesson.
function selectUnit(unitId, options = {}) {
  if (!unitId) return;
  const changingUnit = unitId !== learningPathState.unitId;
  learningPathState.unitId = unitId;
  // Switching units lands on that unit's overview panel (see
  // renderUnitOverviewCard) rather than auto-opening one of its lessons -
  // the previously active lesson (if any) belonged to the old unit, so it
  // can't stay open here. Picking a specific activity to practice is a
  // separate, deliberate action (clicking it directly, or the overview's
  // own "Comenzar/Continuar/Repasar unidad" button).
  if (changingUnit) {
    learningPathState.activeSlug = '';
  }
  if (options.render !== false) renderLearningPath();
}

function getExerciseProgress(lesson) {
  const total = lesson.exercises?.length || 0;
  const results = learningPathState.exerciseResults[lesson.slug] || {};
  const attempted = Object.keys(results).length;
  return { total, attempted, allAttempted: total === 0 || attempted >= total };
}

const languageDisplayNames = {
  english: 'English',
  spanish: 'Español',
  french: 'Français',
  italian: 'Italiano',
  german: 'Deutsch',
  portuguese: 'Português',
  japanese: '日本語',
  chinese: '中文 (简体)',
  ai: 'AI Tutor'
};

// ---------------------------------------------------------------------
// Pronunciation (Web Speech API) - shared by every flashcard/pronounceable
// element across every target language, never hardcoded to English. Locale
// is resolved from the current learningPathState.language (or an explicit
// override) at call time, not baked into this function.
// ---------------------------------------------------------------------

// es-419 (Latin American Spanish) rather than es-ES, matching this app's
// actual Spanish content/audience. Must match lib/server.js's
// SUPPORTED_SPEECH_LOCALES and src/js/translator-languages.js's own locale
// per entry (Traductor-specific list) - kept in sync by hand, same pattern
// this app already uses across its language tables.
const LANGUAGE_LOCALES = {
  english: 'en-US',
  french: 'fr-FR',
  spanish: 'es-419',
  italian: 'it-IT',
  german: 'de-DE',
  portuguese: 'pt-BR',
  japanese: 'ja-JP',
  chinese: 'zh-CN'
};

function supportsSpeech() {
  return typeof window !== 'undefined' && 'speechSynthesis' in window;
}

function getPronunciationLocale(language = learningPathState.language) {
  return LANGUAGE_LOCALES[language] || 'en-US';
}

// Always cancels any in-flight utterance first, so two quick taps (or
// tapping a second card while the first is still speaking) never overlap.
// No-ops silently - no thrown errors, no console noise - when the browser
// doesn't support speechSynthesis at all. `onEnd` (optional) fires once,
// whether playback finished normally or errored out - used by the AI
// Tutor's voice controls to know when to reset their Stop/Repetir state
// (flashcards don't need it and don't pass it).
//
// onStart/onBoundary/onPause/onResume (optional, additive - existing callers
// that don't pass them see zero behavior change) wire straight to the
// utterance's own events, for the Tutor's word-highlight sync
// (requestTutorSpeech below). onBoundary receives the raw SpeechSynthesis
// event so the caller can read event.charIndex itself - this function has
// no opinion on word/sentence granularity, that's the caller's job.
// Returns the utterance so a caller can compare it against whatever's
// current later (e.g. to ignore a stale onboundary from a cancelled/replaced
// utterance), though nothing here requires that.
function speakText(text, { locale, rate = 1, onEnd, onStart, onBoundary, onPause, onResume } = {}) {
  if (!supportsSpeech() || !text) {
    onEnd?.();
    return null;
  }
  try {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = locale || getPronunciationLocale();
    utterance.rate = rate;
    if (onEnd) {
      utterance.onend = onEnd;
      utterance.onerror = onEnd;
    }
    if (onStart) utterance.onstart = onStart;
    if (onBoundary) utterance.onboundary = onBoundary;
    if (onPause) utterance.onpause = onPause;
    if (onResume) utterance.onresume = onResume;
    window.speechSynthesis.speak(utterance);
    return utterance;
  } catch {
    /* speechSynthesis unavailable/misbehaving - the card stays usable without audio */
    onEnd?.();
    return null;
  }
}

// English A1 speaks slightly slower (0.86x) and French A1 slightly slower
// still (0.82x) per spec; every other language/level defaults to normal
// rate unless a card sets its own pronunciationRate.
function getDefaultPronunciationRate(language = learningPathState.language, level = learningPathState.level) {
  if (language === 'english' && level === 'A1') return 0.86;
  if (language === 'french' && level === 'A1') return 0.82;
  return 1;
}

// ---------------------------------------------------------------------
// Reading Text-to-Speech player - reads a whole reading (title + every
// paragraph, concatenated) aloud continuously, independent of speakText()
// above (which flashcards/AI Tutor keep using unchanged, fire-and-forget,
// one utterance at a time). This section owns its own
// SpeechSynthesisUtterance lifecycle because it needs pause/resume,
// segment-level rewind, and a persistent playing/paused state that
// speakText() was never designed for.
//
// Text is split into short sentence-ish "segments" (see
// splitReadingSentences()) rather than spoken as one giant utterance,
// because the Web Speech API has no seek: "rewind 5 seconds" is
// approximated by cancelling the current utterance and restarting
// playback from whichever earlier segment's estimated start time is
// closest to (elapsed - 5s). Durations are estimated from word count at
// the current rate, not measured - there is no reliable cross-browser
// timing signal from speechSynthesis itself.
// ---------------------------------------------------------------------

const READING_RATE_PRESETS = { slow: 0.75, normal: 0.95 };

// Best-effort classification of common OS/browser TTS voices as
// masculine/feminine, curated by us - never inferred automatically from
// a voice's name (a name alone isn't a reliable gender signal). Any
// voice not in this list falls back to a neutral "Voz 1"/"Voz 2" label.
const KNOWN_VOICE_GENDERS = {
  Samantha: 'female',
  Victoria: 'female',
  Karen: 'female',
  Moira: 'female',
  Tessa: 'female',
  Alex: 'male',
  Daniel: 'male',
  Fred: 'male',
  'Google US English': 'female',
  'Google UK English Female': 'female',
  'Google UK English Male': 'male',
  'Google français': 'female',
  'Google español': 'female',
  'Microsoft David - English (United States)': 'male',
  'Microsoft Zira - English (United States)': 'female',
  'Microsoft Mark - English (United States)': 'male',
  'Microsoft Hortense - French (France)': 'female',
  'Microsoft Paul - French (France)': 'male',
  'Microsoft Helena - Spanish (Spain)': 'female',
  'Microsoft Pablo - Spanish (Spain)': 'male',
  Amelie: 'female',
  Thomas: 'male',
  Monica: 'female',
  Jorge: 'male',
  Paulina: 'female',
  Juan: 'male'
};

function getStoredReadingVoiceName(language) {
  try {
    return localStorage.getItem(`andergo_voice_${language}`) || '';
  } catch {
    return '';
  }
}

function setStoredReadingVoiceName(language, name) {
  try {
    localStorage.setItem(`andergo_voice_${language}`, name || '');
  } catch {
    /* private-mode/unavailable localStorage - voice choice just won't persist */
  }
}

function getStoredReadingRate(language) {
  try {
    const raw = localStorage.getItem(`andergo_rate_${language}`);
    return raw === 'slow' || raw === 'normal' ? raw : null;
  } catch {
    return null;
  }
}

function setStoredReadingRate(language, rateKey) {
  try {
    localStorage.setItem(`andergo_rate_${language}`, rateKey);
  } catch {
    /* ignore */
  }
}

// Whether the Tutor's spoken replies should start playing as soon as they're
// ready, with no extra click - defaults to on (missing key = never set, or
// private-mode/localStorage unavailable) since that's the natural fit for a
// voice conversation (see requestTutorSpeech's { auto } path and
// sendTutorMessage's post-stream trigger).
function getTutorAutoplayPref() {
  try {
    const raw = localStorage.getItem('andergo_tutor_autoplay');
    return raw === null ? true : raw === 'true';
  } catch {
    return true;
  }
}

function setTutorAutoplayPref(enabled) {
  try {
    localStorage.setItem('andergo_tutor_autoplay', enabled ? 'true' : 'false');
  } catch {
    /* private-mode/unavailable localStorage - preference just won't persist */
  }
}

// Exact-locale match first (e.g. es-ES), falling back to any voice that
// shares the bare language prefix (e.g. any "es-*") - mirrors
// getPronunciationLocale()'s per-language defaults above.
function getReadingVoicesForLocale(locale) {
  if (!supportsSpeech()) return [];
  const all = window.speechSynthesis.getVoices() || [];
  const prefix = (locale || '').split('-')[0];
  const exact = all.filter((voice) => voice.lang === locale);
  const pool = exact.length ? exact : all.filter((voice) => voice.lang?.startsWith(prefix));
  const seen = new Set();
  return pool.filter((voice) => {
    if (seen.has(voice.name)) return false;
    seen.add(voice.name);
    return true;
  });
}

function splitReadingSentences(text) {
  if (!text) return [];
  const matches = text.match(/[^.!?]+[.!?]+(?:\s+|$)|[^.!?]+$/g);
  return (matches || [text]).map((sentence) => sentence.trim()).filter(Boolean);
}

function estimateReadingSegmentSeconds(text, rate) {
  const words = text.trim().split(/\s+/).filter(Boolean).length || 1;
  const wordsPerSecond = 2.6 * (rate || 1);
  return Math.max(0.6, words / wordsPerSecond);
}

// Single source of truth for "what paragraphs does this reading show" -
// used both to render the full text on screen (renderReadingView) and to
// build the spoken script below (buildReadingSegments), so the sentence
// spans a student sees and the segments the TTS player walks through are
// always in exact lockstep (same source, same split logic). Readings that
// already carry lesson.reading.parts (an array of paragraph-length
// strings) use those directly; everything else falls back to splitting
// the single-block lesson.reading.text/lesson.description on blank lines.
function getReadingParagraphs(lesson) {
  const parts = lesson.reading?.parts;
  if (Array.isArray(parts) && parts.length) return parts;
  return (lesson.reading?.text || lesson.description || '')
    .split(/\n+/)
    .map((p) => p.trim())
    .filter(Boolean);
}

// Builds the full spoken script for a reading: title, then every
// paragraph's sentences in order (never comprehension questions, ordering
// events, vocabulary, or Spanish translations - those aren't part of
// lesson.reading.parts/text). The reading is always spoken and shown as one
// continuous text - there is no paginated "part" concept anymore, so a
// segment's only positional info is its own index within the flat list.
function buildReadingSegments(lesson, rate) {
  const paragraphs = getReadingParagraphs(lesson);
  const segments = [];
  let cursor = 0;
  const addSegment = (text) => {
    const trimmed = text.trim();
    if (!trimmed) return;
    const duration = estimateReadingSegmentSeconds(trimmed, rate);
    segments.push({
      text: trimmed,
      segmentIndex: segments.length,
      estimatedStartSeconds: cursor,
      estimatedDurationSeconds: duration
    });
    cursor += duration;
  };
  if (lesson.title) addSegment(lesson.title);
  paragraphs.forEach((paragraph) => {
    splitReadingSentences(paragraph).forEach((sentence) => addSegment(sentence));
  });
  return { segments, totalDurationSeconds: cursor };
}

function findReadingSegmentIndexAtTime(segments, timeSeconds) {
  for (let i = segments.length - 1; i >= 0; i--) {
    if (segments[i].estimatedStartSeconds <= timeSeconds) return i;
  }
  return 0;
}

function formatReadingTime(totalSeconds) {
  const safe = Number.isFinite(totalSeconds) ? Math.max(0, totalSeconds) : 0;
  const minutes = Math.floor(safe / 60);
  const seconds = Math.floor(safe % 60);
  return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
}

// ---------------------------------------------------------------------
// Engine abstraction (kept deliberately thin) so the player above never
// has to change shape when a Premium neural engine is wired in later -
// only this factory's `engine: 'azure'` branch would gain a real
// implementation (an HTMLAudioElement over a server-generated clip from
// lib/ttsService.js, with real seek/duration). No Azure credentials are
// configured yet, so that branch intentionally falls back to `browser`
// rather than doing nothing.
// ---------------------------------------------------------------------
function createReadingAudioPlayer({ engine = 'browser', language, voice, rate } = {}) {
  const resolvedEngine = engine === 'azure' ? 'browser' : engine;
  return {
    engine: resolvedEngine,
    speakSegment(segment, { onStart, onEnd, onError } = {}) {
      if (!supportsSpeech() || !segment) {
        onEnd?.();
        return null;
      }
      const utterance = new SpeechSynthesisUtterance(segment.text);
      utterance.lang = getPronunciationLocale(language);
      utterance.rate = rate || 1;
      if (voice) utterance.voice = voice;
      utterance.onstart = () => onStart?.();
      utterance.onend = () => onEnd?.();
      utterance.onerror = () => onError?.();
      window.speechSynthesis.speak(utterance);
      return utterance;
    }
  };
}

// Singleton controller - only one reading can ever be "the" audio
// playing at a time (see attach()/teardown()). Exposes exactly the
// function names the product spec calls for: playReading, pauseReading,
// resumeReading, rewindReading(seconds), stopReading, changeReadingVoice,
// changeReadingRate - plus attach/teardown/setHandlers/getSnapshot for
// renderReadingView to wire itself up to.
const readingSpeechPlayer = (() => {
  const PAUSE_WATCHDOG_MS = 350;

  let state = 'idle'; // idle | playing | paused | stopped | completed | error
  let lesson = null;
  let language = null;
  let segments = [];
  let totalDurationSeconds = 0;
  let currentSegmentIndex = 0;
  let elapsedBeforeCurrentSegment = 0;
  let segmentStartedAt = 0;
  let rateKey = 'normal';
  let voices = [];
  let voiceIndex = 0;
  let progressTimer = null;
  let playbackToken = 0; // bumped on every intentional interrupt, so stale utterance callbacks (cancel(), then a new one starts) never act twice
  let onUpdate = null;

  function currentVoice() {
    return voices[voiceIndex] || null;
  }

  function rateValue() {
    return READING_RATE_PRESETS[rateKey] || READING_RATE_PRESETS.normal;
  }

  function voiceDisplayLabel() {
    const voice = currentVoice();
    if (!voice) return '';
    const gender = KNOWN_VOICE_GENDERS[voice.name];
    if (gender === 'female') return 'Voz femenina';
    if (gender === 'male') return 'Voz masculina';
    return `Voz ${voiceIndex + 1}`;
  }

  function loadVoices() {
    const locale = getPronunciationLocale(language);
    voices = getReadingVoicesForLocale(locale);
    const storedName = getStoredReadingVoiceName(language);
    const storedIndex = storedName ? voices.findIndex((voice) => voice.name === storedName) : -1;
    voiceIndex = storedIndex >= 0 ? storedIndex : 0;
  }

  function clearTimer() {
    if (progressTimer) {
      clearInterval(progressTimer);
      progressTimer = null;
    }
  }

  function startTimer() {
    clearTimer();
    progressTimer = setInterval(emitUpdate, 250);
  }

  function snapshot() {
    const seg = segments[currentSegmentIndex];
    const withinSegment =
      state === 'playing' && seg
        ? Math.min((performance.now() - segmentStartedAt) / 1000, seg.estimatedDurationSeconds)
        : 0;
    const elapsedSeconds = Math.min(totalDurationSeconds, elapsedBeforeCurrentSegment + withinSegment);
    const progressPct =
      totalDurationSeconds > 0 ? Math.min(100, Math.round((elapsedSeconds / totalDurationSeconds) * 100)) : 0;
    return {
      state,
      currentSegmentIndex,
      elapsedSeconds,
      totalDurationSeconds,
      progressPct,
      rateKey,
      voiceLabel: voiceDisplayLabel(),
      voiceName: currentVoice()?.name || '',
      canChangeVoice: voices.length > 1
    };
  }

  function emitUpdate() {
    onUpdate?.(snapshot());
  }

  function finish() {
    state = 'completed';
    clearTimer();
    currentSegmentIndex = segments.length;
    elapsedBeforeCurrentSegment = totalDurationSeconds;
    emitUpdate();
  }

  function speakCurrentSegment() {
    const seg = segments[currentSegmentIndex];
    if (!seg) {
      finish();
      return;
    }
    if (!supportsSpeech()) {
      state = 'error';
      clearTimer();
      emitUpdate();
      return;
    }
    window.speechSynthesis.cancel();
    playbackToken += 1;
    const myToken = playbackToken;
    const player = createReadingAudioPlayer({
      engine: 'browser',
      language,
      voice: currentVoice(),
      rate: rateValue()
    });
    segmentStartedAt = performance.now();
    player.speakSegment(seg, {
      onEnd: () => {
        if (myToken !== playbackToken || state !== 'playing') return;
        elapsedBeforeCurrentSegment += seg.estimatedDurationSeconds;
        currentSegmentIndex += 1;
        speakCurrentSegment();
      },
      onError: () => {
        if (myToken !== playbackToken || state !== 'playing') return;
        state = 'error';
        clearTimer();
        emitUpdate();
      }
    });
    startTimer();
    emitUpdate();
  }

  function attach(lessonToAttach, languageKey) {
    const isSameLesson = lesson && lesson.slug === lessonToAttach.slug && language === languageKey;
    if (isSameLesson) return;
    teardown();
    lesson = lessonToAttach;
    language = languageKey;
    rateKey = getStoredReadingRate(language) || 'normal';
    loadVoices();
    const built = buildReadingSegments(lesson, rateValue());
    segments = built.segments;
    totalDurationSeconds = built.totalDurationSeconds;
    currentSegmentIndex = 0;
    elapsedBeforeCurrentSegment = 0;
    state = segments.length ? 'idle' : 'error';
  }

  function setHandlers(handlers) {
    onUpdate = handlers?.onUpdate || null;
  }

  function playReading() {
    if (!supportsSpeech() || !segments.length) return;
    if (state === 'paused') {
      resumeReading();
      return;
    }
    if (state === 'completed' || state === 'stopped' || state === 'error') {
      currentSegmentIndex = 0;
      elapsedBeforeCurrentSegment = 0;
    }
    window.speechSynthesis.cancel(); // only one reading (or flashcard/tutor) utterance is ever active at a time
    state = 'playing';
    speakCurrentSegment();
  }

  function pauseReading() {
    if (state !== 'playing' || !supportsSpeech()) return;
    const seg = segments[currentSegmentIndex];
    elapsedBeforeCurrentSegment += Math.min(
      (performance.now() - segmentStartedAt) / 1000,
      seg?.estimatedDurationSeconds || 0
    );
    state = 'paused';
    clearTimer();
    window.speechSynthesis.pause();
    emitUpdate();
    setTimeout(() => {
      // Some mobile browsers silently ignore pause() and keep talking -
      // if so, force a hard stop; resumeReading() re-speaks the frozen
      // segment from its start either way, so nothing is lost.
      if (state === 'paused' && window.speechSynthesis.speaking && !window.speechSynthesis.paused) {
        playbackToken += 1;
        window.speechSynthesis.cancel();
      }
    }, PAUSE_WATCHDOG_MS);
  }

  function resumeReading() {
    if (state !== 'paused' || !supportsSpeech()) return;
    if (window.speechSynthesis.paused) {
      state = 'playing';
      segmentStartedAt = performance.now();
      window.speechSynthesis.resume();
      startTimer();
      emitUpdate();
      setTimeout(() => {
        // resume() sometimes silently no-ops (notably iOS Safari) - detect
        // that and fall back to re-speaking the current segment.
        if (state === 'playing' && !window.speechSynthesis.speaking) {
          speakCurrentSegment();
        }
      }, PAUSE_WATCHDOG_MS);
    } else {
      // pause() never actually took effect earlier (the watchdog above
      // already cancelled it) - nothing to resume, so re-speak the
      // current segment from its start.
      state = 'playing';
      speakCurrentSegment();
    }
  }

  function stopReading() {
    playbackToken += 1;
    state = 'stopped';
    clearTimer();
    if (supportsSpeech()) window.speechSynthesis.cancel();
    currentSegmentIndex = 0;
    elapsedBeforeCurrentSegment = 0;
    emitUpdate();
  }

  // Rewinding is approximated by jumping to whichever earlier segment's
  // estimated start time is closest to (elapsed - seconds) - the Web
  // Speech API has no real seek, so this can land a sentence or two off
  // from an exact 5s offset, especially right after a rate change (see
  // rebuildDurationsFromCurrentSegment). This only ever moves the audio
  // cursor; it never touches which text is visible on screen.
  function rewindReading(seconds = 5) {
    if (!segments.length) return;
    const wasPlaying = state === 'playing';
    const seg = segments[currentSegmentIndex];
    const currentElapsed =
      elapsedBeforeCurrentSegment +
      (wasPlaying ? Math.min((performance.now() - segmentStartedAt) / 1000, seg?.estimatedDurationSeconds || 0) : 0);
    const targetTime = Math.max(0, currentElapsed - seconds);
    const targetIndex = findReadingSegmentIndexAtTime(segments, targetTime);
    playbackToken += 1;
    if (supportsSpeech()) window.speechSynthesis.cancel();
    currentSegmentIndex = targetIndex;
    elapsedBeforeCurrentSegment = segments[targetIndex].estimatedStartSeconds;
    if (wasPlaying) {
      state = 'playing';
      speakCurrentSegment();
    } else {
      clearTimer();
      emitUpdate();
    }
  }

  function changeReadingVoice() {
    if (voices.length < 2) return;
    voiceIndex = (voiceIndex + 1) % voices.length;
    setStoredReadingVoiceName(language, currentVoice()?.name || '');
    if (state === 'playing') {
      playbackToken += 1;
      if (supportsSpeech()) window.speechSynthesis.cancel();
      speakCurrentSegment();
    } else {
      emitUpdate();
    }
  }

  function rebuildDurationsFromCurrentSegment() {
    let cursor = elapsedBeforeCurrentSegment;
    for (let i = currentSegmentIndex; i < segments.length; i++) {
      segments[i].estimatedStartSeconds = cursor;
      segments[i].estimatedDurationSeconds = estimateReadingSegmentSeconds(segments[i].text, rateValue());
      cursor += segments[i].estimatedDurationSeconds;
    }
    totalDurationSeconds = cursor;
  }

  function changeReadingRate(nextRateKey) {
    if (!READING_RATE_PRESETS[nextRateKey] || nextRateKey === rateKey) return;
    rateKey = nextRateKey;
    setStoredReadingRate(language, rateKey);
    rebuildDurationsFromCurrentSegment();
    if (state === 'playing') {
      playbackToken += 1;
      if (supportsSpeech()) window.speechSynthesis.cancel();
      speakCurrentSegment();
    } else {
      emitUpdate();
    }
  }

  function teardown() {
    playbackToken += 1;
    clearTimer();
    if (supportsSpeech()) window.speechSynthesis.cancel();
    state = 'idle';
    lesson = null;
    language = null;
    segments = [];
    totalDurationSeconds = 0;
    currentSegmentIndex = 0;
    elapsedBeforeCurrentSegment = 0;
    voices = [];
    voiceIndex = 0;
    onUpdate = null;
  }

  if (supportsSpeech()) {
    // Chrome (desktop especially) returns an empty voice list until this
    // fires once, asynchronously, after page load.
    window.speechSynthesis.addEventListener('voiceschanged', () => {
      if (lesson) {
        loadVoices();
        emitUpdate();
      }
    });
  }

  return {
    isSupported: supportsSpeech,
    attach,
    teardown,
    setHandlers,
    getSnapshot: snapshot,
    playReading,
    pauseReading,
    resumeReading,
    rewindReading,
    stopReading,
    changeReadingVoice,
    changeReadingRate
  };
})();

function escapeHtml(value = '') {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

// ---------------------------------------------------------------------
// Tutor reply Markdown cleanup - aiTutorService.js's TUTOR_INSTRUCTIONS ask
// the model not to use Markdown, but never trust that: both functions below
// always escape HTML first and only ever re-introduce <strong>/<ul>/<ol>/
// <li>/<br> themselves - never raw innerHTML from an un-escaped source, and
// never any attribute a reply could hide a script or handler in.
// ---------------------------------------------------------------------
const TUTOR_BULLET_LINE = /^[-*]\s+(.*)$/;
const TUTOR_NUMBERED_LINE = /^\d+[.)]\s+(.*)$/;
const TUTOR_HEADING_LINE = /^#{1,6}\s+(.*)$/;

// **bold** becomes <strong> on already-escaped text; any leftover single/
// double asterisk (unterminated bold, or plain emphasis) is dropped rather
// than turned into <em> - the spec's ask is "no visible asterisks", not
// "support italics". Safe on a partial/still-streaming line: an
// unterminated `**` just has no closing match yet, so it stays plain text
// (then gets stripped) until the closing `**` arrives.
function formatTutorInlineHtml(escapedLine) {
  return escapedLine.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>').replace(/\*/g, '');
}

function matchTutorListLine(trimmedLine) {
  const bulletMatch = trimmedLine.match(TUTOR_BULLET_LINE);
  if (bulletMatch) return { type: 'ul', content: bulletMatch[1] };
  const numberedMatch = trimmedLine.match(TUTOR_NUMBERED_LINE);
  if (numberedMatch) return { type: 'ol', content: numberedMatch[1] };
  return null;
}

// Renders a raw Tutor reply into safe HTML for the response card: escapes
// HTML, then converts **bold**, "- "/"* " bullet lists and "1. " numbered
// lists into real <strong>/<ul>/<ol>/<li>, strips leading #/##/... heading
// markers (kept as a plain line - the spec asks for no long headings, not a
// differently-styled one), and preserves blank-line paragraph breaks as
// <br>. Used for both the live-streaming message body and the final text.
function renderTutorMarkdownHtml(rawText) {
  const lines = String(rawText || '').split('\n');
  const htmlParts = [];
  let listBuffer = [];
  let listType = null;

  const flushList = () => {
    if (!listBuffer.length) return;
    htmlParts.push(`<${listType}>${listBuffer.join('')}</${listType}>`);
    listBuffer = [];
    listType = null;
  };

  lines.forEach((line) => {
    const trimmed = line.trim();
    if (!trimmed) {
      flushList();
      return;
    }

    const listLine = matchTutorListLine(trimmed);
    if (listLine) {
      if (listType && listType !== listLine.type) flushList();
      listType = listLine.type;
      listBuffer.push(`<li>${formatTutorInlineHtml(escapeHtml(listLine.content))}</li>`);
      return;
    }

    flushList();
    const headingMatch = trimmed.match(TUTOR_HEADING_LINE);
    const content = headingMatch ? headingMatch[1] : trimmed;
    htmlParts.push(formatTutorInlineHtml(escapeHtml(content)));
  });
  flushList();

  return htmlParts.join('<br>');
}

// Plain-text counterpart of renderTutorMarkdownHtml(), for the text actually
// sent to TTS (messageEl.dataset.ttsText / /api/speech/synthesize) -
// speechSynthesis must never read "asterisk asterisk Pattern asterisk
// asterisk" aloud. Strips the same markers but returns readable text, not
// HTML - list bullets/numbers are dropped (nothing reads "dash" aloud
// either) and lines are joined with a space, relying on each line's own
// sentence punctuation for natural pauses.
function cleanTutorTextForSpeech(rawText) {
  return String(rawText || '')
    .split('\n')
    .map((line) => {
      const trimmed = line.trim();
      if (!trimmed) return '';
      const listLine = matchTutorListLine(trimmed);
      const headingMatch = trimmed.match(TUTOR_HEADING_LINE);
      const content = listLine?.content ?? headingMatch?.[1] ?? trimmed;
      return content.replace(/\*\*([^*]+)\*\*/g, '$1').replace(/\*/g, '');
    })
    .filter(Boolean)
    .join(' ')
    .replace(/\s+/g, ' ')
    .trim();
}

// Must match the marker lib/aiTutorService.js's TUTOR_INSTRUCTIONS forbids
// the model from emitting at all - the Tutor is strictly monolingual in L2
// now (no L1 support block), but a provider can still ignore instructions,
// so this is a client-side backstop: strip the marker and anything after it
// (and any other "[[TAG]]"-shaped internal marker) before the reply is ever
// shown or spoken. The real fix lives in the prompt, not here.
const TUTOR_L1_SUPPORT_MARKER = '[[L1_SUPPORT]]';
const TUTOR_INTERNAL_MARKER_RE = /\[\[[A-Z0-9_]+\]\]/g;

// Tolerates a marker that's only partially streamed in so far (e.g. the
// chunk boundary landed mid-marker) by trimming any trailing prefix of the
// marker from the visible text until the rest of it arrives - same
// "safe on a partial/still-streaming line" tolerance formatTutorInlineHtml
// already relies on for **bold**.
function stripPartialL1Marker(text) {
  for (let len = TUTOR_L1_SUPPORT_MARKER.length - 1; len > 0; len--) {
    if (text.endsWith(TUTOR_L1_SUPPORT_MARKER.slice(0, len))) {
      return text.slice(0, text.length - len);
    }
  }
  return text;
}

// Sanitizes a raw tutor reply into the L2-only text that should actually be
// shown/spoken: cuts off everything from [[L1_SUPPORT]] onward (a provider
// that ignores the "never emit this" instruction shouldn't be able to leak
// L1 text into the UI), strips any partially-streamed marker prefix, and
// removes any other internal "[[TAG]]"-shaped marker. Legitimate foreign
// words the Tutor is explaining as part of the L2 lesson are left untouched -
// this only ever removes app-generated marker syntax, never prose.
function sanitizeTutorReplyText(text) {
  const raw = String(text || '');
  const idx = raw.indexOf(TUTOR_L1_SUPPORT_MARKER);
  const cut = idx === -1 ? stripPartialL1Marker(raw) : raw.slice(0, idx);
  return cut.replace(TUTOR_INTERNAL_MARKER_RE, '').trim();
}

// Returns the message wrapper <div> (not just its body <p>) so streaming
// callers (see sendTutorMessage()) can keep updating its text as chunks
// arrive, and so tutor voice controls (renderTutorVoiceControls()) have
// somewhere to attach once the reply has finished streaming.
function appendTutorMessage(container, role, text, { isError = false } = {}) {
  if (!container) return null;
  const message = document.createElement('div');
  message.className = `tutor-message tutor-message--${role}${isError ? ' tutor-message--error' : ''}`;

  const label = document.createElement('span');
  label.className = 'tutor-message-label';
  label.textContent = role === 'user' ? 'Tú' : '🤖 Tutor IA ANDERGO';

  const body = document.createElement('p');
  const isTutorReply = role === 'tutor' && !isError;
  // Only real Tutor replies go through the Markdown/marker cleanup - error
  // strings are our own plain text, never the model's, so they stay a
  // simple escape.
  const main = isTutorReply ? sanitizeTutorReplyText(text) : text;
  body.innerHTML = isTutorReply
    ? renderTutorMarkdownHtml(main)
    : escapeHtml(text).replace(/\n/g, '<br>');

  message.append(label, body);
  container.appendChild(message);
  container.scrollTop = container.scrollHeight;
  return message;
}

// Discreet inline status/paywall notice for the Tutor's monthly free-query
// cap (lib/usageLimitService.js, feature='tutor_query') - visually
// distinct from a normal tutor/user bubble (no "Tú"/"Tutor AI" label).
// `locked` reuses the same .premium-lock-box + .upgrade-btn pattern
// already used for locked lessons, so a full lockout looks consistent
// with the rest of the app's paywall UI instead of inventing a new one.
function appendTutorUsageNotice(container, message, { locked = false } = {}) {
  if (!container) return null;
  const notice = document.createElement('div');
  notice.className = `tutor-usage-notice${locked ? ' premium-lock-box' : ''}`;
  const text = document.createElement('p');
  text.textContent = message;
  notice.appendChild(text);
  if (locked) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'primary-btn upgrade-btn';
    btn.textContent = LanguagePair.t('premiumGetBtn', learningPathState.bridgeLanguage);
    notice.appendChild(btn);
  }
  container.appendChild(notice);
  container.scrollTop = container.scrollHeight;
  return notice;
}

// Updates an in-progress tutor message bubble's text (see appendTutorMessage's
// returned wrapper) as streamed chunks accumulate. Sanitizes on every update
// (see sanitizeTutorReplyText) so the visible body is always L2-only, even
// mid-stream.
function updateTutorMessageBody(messageEl, container, text) {
  if (!messageEl) return;
  const main = sanitizeTutorReplyText(text);
  const body = messageEl.querySelector('p');
  if (body) body.innerHTML = renderTutorMarkdownHtml(main);
  if (container) container.scrollTop = container.scrollHeight;
}

// ---------------------------------------------------------------------
// AI Tutor voice (Text-to-Speech on top of Cerebras/Groq/Gemini's text
// reply - see POST /api/speech/synthesize in lib/server.js). Two
// modalities: free browser speechSynthesis (via speakText() above) or
// Premium neural voice (an <audio> element playing a server-generated
// clip) - the server alone decides which one a given request gets back,
// based on the signed-in user's actual subscription state.
// ---------------------------------------------------------------------

// Whatever is currently audible for a tutor reply - at most one at a time,
// whether it's a speechSynthesis utterance or a neural <audio> clip -
// stopAllTutorAudio() always tears this down first, so starting any new
// playback (a different message, or the same one again) never overlaps
// with what was already playing.
let currentTutorAudio = { element: null, messageEl: null };

// One <audio> element reused for every neural tutor reply in the session,
// instead of a fresh `new Audio()` per message - avoids piling up media
// elements as the conversation grows and keeps the "only one thing plays at
// a time" rule (stopAllTutorAudio) working against a single, known element.
let sharedTutorAudioEl = null;
function getSharedTutorAudioElement() {
  if (!sharedTutorAudioEl) sharedTutorAudioEl = new Audio();
  return sharedTutorAudioEl;
}

// Browsers only allow <audio>.play() with sound once *some* play() call has
// happened synchronously inside a real user gesture on that element - once
// that's happened, later programmatic play() calls on the same element (e.g.
// requestTutorSpeech's auto-trigger, which runs well after the click, at the
// end of an async fetch chain) keep working for the rest of the session.
// Calling this at the very top of the Enviar click handler - before any
// `await` - is what makes the autoplay-after-reply flow actually audible
// instead of silently blocked; the attempt itself is wrapped so an empty/
// unsupported source here never surfaces as an error.
function primeTutorAudioForAutoplay() {
  const audio = getSharedTutorAudioElement();
  try {
    const playAttempt = audio.play();
    if (playAttempt?.catch) playAttempt.catch(() => {});
  } catch {
    /* ignore - this call only exists to register gesture-driven playback */
  }
  audio.pause();
}

// ---------------------------------------------------------------------
// Word-highlight sync (TTS reads aloud, the currently-spoken word/segment
// gets a visual highlight in the message bubble). Centralized state per
// spec §11 - activeMessageEl/activeTokens/activeWordIndex here play the
// role of "activeTutorMessageId/activeUtterance/activeCharIndex", scoped to
// this module instead of duplicated per message element.
//
// Only ever applies to the free browser speechSynthesis path
// (requestTutorSpeech below) - the separate Premium neural <audio> clip has
// no boundary-event equivalent and is out of scope here (spec: "no
// modificar la función Premium de conversación de audio a audio").
// ---------------------------------------------------------------------
let tutorHighlight = { messageEl: null, tokens: null, wordIndex: -1 };

// Splits `text` (the exact string handed to SpeechSynthesisUtterance - see
// requestTutorSpeech) into whitespace-separated tokens with [start, end)
// character offsets into that SAME string, so a SpeechSynthesisEvent's
// charIndex always falls inside exactly one token's range. Punctuation
// stays attached to its word (spec's own example: "You've" is one token),
// matching how a person would naturally read the sentence word by word.
function tokenizeTutorTextForHighlight(text) {
  const tokens = [];
  const re = /\S+/g;
  let match = re.exec(text);
  while (match) {
    tokens.push({ start: match.index, end: match.index + match[0].length, text: match[0] });
    match = re.exec(text);
  }
  return tokens;
}

// One <span class="tutor-word"> per token, escaped (spec §5: never insert
// raw model output as HTML) and joined with plain spaces (not wrapped in a
// span) so word-wrapping stays natural. This REPLACES the Markdown-rendered
// body (renderTutorMarkdownHtml) once a reply is complete and ready to be
// spoken - the trade-off (no more **bold**/line-break rendering in that one
// paragraph) is deliberate: spec §5 requires the exact string spoken and the
// exact string shown as spans to be the same one, and the model is already
// instructed to write in plain text with no Markdown, so this rarely gives
// up anything real.
function renderTutorHighlightSpansHtml(tokens) {
  return tokens
    .map((token, index) => `<span class="tutor-word" data-index="${index}">${escapeHtml(token.text)}</span>`)
    .join(' ');
}

// Called once a reply's final text is known (renderTutorVoiceControls, right
// after streaming ends) - swaps the bubble's rendered body for the
// tokenized span version and stashes the token list on the element itself
// (avoids re-tokenizing on every single onboundary event during playback).
// A no-op (keeps the Markdown-rendered body) if there's no ttsText yet or
// speech isn't supported at all, since spans only ever exist to be
// highlighted.
function prepareTutorMessageForHighlight(messageEl) {
  if (!supportsSpeech()) return;
  const body = messageEl.querySelector('p');
  const text = messageEl.dataset.ttsText || '';
  if (!body || !text) return;
  const tokens = tokenizeTutorTextForHighlight(text);
  if (!tokens.length) return;
  messageEl._tutorHighlightTokens = tokens;
  body.innerHTML = renderTutorHighlightSpansHtml(tokens);
}

function clearTutorHighlight() {
  if (tutorHighlight.messageEl) {
    tutorHighlight.messageEl.querySelector('.tutor-word.is-current')?.classList.remove('is-current');
  }
  tutorHighlight = { messageEl: null, tokens: null, wordIndex: -1 };
}

// Auto-follow the highlighted word (spec §8) - suppressed for a few seconds
// right after the student scrolls the conversation manually (see the
// capture-phase 'scroll' listener below), and skipped under
// prefers-reduced-motion in favor of an instant jump instead of a smooth
// one (spec §9), never skipped entirely - the student still needs to find
// the word.
let tutorAutoScrollSuppressedUntil = 0;
let tutorAutoScrollInProgress = false;

function scrollTutorWordIntoView(span) {
  if (Date.now() < tutorAutoScrollSuppressedUntil) return;
  const reduceMotion = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
  tutorAutoScrollInProgress = true;
  span.scrollIntoView({ block: 'nearest', behavior: reduceMotion ? 'auto' : 'smooth' });
  // Smooth scrolling fires its own 'scroll' events while it animates - this
  // window keeps the manual-scroll listener below from mistaking our own
  // scroll for the student's and immediately re-suppressing auto-follow.
  window.setTimeout(() => {
    tutorAutoScrollInProgress = false;
  }, 500);
}

// event.charIndex (from onboundary) maps to the token whose [start, end)
// contains it. Works unchanged whether the browser fires boundary per WORD
// or only per SENTENCE (spec §7 tiers A/B): a sentence-level charIndex still
// lands inside some word's range, it just jumps further between highlights -
// no separate code path needed for the coarser granularity. Tier C (no
// boundary events at all) needs no code here either: this function simply
// never gets called, so no highlight ever appears and playback is
// unaffected either way.
function setTutorHighlightWord(messageEl, tokens, charIndex) {
  let index = tokens.findIndex((t) => charIndex >= t.start && charIndex < t.end);
  if (index === -1) {
    // Defensive fallback for a charIndex that lands on inter-word
    // whitespace instead of inside a token - the last token that had
    // already started by this charIndex is still the "current" word.
    for (let i = tokens.length - 1; i >= 0; i -= 1) {
      if (tokens[i].start <= charIndex) {
        index = i;
        break;
      }
    }
  }
  if (index === -1 || (tutorHighlight.messageEl === messageEl && tutorHighlight.wordIndex === index)) return;

  messageEl.querySelector('.tutor-word.is-current')?.classList.remove('is-current');
  const span = messageEl.querySelector(`.tutor-word[data-index="${index}"]`);
  if (span) {
    span.classList.add('is-current');
    scrollTutorWordIntoView(span);
  }
  tutorHighlight = { messageEl, tokens, wordIndex: index };
}

// Capture phase so this sees scroll events from any descendant of
// .tutor-conversation (the 'scroll' event itself doesn't bubble) - both the
// main Tutor view and the drawer use this same class. Ignores our own
// auto-follow scrolls (tutorAutoScrollInProgress) so following the voice
// never looks like "the student scrolled, so stop following".
document.addEventListener(
  'scroll',
  (event) => {
    if (tutorAutoScrollInProgress) return;
    if (!event.target?.classList?.contains?.('tutor-conversation')) return;
    tutorAutoScrollSuppressedUntil = Date.now() + 3000;
  },
  true
);

function resetTutorVoiceButtons(messageEl) {
  const controls = messageEl?.querySelector('.tutor-voice-controls');
  if (!controls) return;
  const listenBtn = controls.querySelector('.tutor-voice-listen');
  const stopBtn = controls.querySelector('.tutor-voice-stop');
  const pauseBtn = controls.querySelector('.tutor-voice-pause');
  const rewindBtn = controls.querySelector('.tutor-voice-rewind');
  if (listenBtn) {
    listenBtn.disabled = false;
    if (listenBtn.dataset.played) listenBtn.textContent = '🔁 Repetir';
  }
  if (stopBtn) stopBtn.disabled = true;
  if (pauseBtn) {
    pauseBtn.disabled = true;
    pauseBtn.textContent = '⏸ Pausar';
  }
  // Rewind only ever makes sense for the neural <audio> path - speechSynthesis
  // has no seek API, so it stays hidden in browser-fallback mode (see
  // requestTutorSpeech, which sets messageEl.dataset.ttsMode on success).
  if (rewindBtn) {
    rewindBtn.disabled = true;
    rewindBtn.hidden = messageEl.dataset.ttsMode !== 'neural';
  }
}

// Pauses/resumes in place - never regenerates the audio (same clip/
// utterance, whether neural <audio> or the speechSynthesis fallback).
function toggleTutorVoicePause(messageEl) {
  if (!messageEl || currentTutorAudio.messageEl !== messageEl) return;
  const pauseBtn = messageEl.querySelector('.tutor-voice-pause');
  if (currentTutorAudio.element) {
    if (currentTutorAudio.element.paused) {
      currentTutorAudio.element.play();
      if (pauseBtn) pauseBtn.textContent = '⏸ Pausar';
    } else {
      currentTutorAudio.element.pause();
      if (pauseBtn) pauseBtn.textContent = '▶ Continuar';
    }
  } else if (supportsSpeech()) {
    if (window.speechSynthesis.paused) {
      window.speechSynthesis.resume();
      if (pauseBtn) pauseBtn.textContent = '⏸ Pausar';
      messageEl.classList.remove('is-tts-paused');
    } else {
      window.speechSynthesis.pause();
      if (pauseBtn) pauseBtn.textContent = '▶ Continuar';
      // Spec §6: "al pausar, conservar la palabra actual resaltada; mostrar
      // estado Pausado" - the highlighted word itself is untouched (nothing
      // here clears it), this class just gives it a paused look in CSS
      // (e.g. drop the pulse) instead of a separate status label.
      messageEl.classList.add('is-tts-paused');
    }
  }
}

// Neural <audio> only - speechSynthesis has no seek API (button stays
// hidden in that mode, see requestTutorSpeech/resetTutorVoiceButtons).
function rewindTutorVoice(seconds) {
  if (!currentTutorAudio.element) return;
  currentTutorAudio.element.currentTime = Math.max(0, currentTutorAudio.element.currentTime - seconds);
}

function stopAllTutorAudio() {
  if (supportsSpeech()) window.speechSynthesis.cancel();
  currentTutorAudio.element?.pause?.();
  if (currentTutorAudio.messageEl) {
    currentTutorAudio.messageEl.classList.remove('is-playing', 'is-tts-paused');
    resetTutorVoiceButtons(currentTutorAudio.messageEl);
  }
  currentTutorAudio = { element: null, messageEl: null };
  // Spec §6 ("al detener: cancelar speechSynthesis, eliminar resaltado") and
  // §11 ("no permitir dos utterances simultáneos") - every path that starts
  // a new utterance (Escuchar/Repetir on any message, speed change) already
  // calls this first, so the previous message's highlight never lingers
  // once a different/new one starts speaking.
  clearTutorHighlight();
}

// The controls row is injected only once the streamed reply has finished
// completely (see sendTutorMessage()'s SSE loop) - never mid-stream, so
// "Escuchar" can never read a partial/incomplete reply aloud. Hidden
// entirely (never rendered) when the browser has no speechSynthesis at all -
// mirrors the flashcard pronunciation feature's graceful-degradation rule.
function renderTutorVoiceControls(messageEl) {
  if (!supportsSpeech() || messageEl.querySelector('.tutor-voice-controls')) return;
  // The reply is fully known now (never mid-stream, see this function's own
  // header comment) - safe to swap the bubble to the highlightable
  // span version once, here, rather than re-tokenizing on every play.
  prepareTutorMessageForHighlight(messageEl);
  const controls = document.createElement('div');
  controls.className = 'tutor-voice-controls';
  controls.innerHTML = `
    <button type="button" class="tutor-voice-btn tutor-voice-listen" aria-label="Reproducir respuesta del tutor">🔊 Escuchar</button>
    <button type="button" class="tutor-voice-btn tutor-voice-pause" disabled aria-label="Pausar reproducción">⏸ Pausar</button>
    <button type="button" class="tutor-voice-btn tutor-voice-rewind" disabled hidden aria-label="Retroceder 5 segundos">⏪ 5s</button>
    <button type="button" class="tutor-voice-btn tutor-voice-stop" disabled aria-label="Detener reproducción">⏹ Detener</button>
    <div class="tutor-voice-speed-group" role="group" aria-label="Velocidad de voz">
      <button type="button" class="tutor-voice-speed-btn is-active" data-speed="normal" aria-label="Velocidad normal" aria-pressed="true">▶ Normal</button>
      <button type="button" class="tutor-voice-speed-btn" data-speed="slow" aria-label="Velocidad lenta" aria-pressed="false">🐢 Lenta</button>
    </div>
    <span class="tutor-voice-limit-message" role="status" aria-live="polite" hidden></span>
  `;
  messageEl.appendChild(controls);
}

// Called from the Escuchar/Repetir click handler, and also automatically
// right after a tutor reply finishes streaming when the "reproducir
// automáticamente" preference is on, or when the Premium hands-free
// conversation mode is active (see sendTutorMessage and getTutorAutoplayPref).
// Reads the reply aloud entirely client-side via the browser's own
// speechSynthesis (speakText) - no network call, no login requirement, no
// per-message/monthly limit: TTS is not a Premium feature and must never be
// artificially capped (distinct from the separate Premium hands-free
// "Conversar" audio-to-audio mode this same function also powers - that
// mode's Premium gate lives in handleTutorConversationToggleClick, not
// here). `auto: true` only changes how a blocked autoplay is reported.
// `onPlaybackEnd`, when given, always fires exactly once - on a normal end,
// a blocked autoplay, or a missing ttsText/unsupported browser - so a caller
// chaining off it (resumeTutorConversationListening) never waits forever on
// a turn that never actually produced audio.
function requestTutorSpeech(messageEl, { auto = false, onPlaybackEnd } = {}) {
  const controls = messageEl.querySelector('.tutor-voice-controls');
  const stopBtn = controls?.querySelector('.tutor-voice-stop');
  const pauseBtn = controls?.querySelector('.tutor-voice-pause');
  const listenBtn = controls?.querySelector('.tutor-voice-listen');
  const limitMsg = controls?.querySelector('.tutor-voice-limit-message');
  const speed = controls?.querySelector('.tutor-voice-speed-btn.is-active')?.dataset.speed || 'normal';
  const text = messageEl.dataset.ttsText || '';
  const locale = messageEl.dataset.ttsLocale || getPronunciationLocale();
  if (!text) {
    if (auto) console.warn('[Tutor] auto-play skipped: no ttsText on message element yet.');
    onPlaybackEnd?.();
    return;
  }

  // Always stops whatever was playing before (any earlier reply, or this
  // same one) - never two utterances overlapping.
  stopAllTutorAudio();
  if (limitMsg) limitMsg.hidden = true;
  messageEl.dataset.ttsMode = 'browser';

  const onEnd = () => {
    messageEl.classList.remove('is-playing', 'is-tts-paused');
    if (currentTutorAudio.messageEl === messageEl) currentTutorAudio = { element: null, messageEl: null };
    if (onPlaybackEnd) onPlaybackEnd();
    else if (tutorReplyEndsWithQuestion(text)) activateTutorMicAfterQuestion(messageEl);
    resetTutorVoiceButtons(messageEl);
    // Spec §6: "al terminar, eliminar resaltado después de una transición
    // breve; conservar el texto completo". The word spans (and their full
    // text) stay exactly as rendered - only the .is-current class goes,
    // and only after a short delay so the last word doesn't just vanish
    // the instant audio stops.
    if (tutorHighlight.messageEl === messageEl) {
      window.setTimeout(() => {
        if (tutorHighlight.messageEl === messageEl) clearTutorHighlight();
      }, 400);
    }
  };

  if (!supportsSpeech()) {
    if (auto) console.warn('[Tutor] auto-play skipped: speechSynthesis unsupported.');
    onEnd();
    if (limitMsg) {
      limitMsg.textContent = 'Este navegador no admite lectura en voz alta. Puedes continuar leyendo la respuesta.';
      limitMsg.hidden = false;
    }
    return;
  }

  // Repetir (same messageEl, already spoken once) must restart the
  // highlight from scratch (spec §6) - stopAllTutorAudio() above already
  // cleared any active highlight, so a fresh tokens list + wordIndex -1 is
  // exactly the right starting state whether this is the first play or a
  // repeat.
  const tokens = messageEl._tutorHighlightTokens || null;

  currentTutorAudio = { element: null, messageEl };
  speakText(text, {
    locale,
    rate: speed === 'slow' ? 0.75 : 1,
    onEnd,
    onBoundary: tokens
      ? (event) => {
          // Ignore a stray event from an utterance speechSynthesis is still
          // tearing down after a cancel() elsewhere (e.g. Detener/Repetir
          // fired a moment ago) - only ever trust boundary events while this
          // message is still the one actually current.
          if (currentTutorAudio.messageEl !== messageEl) return;
          setTutorHighlightWord(messageEl, tokens, event.charIndex ?? 0);
        }
      : undefined
  });

  messageEl.classList.add('is-playing');
  if (stopBtn) stopBtn.disabled = false;
  if (pauseBtn) {
    pauseBtn.disabled = false;
    pauseBtn.textContent = '⏸ Pausar';
  }
  if (listenBtn) listenBtn.dataset.played = 'true';
}

// Course-backed lessons (normalized schema, e.g. English A1) send options as
// { id, text } and exercises with a real id. Legacy content_json lessons send
// options as plain strings and have no exercise id at all. These helpers let
// the rendering/answer code handle both shapes without caring which one it got.
function optionLabel(option) {
  return option && typeof option === 'object' ? option.text : option;
}

function optionKey(option, optionIndex) {
  return option && typeof option === 'object' ? option.id : optionIndex;
}

function authHeaders() {
  return authStatus.session?.access_token
    ? { Authorization: `Bearer ${authStatus.session.access_token}` }
    : {};
}

// Desktop/tablet always show the path and the lesson panel side by side
// (see .learning-path-layout's grid) - this only matters on mobile, where
// the path collapses into a drawer opened by "Ver ruta" ('route') and
// closed once a lesson is picked or "Volver a la ruta" reopens it ('route'
// again). The class has no effect above the mobile breakpoint.
function showLearnState(state) {
  const graph = document.getElementById('skillGraph');
  const toggle = document.querySelector('.learn-route-toggle');
  const isOpen = state === 'route';
  graph?.classList.toggle('is-drawer-open', isOpen);
  toggle?.setAttribute('aria-expanded', String(isOpen));
}

// Selects a lesson in the learning path and, for signed-in users, tells the
// backend it was opened (POST /api/lessons/:slug/start marks it in_progress
// in user_lesson_progress). Fire-and-forget: 404s for lessons not yet on the
// normalized courses schema, and guests just get the local UI update.
function openLesson(slug) {
  if (!slug) return;
  stopTutorDictation();
  setActiveLesson(slug);
  updateLearnHash();
  renderLearningPath();
  showLearnState('lesson');
  if (authStatus.session?.access_token) {
    fetch(`${backendBaseUrl}/api/lessons/${slug}/start`, {
      method: 'POST',
      headers: authHeaders()
    }).catch(() => {});
  }
}

function getActiveLearningLesson() {
  const direct = learningPathState.lessons.find(
    (item) => item.slug === learningPathState.activeSlug
  );
  if (direct) return direct;
  // No direct match (activeSlug empty/stale). Previously this fell straight
  // to learningPathState.lessons[0], which - since lessons are ordered by
  // unit - is always Unidad 1's first activity: the Tutor IA context and
  // "next activity" would silently stick to Unidad 1 even right after the
  // user selected a different unit. Prefer a lesson from the selected unit
  // first, and only fall back to the course-wide recommendation otherwise.
  if (learningPathState.unitId) {
    const unitActivities = getUnitActivities(learningPathState.unitId);
    const unitFallback =
      unitActivities.find((item) => !item.completed && !item.locked) || unitActivities[0];
    if (unitFallback) return unitFallback;
  }
  return getNextRecommendedLesson() || null;
}

function updateAiTutorContext() {
  const contextRoot = document.querySelector('#tutor .tutor-context');
  if (!contextRoot) return;
  refreshLanguagePairChrome();

  const lesson = getActiveLearningLesson();
  const values = {
    language: LanguagePair
      ? LanguagePair.languageNameIn(learningPathState.bridgeLanguage, learningPathState.language)
      : languageDisplayNames[learningPathState.language] || learningPathState.language || 'English',
    level: learningPathState.level || 'A1',
    lesson: lesson?.title || 'Ruta inicial'
  };

  Object.entries(values).forEach(([key, value]) => {
    const node = contextRoot.querySelector(`[data-ai-context="${key}"]`);
    if (node) node.textContent = value;
  });
}

// Real connectivity probe run each time the Tutor view is opened - never
// hardcode "Conectado", it has to reflect an actual backend response.
// A chat exchange (see .tutor-chat-btn handler) is a stronger signal and
// overwrites this once the student actually sends a message.
async function checkTutorConnection(statusElId = 'tutorConnectionStatus') {
  const status = document.getElementById(statusElId);
  if (!status) return;
  status.textContent = 'Comprobando conexión…';
  try {
    const response = await fetch(`${backendBaseUrl}/api/health`);
    status.textContent = response.ok ? 'Conectado' : 'No disponible';
  } catch (error) {
    status.textContent = 'No disponible';
  }
}

// Discreet "Te quedan N de 30 consultas" line - replaces the old permanent
// "Conversación por voz / Corrección de pronunciación" Premium badge row
// that used to sit here regardless of how much of the free quota was left.
// Says nothing about Premium at all until the student actually hits the
// limit (see openPaywallModal, called separately from the /api/ai/tutor
// rejection). remaining: null (guest, or Premium/ceo - see
// usageLimitService.checkUsage) means "no cap to show", so the line stays empty.
function renderTutorUsageCounter({ remaining, limit }) {
  const el = document.getElementById('tutorUsageCounter');
  if (!el) return;
  el.textContent =
    remaining != null && limit != null ? `Te quedan ${remaining} de ${limit} consultas.` : '';
}

async function refreshTutorUsageCounter() {
  const el = document.getElementById('tutorUsageCounter');
  if (!el) return;
  try {
    const response = await fetch(`${backendBaseUrl}/api/ai/tutor/usage`, { headers: authHeaders() });
    if (!response.ok) return;
    const data = await response.json();
    renderTutorUsageCounter(data);
  } catch (error) {
    // Silent - a stale/missing counter is never worth surfacing an error for.
  }
}

// ---------------------------------------------------------------------
// Speech transcript punctuation normalization. The Web Speech API used by
// startTutorDictation below returns raw text with no punctuation and no
// capitalization at all - there's no "provider punctuation" tier to lean on
// here, so this rule-based pass is the whole fix (deliberately not an AI
// call: a network round-trip per dictation would add latency and burn the
// Tutor's free-query quota for what's just spacing/capitalization cleanup,
// see §8/§9 of the spec this implements). It only ever touches whitespace,
// capitalization and terminal punctuation - never vocabulary, word order or
// meaning - and is applied once, when dictation ends, never on the live
// interim text (which would otherwise flicker).
// ---------------------------------------------------------------------
const TRANSCRIPT_LANGUAGE_CODES = { english: 'en', spanish: 'es', french: 'fr' };

// Sentence-initial cues used only to pick "?" vs "." for the one terminal
// mark this function may add - never used to add/remove/reorder words.
const TRANSCRIPT_QUESTION_STARTERS = {
  en: /^(what|why|when|where|who|whom|whose|which|how|is|are|am|was|were|do|does|did|can|could|will|would|shall|should|may|might|have|has|had)\b/i,
  es: /^(qué|que|cómo|como|cuándo|cuando|dónde|donde|quién|quien|cuál|cual|cuánto|cuanto|puedes|puede|podrías|podría|eres|es|estás|estas|tienes|tiene|vas|va)\b/i,
  fr: /^(que|qu'|quoi|comment|quand|où|qui|quel|quelle|quels|quelles|pourquoi|combien|es-tu|est-il|est-elle|peux-tu|pouvez-vous|as-tu|avez-vous|vas-tu|allez-vous)\b/i
};

// Collapses duplicate whitespace and fixes spacing around , . ; : ! ? -
// never removes accents/apostrophes, never touches word content.
function normalizeTranscriptSpacing(text) {
  return String(text)
    .replace(/\s+/g, ' ')
    .replace(/\s+([,.;:!?])/g, '$1')
    .replace(/([,.;:!?])(?=[^\s.!?…])/g, '$1 ')
    .replace(/\.{4,}/g, '...')
    .trim();
}

// Reusable, single-purpose formatter for a finished speech transcript -
// capitalization, spacing and terminal punctuation only, per language
// (en/es/fr supported; anything else still gets safe spacing/capitalization,
// just no question-mark heuristic since we have no starter word list for it).
function normalizeSpeechTranscript(text, language) {
  if (!text) return text;
  const lang = TRANSCRIPT_LANGUAGE_CODES[language] || null;

  let normalized = String(text)
    .split('\n')
    .map(normalizeTranscriptSpacing)
    .join('\n')
    .trim();
  if (!normalized) return normalized;

  // Capitalize the very first letter and the start of any sentence that
  // follows a ./!/?/… plus whitespace - interior words are never touched.
  normalized = normalized.replace(/(^|[.!?…]\s+)([a-zà-öø-ÿ])/g, (match, lead, letter) =>
    lead + letter.toUpperCase()
  );

  const endsWithTerminal = /[.!?…]["')\]]?$/.test(normalized);
  if (!endsWithTerminal) {
    const isQuestion = lang && TRANSCRIPT_QUESTION_STARTERS[lang]?.test(normalized);
    normalized += isQuestion ? '?' : '.';
  }

  if (lang === 'es') {
    if (/\?$/.test(normalized) && !normalized.startsWith('¿')) normalized = `¿${normalized}`;
  } else if (lang === 'fr') {
    // French convention: a space before ! ? ; : - already stripped by
    // normalizeTranscriptSpacing above, added back only for these four.
    normalized = normalized.replace(/\s*([!?;:])/g, ' $1');
  }

  return normalized;
}

// Voice dictation for the Tutor prompt textareas - converts speech to text
// via the browser's Web Speech API only. This is deliberately unrelated to
// the Speaking skill's MediaRecorder-based audio capture (renderSpeakingView):
// no audio is ever recorded, kept, or sent anywhere here, only the
// transcribed text ends up in the textarea, same as if the student had
// typed it. Only one dictation session may run at a time app-wide.
const DICTATION_LANGUAGE_CODES = {
  english: 'en-US',
  spanish: 'es-ES',
  french: 'fr-FR',
  italian: 'it-IT',
  german: 'de-DE',
  portuguese: 'pt-BR',
  japanese: 'ja-JP',
  chinese: 'zh-CN'
};
const DICTATION_MAX_SECONDS = 45;

let tutorDictation = {
  recognition: null,
  status: 'idle', // idle | listening | unsupported
  textareaId: null,
  timeoutId: null
};

// Set right before sendTutorMessage stops an in-progress recognition to send
// early (spec: "el usuario también debe poder enviar manualmente antes de
// que terminen los dos segundos") - tells the recognizer's own 'end' handler
// not to also overwrite the textarea (now cleared by the send that just
// happened) or auto-click send a second time. Read once and reset by that
// handler; a single module-level flag is enough since only one recognition
// session is ever active at a time.
let tutorDictationManualSendSuppressed = false;

// Centralized auto-send state. Once speech recognition has decided that the
// student finished, there is no second artificial two-second wait.
let tutorAutoSendTimerId = null;
let tutorLastAutoSentTranscript = '';

function clearTutorAutoSendTimer() {
  if (tutorAutoSendTimerId) {
    window.clearTimeout(tutorAutoSendTimerId);
    tutorAutoSendTimerId = null;
  }
}

// Sends on the next event-loop turn so the recognizer can finish resetting
// its UI before the normal Send button path runs.
function scheduleTutorAutoSend(textareaId) {
  clearTutorAutoSendTimer();
  setDictationStatusText(textareaId, 'Enviando…');
  tutorAutoSendTimerId = window.setTimeout(() => {
    tutorAutoSendTimerId = null;
    const textarea = document.getElementById(textareaId);
    const normalized = (textarea?.value || '').trim();
    const sendBtn = getDictationSendButton(textareaId);
    if (!normalized || normalized === tutorLastAutoSentTranscript || sendBtn?.disabled) return;
    setDictationStatusText(textareaId, 'Enviando…');
    sendBtn?.click();
  }, 0);
}

// Kept as the single re-scheduling entry point for the brief next-tick
// window above.
function restartTutorAutoSendIfPending(textareaId) {
  if (tutorAutoSendTimerId) scheduleTutorAutoSend(textareaId);
}

function getSpeechRecognitionCtor() {
  return window.SpeechRecognition || window.webkitSpeechRecognition || null;
}

function setDictationStatusText(textareaId, text) {
  const statusEl = document.getElementById(`${textareaId}DictateStatus`);
  if (statusEl) statusEl.textContent = text;
}

function getDictationSendButton(textareaId) {
  return textareaId === 'aiTutorPrompt'
    ? document.querySelector('#tutor .tutor-chat-btn')
    : document.getElementById('tutorDrawerSend');
}

function resetDictationUI(textareaId) {
  const micBtn = document.querySelector(`.tutor-dictate-btn[data-dictate-target="${textareaId}"]`);
  const stopBtn = document.querySelector(
    `.tutor-dictate-stop-btn[data-dictate-target="${textareaId}"]`
  );
  if (micBtn && tutorDictation.status !== 'unsupported') {
    micBtn.disabled = false;
    micBtn.classList.remove('is-listening');
    micBtn.setAttribute('aria-pressed', 'false');
  }
  if (stopBtn) stopBtn.hidden = true;
  const sendBtn = getDictationSendButton(textareaId);
  if (sendBtn) sendBtn.disabled = false;
}

// Stops the recognizer (if any) - safe to call any time, including when
// nothing is active. Fires the 'end' handler registered in startDictation,
// which does the actual UI/state cleanup, so callers don't duplicate that.
function stopDictationRecognizer() {
  // Covers every cleanup path at once (closing the Tutor, changing language,
  // clearing the conversation, navigating away, starting a fresh dictation
  // session, a real error) since they all funnel through here - spec §6:
  // "Limpiar timers... cuando se cierre el Tutor / se cambie de idioma / se
  // limpie la conversación / se navegue fuera / se produzca un error."
  clearTutorAutoSendTimer();
  if (tutorDictation.timeoutId) {
    window.clearTimeout(tutorDictation.timeoutId);
    tutorDictation.timeoutId = null;
  }
  if (tutorDictation.recognition) {
    try {
      tutorDictation.recognition.stop();
    } catch {
      /* already stopped/inactive */
    }
  }
}

// Called on: manually pressing "Detener", the 45s limit, changing target
// language, closing the Tutor drawer, and any top-level view navigation
// (showView) - covers "cerrar el Tutor"/"cambiar de idioma"/"cambiar de
// lección" without needing a cleanup call at every single call site.
function stopTutorDictation() {
  if (tutorDictation.status !== 'listening') return;
  setDictationStatusText(tutorDictation.textareaId, 'Transcribiendo…');
  stopDictationRecognizer();
}

// continuous/silenceMs/autoSend back the Premium "Conversar" hands-free mode
// (see resumeTutorConversationListening/setTutorConversationMode above):
// continuous keeps the recognizer open instead of stopping after one
// phrase, silenceMs auto-stops it after that many ms without a new result
// (i.e. "wait N seconds after the student stops talking"), and autoSend
// clicks the send button once a real transcript comes back instead of
// leaving it for the student to review. All three default to the original
// single-shot manual-dictation behavior when omitted.
function startTutorDictation(textareaId, { continuous = false, silenceMs = null, autoSend = false } = {}) {
  const textarea = document.getElementById(textareaId);
  const Ctor = getSpeechRecognitionCtor();
  if (!Ctor || !textarea) {
    tutorDictation.status = 'unsupported';
    setDictationStatusText(
      textareaId,
      'El dictado por voz no está disponible en este navegador. Puedes escribir tu mensaje.'
    );
    const micBtn = document.querySelector(
      `.tutor-dictate-btn[data-dictate-target="${textareaId}"]`
    );
    if (micBtn) micBtn.disabled = true;
    return;
  }

  // No simultaneous sessions - a second "Hablar" press while already
  // listening (on either textarea) is a no-op. Also releases the
  // translator's mic, since only one recognizer can use it at a time.
  if (tutorDictation.status === 'listening') return;
  stopTranslatorDictation();
  stopDictationRecognizer();

  const recognition = new Ctor();
  recognition.lang = DICTATION_LANGUAGE_CODES[learningPathState.language] || 'en-US';
  recognition.interimResults = true;
  recognition.continuous = continuous;

  tutorDictation = { recognition, status: 'listening', textareaId, timeoutId: null };

  const baseText = textarea.value.trim();
  let finalTranscript = '';
  let hadError = false;
  let lastErrorCode = null;
  // Only armed once continuous+silenceMs are both set, and only starts
  // counting once the student has actually said something (first 'result')
  // - never from the moment the mic opens, so thinking time before speaking
  // is never mistaken for "finished talking".
  let silenceTimerId = null;
  let waitingStatusTimerId = null;

  const micBtn = document.querySelector(`.tutor-dictate-btn[data-dictate-target="${textareaId}"]`);
  const stopBtn = document.querySelector(
    `.tutor-dictate-stop-btn[data-dictate-target="${textareaId}"]`
  );
  if (micBtn) {
    micBtn.disabled = true;
    micBtn.classList.add('is-listening');
    micBtn.setAttribute('aria-pressed', 'true');
  }
  if (stopBtn) stopBtn.hidden = false;
  // Send stays enabled while listening - the student can send manually
  // before the ~2s silence auto-send fires (see sendTutorMessage, which
  // stops this recognizer and suppresses its own auto-send when that
  // happens).
  setDictationStatusText(textareaId, continuous ? 'Escuchando… habla cuando quieras.' : 'Escuchando…');

  recognition.addEventListener('result', (event) => {
    let interim = '';
    for (let i = event.resultIndex; i < event.results.length; i++) {
      const chunk = event.results[i][0].transcript;
      if (event.results[i].isFinal) finalTranscript += chunk;
      else interim += chunk;
    }
    textarea.value = [baseText, (finalTranscript + interim).trim()].filter(Boolean).join(' ');

    if (continuous && silenceMs) {
      if (silenceTimerId) window.clearTimeout(silenceTimerId);
      if (waitingStatusTimerId) window.clearTimeout(waitingStatusTimerId);
      setDictationStatusText(textareaId, 'Voz detectada…');
      // "Esperando…" covers the rest of the silence countdown once the
      // brief "Voz detectada…" beat has shown - both are cleared/restarted
      // together by the next result, so a student who keeps talking never
      // sees them flicker.
      waitingStatusTimerId = window.setTimeout(() => {
        setDictationStatusText(textareaId, 'Esperando…');
      }, Math.min(400, silenceMs));
      silenceTimerId = window.setTimeout(() => stopTutorDictation(), silenceMs);
    }
  });

  recognition.addEventListener('error', (event) => {
    hadError = true;
    lastErrorCode = event.error;
    if (event.error === 'not-allowed' || event.error === 'permission-denied') {
      setDictationStatusText(
        textareaId,
        'No se pudo acceder al micrófono. Revisa los permisos del navegador.'
      );
    } else if (event.error === 'no-speech') {
      // In conversation mode this is normal, not a real failure - the
      // browser's own SpeechRecognition instance times itself out after a
      // few seconds of silence even with continuous:true. The 'end' handler
      // below auto-restarts listening in that case instead of showing this
      // as an error, so this message only actually reaches the student
      // outside conversation mode (see the 'end' handler's own check).
      setDictationStatusText(textareaId, 'No se entendió el audio. Intenta de nuevo.');
    } else {
      setDictationStatusText(textareaId, 'No se pudo completar el dictado. Intenta de nuevo.');
    }
  });

  // 'error' always fires before 'end', but 'end' still fires afterwards -
  // hadError guards against this handler overwriting a more specific
  // message (e.g. permission denied) with a generic one.
  recognition.addEventListener('end', () => {
    if (silenceTimerId) window.clearTimeout(silenceTimerId);
    if (waitingStatusTimerId) window.clearTimeout(waitingStatusTimerId);
    // A manual send (sendTutorMessage) already stopped this recognizer and
    // read/cleared the textarea itself - don't repopulate it with the
    // now-stale transcript, and don't auto-click send a second time.
    const suppressed = tutorDictationManualSendSuppressed;
    tutorDictationManualSendSuppressed = false;
    const hadFinalText = Boolean(finalTranscript.trim());
    if (hadFinalText && !suppressed) {
      const polished = normalizeSpeechTranscript(finalTranscript.trim(), learningPathState.language);
      textarea.value = [baseText, polished].filter(Boolean).join(' ');
    }
    tutorDictation = { recognition: null, status: 'idle', textareaId: null, timeoutId: null };
    resetDictationUI(textareaId);
    if (suppressed) return;
    if (hadFinalText && autoSend) {
      scheduleTutorAutoSend(textareaId);
      return;
    }
    // Conversation mode must keep listening on its own - a silence timeout
    // or a 'no-speech' error (the browser's own SpeechRecognition instance
    // gives up after a few seconds of silence even with continuous:true)
    // is normal here, not something that should force the student to press
    // "Hablar" again. Only a real permission problem stops the loop.
    if (
      !hadFinalText &&
      continuous &&
      tutorConversationMode &&
      lastErrorCode !== 'not-allowed' &&
      lastErrorCode !== 'permission-denied'
    ) {
      setDictationStatusText(textareaId, 'Escuchando… habla cuando quieras.');
      window.setTimeout(() => resumeTutorConversationListening(), 400);
      return;
    }
    if (hadFinalText) {
      setDictationStatusText(textareaId, 'Texto listo. Puedes editarlo antes de enviar.');
    } else if (!hadError && !textarea.value.trim()) {
      setDictationStatusText(
        textareaId,
        continuous && tutorConversationMode
          ? 'No se detectó voz. Pulsa "Hablar" cuando quieras continuar.'
          : 'No se entendió el audio. Intenta de nuevo.'
      );
    }
    textarea.focus();
  });

  try {
    recognition.start();
  } catch {
    tutorDictation = { recognition: null, status: 'idle', textareaId: null, timeoutId: null };
    setDictationStatusText(textareaId, 'No se pudo iniciar el dictado. Intenta de nuevo.');
    resetDictationUI(textareaId);
    return;
  }

  tutorDictation.timeoutId = window.setTimeout(() => {
    stopTutorDictation();
  }, DICTATION_MAX_SECONDS * 1000);
}

// Separate from tutorDictation - the translator has its own recognizer
// language (the selected "Idioma de origen", not the learning path
// language) and its own single textarea, so it doesn't need the
// multi-textarea bookkeeping tutorDictation carries.
let translatorDictation = {
  recognition: null,
  status: 'idle', // idle | listening | unsupported
  timeoutId: null
};

// Set by setupTranslator() once the Traductor view's runTranslation() closure
// exists - lets startTranslatorDictation() (defined earlier in the file,
// outside that closure) trigger the same auto-translate-after-silence flow
// the Enter key and the Traducir button use, without duplicating its logic.
let translateTranslatorInputNow = null;

// Mirrors tutorDictationManualSendSuppressed: set right before runTranslation
// stops an in-progress recognition to translate early (manual Enter/click
// while still listening) - tells the recognizer's 'end' handler not to also
// overwrite the textarea or auto-translate a second time.
let translatorDictationManualSendSuppressed = false;

// Set right before the ~2s-silence auto-translate (voice dictation only,
// never Enter/the Traducir button) - runTranslation() reads and clears this
// once, so only a translation that was actually triggered by speaking gets
// its result read aloud automatically afterwards.
let translatorAutoPlayAfterVoice = false;

function setTranslatorDictateStatusText(text) {
  const statusEl = document.getElementById('translatorInputDictateStatus');
  if (statusEl) statusEl.textContent = text;
}

function resetTranslatorDictateUI() {
  const micBtn = document.getElementById('translatorDictateBtn');
  const stopBtn = document.getElementById('translatorDictateStopBtn');
  if (micBtn && translatorDictation.status !== 'unsupported') {
    micBtn.disabled = false;
    micBtn.classList.remove('is-listening');
    micBtn.setAttribute('aria-pressed', 'false');
  }
  if (stopBtn) stopBtn.hidden = true;
}

function stopTranslatorDictationRecognizer() {
  if (translatorDictation.timeoutId) {
    window.clearTimeout(translatorDictation.timeoutId);
    translatorDictation.timeoutId = null;
  }
  if (translatorDictation.recognition) {
    try {
      translatorDictation.recognition.stop();
    } catch {
      /* already stopped/inactive */
    }
  }
}

// Called on: manually pressing "Detener", the 45s limit, changing the
// source language mid-dictation (recognition.lang is fixed for the life of
// a SpeechRecognition instance), and any top-level view navigation away
// from the homepage.
function stopTranslatorDictation() {
  if (translatorDictation.status !== 'listening') return;
  setTranslatorDictateStatusText('Transcribiendo…');
  stopTranslatorDictationRecognizer();
}

function startTranslatorDictation() {
  const textarea = document.getElementById('translatorInput');
  const Ctor = getSpeechRecognitionCtor();
  if (!Ctor || !textarea) {
    translatorDictation.status = 'unsupported';
    setTranslatorDictateStatusText(
      'El dictado por voz no está disponible en este navegador. Puedes escribir tu texto.'
    );
    const micBtn = document.getElementById('translatorDictateBtn');
    if (micBtn) micBtn.disabled = true;
    return;
  }

  // No simultaneous sessions - also releases the tutor's mic, since only
  // one recognizer can use it at a time.
  if (translatorDictation.status === 'listening') return;
  stopTutorDictation();
  stopTranslatorDictationRecognizer();

  const sourceSelect = document.getElementById('translatorSourceLang');
  const recognition = new Ctor();
  // 'auto' (Detectar idioma) has no fixed language to give the recognizer,
  // so it falls back to Spanish - most likely tongue for this app's users.
  recognition.lang = DICTATION_LANGUAGE_CODES[sourceSelect?.value] || 'es-ES';
  recognition.interimResults = true;
  // Stays open (instead of stopping after one phrase) so the ~2s-silence
  // timer below decides when the student is actually done talking, same
  // pattern as the Tutor's mic (startTutorDictation).
  recognition.continuous = true;

  translatorDictation = { recognition, status: 'listening', timeoutId: null };

  const baseText = textarea.value.trim();
  let finalTranscript = '';
  let hadError = false;
  // Only starts counting once the student has actually said something
  // (first 'result'), and restarts on every new result - "esperar ~2
  // segundos sin nueva voz" / "cancelar el temporizador si vuelve a hablar".
  let silenceTimerId = null;

  const micBtn = document.getElementById('translatorDictateBtn');
  const stopBtn = document.getElementById('translatorDictateStopBtn');
  if (micBtn) {
    micBtn.disabled = true;
    micBtn.classList.add('is-listening');
    micBtn.setAttribute('aria-pressed', 'true');
  }
  if (stopBtn) stopBtn.hidden = false;
  setTranslatorDictateStatusText('Escuchando…');

  recognition.addEventListener('result', (event) => {
    let interim = '';
    for (let i = event.resultIndex; i < event.results.length; i++) {
      const chunk = event.results[i][0].transcript;
      if (event.results[i].isFinal) finalTranscript += chunk;
      else interim += chunk;
    }
    textarea.value = [baseText, (finalTranscript + interim).trim()].filter(Boolean).join(' ');
    // Keeps the char counter (bound to 'input') live while dictating.
    textarea.dispatchEvent(new Event('input'));

    if (silenceTimerId) window.clearTimeout(silenceTimerId);
    silenceTimerId = window.setTimeout(() => stopTranslatorDictation(), 2000);
  });

  recognition.addEventListener('error', (event) => {
    hadError = true;
    if (event.error === 'not-allowed' || event.error === 'permission-denied') {
      setTranslatorDictateStatusText(
        'No se pudo acceder al micrófono. Revisa los permisos del navegador.'
      );
    } else if (event.error === 'no-speech') {
      setTranslatorDictateStatusText('No se entendió el audio. Intenta de nuevo.');
    } else {
      setTranslatorDictateStatusText('No se pudo completar el dictado. Intenta de nuevo.');
    }
  });

  // 'error' always fires before 'end', but 'end' still fires afterwards -
  // hadError guards against this handler overwriting a more specific
  // message (e.g. permission denied) with a generic one.
  recognition.addEventListener('end', () => {
    if (silenceTimerId) window.clearTimeout(silenceTimerId);
    // A manual translate (runTranslation, via Enter or the Traducir button)
    // already stopped this recognizer and read/cleared the textarea itself -
    // don't repopulate it with the now-stale transcript, and don't
    // auto-translate a second time.
    const suppressed = translatorDictationManualSendSuppressed;
    translatorDictationManualSendSuppressed = false;
    // No textarea rewrite here (unlike the Tutor's dictation) - the
    // 'result' handler above already keeps textarea.value current with the
    // final transcript as it arrives, and the original translator flow
    // never re-normalized it, so this doesn't change that.
    const hadFinalText = Boolean(finalTranscript.trim());
    translatorDictation = { recognition: null, status: 'idle', timeoutId: null };
    resetTranslatorDictateUI();
    if (suppressed) return;
    if (hadFinalText) {
      setTranslatorDictateStatusText('Traduciendo…');
      translatorAutoPlayAfterVoice = true;
      translateTranslatorInputNow?.();
    } else if (!hadError && !textarea.value.trim()) {
      setTranslatorDictateStatusText('No se entendió el audio. Intenta de nuevo.');
    }
    textarea.focus();
  });

  try {
    recognition.start();
  } catch {
    translatorDictation = { recognition: null, status: 'idle', timeoutId: null };
    setTranslatorDictateStatusText('No se pudo iniciar el dictado. Intenta de nuevo.');
    resetTranslatorDictateUI();
    return;
  }

  translatorDictation.timeoutId = window.setTimeout(() => {
    stopTranslatorDictation();
  }, DICTATION_MAX_SECONDS * 1000);
}

const SKILL_ICONS = {
  listening: '🎧',
  speaking: '🗣️',
  reading: '📖',
  writing: '✍️',
  grammar: '📚',
  vocabulary: '🧠',
  dialogue: '💬'
};

// One lesson per skill per level is the real data shape today (no
// sub-level "module" grouping exists in course_lessons/lessonsService), so
// "Módulo <nivel>" is the module unit - honest to what's actually loaded,
// rather than inventing themed module names the data can't back up.
function getLessonStateInfo(lesson, isActive, nextSlug) {
  if (lesson.locked) return { key: 'locked', label: 'Bloqueado' };
  if (isActive) return { key: 'now', label: 'Ahora' };
  if (lesson.completed) return { key: 'completed', label: 'Completado' };
  if (lesson.progressStatus === 'in_progress') return { key: 'in-progress', label: 'En progreso' };
  if (lesson.slug === nextSlug) return { key: 'recommended', label: 'Recomendado' };
  return { key: 'available', label: 'Disponible' };
}

function renderLessonItemHtml(lesson, nextSlug) {
  const isActive = lesson.slug === learningPathState.activeSlug;
  const icon = SKILL_ICONS[lesson.skill?.toLowerCase()] || '📚';
  const skillLabel = getSkillLabel(lesson.skill);
  const duration = getLessonDurationMinutes(lesson);
  const xp = lesson.xpReward ?? lesson.xp_reward ?? 20;
  const state = getLessonStateInfo(lesson, isActive, nextSlug);
  const progressPct = lesson.completed
    ? 100
    : lesson.progressStatus === 'in_progress'
      ? (lesson.bestScore ?? 50)
      : 0;

  return `
      <button
        type="button"
        class="path-lesson-item path-lesson-item--${state.key}"
        data-lesson-slug="${escapeHtml(lesson.slug)}"
        ${isActive ? 'aria-current="true"' : ''}
      >
        <span class="path-lesson-icon" aria-hidden="true">${lesson.locked ? '🔒' : icon}</span>
        <span class="path-lesson-info">
          <span class="path-lesson-skill">${escapeHtml(skillLabel)}</span>
          <span class="path-lesson-title">${escapeHtml(lesson.title)}</span>
          <span class="path-lesson-meta">
            ${duration ? `<span>⏱ ${escapeHtml(String(duration))} min</span>` : ''}
            <span>⭐ ${escapeHtml(String(xp))} XP</span>
          </span>
          ${progressPct > 0 ? `<span class="path-lesson-progress"><span style="width:${progressPct}%"></span></span>` : ''}
        </span>
        <span class="path-lesson-state path-lesson-state--${state.key}">${state.label}</span>
      </button>
    `;
}

// The Ruta tab for a unit-aware language+level (English A1 today): 12
// thematic units in order, each with its own ≤6 activities, instead of one
// flat module. Reuses renderLessonItemHtml() so a unit's activities look
// and behave exactly like the legacy flat list's items.
function renderUnitAccordionHtml(nextSlug) {
  // If nothing has explicitly selected a unit yet (fresh load / language or
  // level switch, which resets unitId), default to the unit that holds the
  // active lesson, or failing that the recommended "next" lesson - so the
  // accordion opens somewhere sensible instead of every unit collapsed.
  if (!learningPathState.unitId) {
    const fallbackLesson = learningPathState.lessons.find(
      (item) => item.slug === learningPathState.activeSlug || item.slug === nextSlug
    );
    if (fallbackLesson?.unitId) learningPathState.unitId = fallbackLesson.unitId;
  }

  return learningPathState.units
    .map((unit) => {
      const metrics = getUnitProgressMetrics(unit.id);
      const isSelected = unit.id === learningPathState.unitId;

      return `
      <button type="button" class="path-unit path-unit-header${isSelected ? ' path-unit--selected' : ''}" data-unit-id="${escapeHtml(unit.id)}" ${isSelected ? 'aria-current="true"' : ''}>
        <span class="path-unit-order">${escapeHtml(String(unit.order))}</span>
        <span class="path-unit-titles">
          <span class="path-unit-title">${escapeHtml(unit.title)}</span>
          ${unit.titleEs ? `<span class="path-unit-title-es">${escapeHtml(unit.titleEs)}</span>` : ''}
        </span>
        <span class="path-unit-progress-label">${metrics.completedCount}/${metrics.total} · ${metrics.progressPercent}%</span>
      </button>
    `;
    })
    .join('');
}

function renderSkillGraph() {
  const container = document.getElementById('skillGraph');
  if (!container) return;

  const lessons = learningPathState.lessons;
  if (!lessons.length) {
    container.innerHTML = '<p class="skill-graph-empty">No hay lecciones disponibles.</p>';
    return;
  }

  const targetLabel =
    languageDisplayNames[learningPathState.language] || learningPathState.language;
  const level = learningPathState.level;
  const courseMetrics = hasUnits()
    ? getCourseProgressMetrics()
    : {
        completedCount: lessons.filter((item) => item.completed).length,
        total: lessons.length,
        progressPercent: Math.round(
          lessons.reduce((sum, item) => sum + Number(item.bestScore || 0), 0) / lessons.length
        )
      };
  const nextLesson = getNextRecommendedLesson();
  const nextSkillLabel = nextLesson ? getSkillLabel(nextLesson.skill) : '—';

  const bodyHtml = hasUnits()
    ? `<div class="unit-accordion">${renderUnitAccordionHtml(nextLesson?.slug)}</div>`
    : `
    <div class="path-module">
      <div class="path-module-header">Módulo ${escapeHtml(level)} · ${escapeHtml(targetLabel)}</div>
      <div class="path-module-body">${lessons.map((item) => renderLessonItemHtml(item, nextLesson?.slug)).join('')}</div>
    </div>
  `;

  container.innerHTML = `
    <div class="path-summary">
      <span class="path-summary-lang">${escapeHtml(targetLabel)} · ${escapeHtml(level)}</span>
      <div class="path-summary-progress" role="progressbar" aria-valuenow="${courseMetrics.progressPercent}" aria-valuemin="0" aria-valuemax="100">
        <div style="width:${courseMetrics.progressPercent}%"></div>
      </div>
      <span class="path-summary-detail">${courseMetrics.completedCount}/${courseMetrics.total} completadas · Score promedio: ${courseMetrics.progressPercent}/100 · Próximo: ${escapeHtml(nextSkillLabel)}</span>
    </div>
    ${bodyHtml}
  `;

  container.querySelectorAll('.path-lesson-item').forEach((nodeEl) => {
    nodeEl.addEventListener('click', () => openLesson(nodeEl.dataset.lessonSlug));
  });

  // Clicking a unit selects it (see selectUnit()): it becomes the source of
  // truth in learningPathState.unitId, its first available lesson is
  // auto-picked when the previously active lesson belonged to a different
  // unit, and the whole graph re-renders - which is also what moves the
  // aria-current highlight to this unit. The route only ever lists unit
  // names; per-skill navigation happens in the right-hand unit overview
  // panel's CTA (renderUnitOverviewCard) and each skill's own level-tabs.
  container.querySelectorAll('.path-unit-header').forEach((headerEl) => {
    headerEl.addEventListener('click', (event) => {
      event.preventDefault();
      const unitId = headerEl.closest('.path-unit')?.dataset.unitId;
      if (!unitId) return;
      selectUnit(unitId);
      updateLearnHash('learn');
    });
  });

  // Keep the active lesson in view when the list re-renders (e.g. after
  // switching level/language) rather than always resetting scroll to top.
  container
    .querySelector('.path-lesson-item[aria-current="true"]')
    ?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function renderLessonExercise(item, index, lesson) {
  const recorded = learningPathState.exerciseResults[lesson.slug]?.[index];

  if (item.type === 'mcq' && Array.isArray(item.options)) {
    const optionsHtml = item.options
      .map((option, optionIndex) => {
        const key = optionKey(option, optionIndex);
        const isChosen = recorded && String(recorded.selectedOption) === String(key);
        const cls = isChosen ? (recorded.correct ? 'correct' : 'incorrect') : '';
        const disabled = recorded ? 'disabled' : '';
        return `<button type="button" class="mcq-option ${cls}" data-option-key="${escapeHtml(String(key))}" data-option-index="${optionIndex}" ${disabled}>${escapeHtml(optionLabel(option))}</button>`;
      })
      .join('');
    const answeredClass = recorded
      ? `answered ${recorded.correct ? 'is-correct' : 'is-incorrect'}`
      : '';
    const feedbackText = recorded
      ? recorded.correct
        ? '¡Correcto! +5 XP'
        : 'No es correcto, pero sigue intentando.'
      : '';
    return `
      <div class="mcq-question lesson-exercise ${answeredClass}" data-exercise-index="${index}" data-exercise-id="${escapeHtml(item.id || '')}" data-lesson-slug="${escapeHtml(lesson.slug || '')}" data-skill="${escapeHtml(lesson.skill || '')}" data-language="${escapeHtml(learningPathState.language)}">
        <strong>${index + 1}. ${escapeHtml(item.prompt)}</strong>
        <div class="mcq-options">${optionsHtml}</div>
        <span class="mcq-feedback" aria-live="polite">${feedbackText}</span>
      </div>
    `;
  }

  return `
    <div class="lesson-exercise open-exercise" data-exercise-index="${index}" data-exercise-id="${escapeHtml(item.id || '')}" data-lesson-slug="${escapeHtml(lesson.slug || '')}" data-skill="${escapeHtml(lesson.skill || item.type || '')}" data-language="${escapeHtml(learningPathState.language)}">
      <strong>${index + 1}. ${escapeHtml(item.prompt)}</strong>
      <button type="button" class="practice-mark-btn" ${recorded ? 'disabled' : ''}>${recorded ? '✅ Practicado' : 'Marcar como practicado'}</button>
    </div>
  `;
}

// First lesson that's neither completed nor locked - used both for the
// right panel's default "continue" card and for the module summary header.
function getNextRecommendedLesson() {
  return (
    learningPathState.lessons.find((item) => !item.completed && !item.locked) ||
    learningPathState.lessons[0] ||
    null
  );
}

function getLessonDurationMinutes(lesson) {
  return lesson.estimated_minutes || lesson.estimatedMinutes || lesson.duration || null;
}

function renderContinueCard(lesson) {
  const skillLabel = getSkillLabel(lesson.skill);
  const duration = getLessonDurationMinutes(lesson);
  const xp = lesson.xpReward ?? lesson.xp_reward ?? 20;
  const completedCount = learningPathState.lessons.filter((item) => item.completed).length;
  const total = learningPathState.lessons.length;
  const pct = total ? Math.round((completedCount / total) * 100) : 0;
  const targetLabel =
    languageDisplayNames[learningPathState.language] || learningPathState.language;

  return `
    <div class="lesson-continue-card">
      <span class="lesson-continue-kicker">${escapeHtml(targetLabel)} · Nivel ${escapeHtml(lesson.level)}</span>
      <h3>${lesson.progressStatus === 'in_progress' ? 'Continúa tu lección' : 'Tu próxima lección está lista'}</h3>
      <p class="lesson-continue-title">${escapeHtml(skillLabel)} · ${escapeHtml(lesson.title)}</p>
      <p class="lesson-continue-desc">${escapeHtml(lesson.intro || lesson.description || '')}</p>
      <div class="lesson-continue-meta">
        ${duration ? `<span>⏱ ${escapeHtml(String(duration))} min</span>` : ''}
        <span>⭐ ${escapeHtml(String(xp))} XP</span>
      </div>
      <div class="lesson-continue-progress" role="progressbar" aria-valuenow="${pct}" aria-valuemin="0" aria-valuemax="100">
        <div style="width:${pct}%"></div>
      </div>
      <p class="lesson-continue-count">${completedCount}/${total} lecciones completadas en ${escapeHtml(lesson.level)}</p>
      <button type="button" class="primary-btn lesson-continue-btn" data-lesson-slug="${escapeHtml(lesson.slug)}" data-lesson-skill="${escapeHtml(lesson.skill)}">${lesson.progressStatus === 'in_progress' ? 'Continuar ahora' : 'Empezar ahora'} →</button>
    </div>
  `;
}

// unit.unitOverview is optional hand-authored content (see
// scripts/content/*-a1-units.js's unitOverview field) - most units don't
// have it filled in yet, so every field here falls back to something safe
// instead of rendering "undefined" or an empty list.
function getUnitOverviewData(unit) {
  const overview = unit.unitOverview || {};
  return {
    objective: overview.objective || unit.description || '',
    outcomes: Array.isArray(overview.outcomes) ? overview.outcomes : [],
    grammar: Array.isArray(overview.grammar) ? overview.grammar : [],
    vocabulary: Array.isArray(overview.vocabulary) ? overview.vocabulary : [],
    scenario: overview.scenario || ''
  };
}

// Contextual CTA for the unit overview panel: label and target activity
// both follow the unit's own completion state, never a specific lesson name
// (that's what the left column's per-activity labels are for - see
// renderLessonItemHtml/getLessonStateInfo).
function getUnitActionState(unit) {
  const metrics = getUnitProgressMetrics(unit.id);
  const activities = metrics.activities;
  const total = metrics.total;
  const completedCount = metrics.completedCount;
  const started = activities.some(
    (item) => item.completed || item.progressStatus === 'in_progress'
  );
  const allCompleted = total > 0 && completedCount === total;

  let label = 'Comenzar unidad';
  if (allCompleted) label = 'Repasar unidad';
  else if (started) label = 'Continuar unidad';

  const target = allCompleted
    ? activities[0]
    : activities.find((item) => !item.completed && !item.locked) || activities[0];

  return { total, completedCount, label, targetSlug: target?.slug || '' };
}

function renderUnitOverviewList(items) {
  if (!items.length) return '';
  return `<ul>${items.map((item) => `<li>${escapeHtml(item)}</li>`).join('')}</ul>`;
}

// The 2-column grid from .unit-overview-body (see styles.css): outcomes and
// grammar side by side, vocabulary spanning the full width below. Any
// section with no data (unit has no unitOverview yet) is simply omitted.
function renderUnitOverviewBody(data) {
  const outcomesHtml = data.outcomes.length
    ? `<div class="unit-overview-column"><h4>Aprenderás a</h4>${renderUnitOverviewList(data.outcomes)}</div>`
    : '';
  const grammarHtml = data.grammar.length
    ? `<div class="unit-overview-column"><h4>Gramática</h4>${renderUnitOverviewList(data.grammar)}</div>`
    : '';
  const vocabularyHtml = data.vocabulary.length
    ? `<div class="unit-overview-column unit-overview-column--full"><h4>Vocabulario</h4>${renderUnitOverviewList(data.vocabulary)}</div>`
    : '';
  return `${outcomesHtml}${grammarHtml}${vocabularyHtml}`;
}

// Right-panel default state for unit-aware languages/levels (English,
// Français, Español A1 today - see hasUnits()): describes the *selected
// unit* (title, communicative objective, outcomes, grammar, vocabulary,
// scenario, this unit's own progress) instead of naming one specific
// lesson. The left column (renderUnitAccordionHtml) only lists unit names
// and overall progress - this panel's own "Comenzar/Continuar/Repasar
// unidad" CTA (action.targetSlug below) is how a student actually enters a
// specific activity; each skill's own level-tabs nav is the other way in.
// See renderContinueCard (still used for languages/levels without units)
// for the shape this replaces.
//
// Stable across every activity click within the same unit: nothing here
// depends on which activity is highlighted, only on unitId and this unit's
// completion state, so opening a different lesson to practice (which
// replaces this panel with renderLessonDetail) is the only thing that
// changes it - not merely looking at a different activity in the list.
function renderUnitOverviewCard(unit) {
  const data = getUnitOverviewData(unit);
  const action = getUnitActionState(unit);
  const pct = getUnitProgressMetrics(unit.id).progressPercent;
  const bodyHtml = renderUnitOverviewBody(data);

  return `
    <div class="unit-overview-panel">
      <div class="unit-overview-header">
        <h3 class="unit-title">${escapeHtml(unit.title)}</h3>
        ${data.objective ? `<p class="unit-objective">${escapeHtml(data.objective)}</p>` : ''}
        ${data.scenario ? `<p class="unit-scenario">“${escapeHtml(data.scenario)}”</p>` : ''}
      </div>
      <div class="unit-overview-progress">
        <div class="unit-overview-progress-bar" role="progressbar" aria-valuenow="${pct}" aria-valuemin="0" aria-valuemax="100">
          <div style="width:${pct}%"></div>
        </div>
        <span class="unit-overview-progress-label">${action.completedCount}/${action.total} actividades completadas en esta unidad</span>
      </div>
      <div class="unit-overview-sequence">
        <div class="unit-sequence-heading">
          <strong>Recorrido recomendado</strong>
          <span>Empieza con Reading y avanza paso a paso.</span>
        </div>
        <div class="unit-sequence-steps">${renderUnitSequenceStepsHtml(unit.id)}</div>
      </div>
      ${
        bodyHtml
          ? `
      <div class="unit-overview-desktop">
        <div class="unit-overview-body">${bodyHtml}</div>
      </div>
      <details class="unit-overview-collapsible">
        <summary>Ver detalles de la unidad</summary>
        <div class="unit-overview-body">${bodyHtml}</div>
      </details>`
          : ''
      }
      <div class="unit-overview-actions">
        <button type="button" class="primary-btn unit-action-btn" data-lesson-slug="${escapeHtml(action.targetSlug)}">${escapeHtml(action.label)}</button>
      </div>
    </div>
  `;
}

function renderLessonDetail(lesson) {
  const vocabulary =
    lesson.vocabulary
      ?.map(
        (item) => `
    <div>
      <strong>${escapeHtml(item.word)}</strong>
      <span>${escapeHtml(resolveVocabTranslation(item))} · ${escapeHtml(item.example)}</span>
    </div>
  `
      )
      .join('') || '';

  const dialogue =
    lesson.dialogue
      ?.map(
        (item) => `
    <div>
      <strong>${escapeHtml(item.speaker)}: ${escapeHtml(item.line)}</strong>
      <span>${escapeHtml(resolveVocabTranslation(item))}</span>
    </div>
  `
      )
      .join('') || '';

  const audioPlayer =
    lesson.skill === 'listening' && lesson.audioUrl
      ? `<audio class="lesson-audio-player" controls preload="none" src="${escapeHtml(lesson.audioUrl)}">
        Tu navegador no soporta audio HTML5.
      </audio>`
      : '';

  const exercises = lesson.locked
    ? `
    <div class="premium-lock-box">
      <strong>🔒 Lección premium</strong>
      <button type="button" class="primary-btn" data-action="open-lesson-paywall">Desbloquear</button>
    </div>
  `
    : lesson.exercises?.map((item, index) => renderLessonExercise(item, index, lesson)).join('') ||
      '';

  let mode = 'practice';
  let disabled = false;
  let buttonText = 'Iniciar práctica';
  if (lesson.locked) {
    mode = 'locked';
    disabled = true;
    buttonText = `Premium USD ${premiumPriceUsd}`;
  } else if (lesson.completed) {
    mode = 'completed';
    disabled = true;
    buttonText = 'Completada';
  } else {
    const { total, attempted, allAttempted } = getExerciseProgress(lesson);
    if (allAttempted) {
      mode = 'complete';
      buttonText = 'Completar';
    } else {
      buttonText = attempted > 0 ? `Iniciar práctica (${attempted}/${total})` : 'Iniciar práctica';
    }
  }

  return `
    <div class="lesson-workspace-head">
      <div>
        <button class="learn-back-to-route" type="button">← Volver a la ruta</button>
        <span class="lesson-kicker">${escapeHtml(lesson.level)} · ${escapeHtml(lesson.skill)}</span>
        <h3>${escapeHtml(lesson.title)}</h3>
      </div>
      <button type="button" class="lesson-complete-btn" data-lesson-slug="${escapeHtml(lesson.slug)}" data-mode="${mode}" ${disabled ? 'disabled' : ''}>${escapeHtml(buttonText)}</button>
    </div>
    <p class="lesson-intro">${escapeHtml(lesson.intro || lesson.description || '')}</p>
    <div class="lesson-audio">${audioPlayer}</div>
    <div class="lesson-columns">
      <div>
        <h4>Vocabulario</h4>
        <div class="lesson-vocabulary">${vocabulary}</div>
      </div>
      <div>
        <h4>Diálogo</h4>
        <div class="lesson-dialogue">${dialogue}</div>
      </div>
    </div>
    <div class="lesson-exercises">${exercises}</div>
  `;
}

// The right panel is never empty: with no lesson explicitly opened yet it
// shows the selected unit's overview (renderUnitOverviewCard) for
// unit-aware languages/levels, or a "continue" card for the next
// recommended lesson otherwise (languages/levels without units - see
// hasUnits()); once the student opens a specific activity to practice it
// shows that lesson's full detail. All three branches fully own
// workspace.innerHTML (see the delegated .lesson-complete-btn/
// .learn-back-to-route/.lesson-continue-btn/.unit-action-btn handlers below
// - they can't be one-time listeners bound to a single element, since that
// element gets replaced on every render).
function renderLessonWorkspace() {
  const workspace = document.getElementById('lessonWorkspace');
  if (!workspace) return;
  if (!learningPathState.lessons.length) return;

  const activeLesson = learningPathState.activeSlug
    ? learningPathState.lessons.find((item) => item.slug === learningPathState.activeSlug)
    : null;

  if (activeLesson) {
    workspace.innerHTML = renderLessonDetail(activeLesson);
    workspace.classList.remove('lesson-workspace--continue', 'lesson-workspace--unit-overview');
    return;
  }

  const selectedUnitActivities =
    hasUnits() && learningPathState.unitId ? getUnitActivities(learningPathState.unitId) : [];
  const nextLesson =
    selectedUnitActivities.find((item) => !item.completed && !item.locked) ||
    selectedUnitActivities[0] ||
    getNextRecommendedLesson();
  if (!nextLesson) return;
  workspace.innerHTML = renderContinueCard(nextLesson);
  workspace.classList.add('lesson-workspace--continue');
  workspace.classList.remove('lesson-workspace--unit-overview');
}

function renderLearningPath() {
  renderSkillGraph();
  renderLessonWorkspace();
  renderSkillCards();
  updateAiTutorContext();
}

const SKILL_LABELS = {
  learn: 'Ruta',
  listening: 'Listening',
  speaking: 'Speaking',
  reading: 'Reading',
  writing: 'Writing',
  grammar: 'Grammar',
  vocabulary: 'Vocabulary',
  dialogue: 'Dialogues'
};

// French A1's pedagogical content is authored entirely in French (see
// scripts/content/french-a1-units.js), so its skill-tab labels are French
// too - internal skill keys (reading/listening/etc., plus the new
// 'dialogue' type) stay the same for code compatibility. Every other
// language keeps the SKILL_LABELS map above unchanged.
const SKILL_LABELS_FRENCH = {
  learn: 'Parcours',
  listening: 'Compréhension orale',
  speaking: 'Expression orale',
  reading: 'Lecture',
  writing: 'Expression écrite',
  grammar: 'Grammaire',
  vocabulary: 'Vocabulaire',
  dialogue: 'Dialogues'
};

function getSkillLabel(skill, language = learningPathState.language) {
  if (language === 'french') return SKILL_LABELS_FRENCH[skill] || SKILL_LABELS[skill] || skill;
  return SKILL_LABELS[skill] || skill;
}

// Updates every repeated .level-tabs strip (one per skill section, see
// index.html) and every .skill-competency-card <h3> to match the active
// target language - these are plain static markup otherwise, so without
// this they'd keep showing English/Spanish labels no matter which
// language's course is open. Cheap full-DOM sweep, called on every
// navigation (showView) and language switch (setTargetLanguage).
function updateLevelTabLabels() {
  document.querySelectorAll('.level-tab[data-tab]').forEach((link) => {
    link.textContent = getSkillLabel(link.dataset.tab);
  });
  document.querySelectorAll('.skill-competency-card[data-skill]').forEach((card) => {
    const heading = card.querySelector('h3');
    if (heading) heading.textContent = getSkillLabel(card.dataset.skill);
  });
}

// Populates each of the 6 skill-competency-cards with real status/progress/XP
// for the current language+level, instead of the bare icon+name they show
// before the first lesson list loads.
function renderSkillCards() {
  document.querySelectorAll('.skill-competency-card').forEach((card) => {
    const skill = card.dataset.skill;
    const statusEl = card.querySelector('.skill-card-status');
    const progressBar = card.querySelector('.skill-card-progress div');
    const progressWrap = card.querySelector('.skill-card-progress');
    const xpEl = card.querySelector('.skill-card-xp');

    const lesson = learningPathState.lessons.find((item) => item.skill === skill);
    if (!lesson) {
      if (statusEl) {
        statusEl.textContent = learningPathState.lessons.length
          ? LanguagePair.t('skillNotAvailableLevel', learningPathState.bridgeLanguage)
          : LanguagePair.t('genericLoading', learningPathState.bridgeLanguage);
        statusEl.className = 'skill-card-status skill-card-status-loading';
      }
      if (progressWrap) progressWrap.hidden = true;
      if (xpEl) xpEl.textContent = '';
      return;
    }

    // Unit-aware languages (English A1 today) have up to 12 activities per
    // skill instead of one - the card becomes a library entry point, so its
    // status/progress summarize all of that skill's activities rather than
    // a single lesson's.
    if (hasUnits()) {
      const activities = getSkillActivities(skill);
      const completedCount = activities.filter((item) => item.completed).length;
      const pct = activities.length ? Math.round((completedCount / activities.length) * 100) : 0;
      if (statusEl) {
        statusEl.textContent = `${completedCount}/${activities.length} completadas`;
        statusEl.className = 'skill-card-status skill-card-status-available';
      }
      if (progressWrap) {
        progressWrap.hidden = false;
        progressWrap.setAttribute('aria-label', `Progreso: ${pct}%`);
      }
      if (progressBar) progressBar.style.width = `${pct}%`;
      if (xpEl) xpEl.textContent = `${activities.length} actividades`;
      card.setAttribute(
        'aria-label',
        `${getSkillLabel(skill)}: biblioteca, ${completedCount}/${activities.length} completadas`
      );
      return;
    }

    // Listening's status depends solely on whether public.lesson_audio has a
    // published row for this lesson (GET /api/listening/audio) - three real
    // states (spec §3): 'official' (normal+slow), 'partial' (normal only),
    // or anything else (no published row) = próximamente.
    if (skill === 'listening') {
      if (statusEl) {
        statusEl.textContent = 'Comprobando disponibilidad…';
        statusEl.className = 'skill-card-status skill-card-status-loading';
      }
      if (progressWrap) progressWrap.hidden = true;
      if (xpEl) xpEl.textContent = '';
      card.setAttribute('aria-label', 'Listening: comprobando disponibilidad');
      fetchListeningAudioStatus(lesson).then((data) => {
        if (!statusEl) return;
        const { total, attempted } = getExerciseProgress(lesson);
        const pct = total ? Math.round((attempted / total) * 100) : 0;
        if (data.status === 'official' || data.status === 'partial') {
          statusEl.textContent = data.status === 'official' ? 'Disponible' : 'Parcial';
          statusEl.className =
            data.status === 'official'
              ? 'skill-card-status skill-card-status-available'
              : 'skill-card-status skill-card-status-partial';
          if (progressWrap) {
            progressWrap.hidden = false;
            progressWrap.setAttribute('aria-label', `Progreso: ${pct}%`);
          }
          if (progressBar) progressBar.style.width = `${pct}%`;
          if (xpEl) xpEl.textContent = `+${lesson.xpReward || 20} XP`;
          card.setAttribute(
            'aria-label',
            `Listening: ${data.status === 'official' ? 'disponible' : 'parcial, sin audio lento'}, ${pct}% completado, ${lesson.xpReward || 20} XP`
          );
        } else {
          statusEl.textContent = 'Próximamente';
          statusEl.className = 'skill-card-status skill-card-status-soon';
          card.setAttribute('aria-label', 'Listening: próximamente');
        }
      });
      return;
    }

    const { total, attempted } = getExerciseProgress(lesson);
    const pct = total ? Math.round((attempted / total) * 100) : 0;
    if (statusEl) {
      statusEl.textContent = 'Disponible';
      statusEl.className = 'skill-card-status skill-card-status-available';
    }
    if (progressWrap) {
      progressWrap.hidden = false;
      progressWrap.setAttribute('aria-label', `Progreso: ${pct}%`);
    }
    if (progressBar) progressBar.style.width = `${pct}%`;
    if (xpEl) xpEl.textContent = `+${lesson.xpReward || 20} XP`;
    card.setAttribute(
      'aria-label',
      `${getSkillLabel(skill)}: disponible, ${pct}% completado, ${lesson.xpReward || 20} XP`
    );
  });
}

// ---------------------------------------------------------------------
// Dedicated skill views (Reading/Writing/Speaking/Grammar/Vocabulary each
// get their own routed view instead of swapping content inside the small
// #learning-path lesson-workspace card). Listening is now a real view too -
// see the dedicated Listening block further below for its audio-source/
// player/transcript/question logic and docs/audio-architecture.md for the
// two-source (official vs AI-generated) design.
// ---------------------------------------------------------------------

// Writes the bridge/target/level pills + "Aprenderás X con apoyo en Y"
// sentence shared by every skill view header, from the same state
// updatePathPairPreview() already uses - so it can never disagree with #learn.
function renderSkillViewHeader(section) {
  if (!section) return;
  refreshLanguagePairChrome();
  const bridgeLabel = LanguagePair
    ? LanguagePair.languageNameIn(learningPathState.bridgeLanguage, learningPathState.bridgeLanguage)
    : languageDisplayNames[learningPathState.bridgeLanguage] || learningPathState.bridgeLanguage;
  const targetLabel = LanguagePair
    ? LanguagePair.languageNameIn(learningPathState.bridgeLanguage, learningPathState.language)
    : languageDisplayNames[learningPathState.language] || learningPathState.language;
  const level = learningPathState.level;
  const bridgeEl = section.querySelector('[data-field="bridge"]');
  const targetEl = section.querySelector('[data-field="target"]');
  const levelEl = section.querySelector('[data-field="level"]');
  const sentenceEl = section.querySelector('[data-field="sentence"]');
  if (bridgeEl) bridgeEl.textContent = bridgeLabel;
  if (targetEl) targetEl.textContent = targetLabel;
  if (levelEl) levelEl.textContent = level;
  if (sentenceEl) {
    sentenceEl.textContent = LanguagePair
      ? LanguagePair.getLanguagePairLabel(learningPathState.bridgeLanguage, learningPathState.language)
      : `Aprenderás ${targetLabel} con apoyo en ${bridgeLabel}.`;
  }
}

function openChangeCombinationPopover() {
  const popover = document.getElementById('changeComboPopover');
  if (!popover) return;
  const bridgeSelect = document.getElementById('comboBridgeSelect');
  const languageSelect = document.getElementById('comboLanguageSelect');
  const levelSelect = document.getElementById('comboLevelSelect');
  if (bridgeSelect) bridgeSelect.value = learningPathState.bridgeLanguage;
  if (languageSelect) languageSelect.value = learningPathState.language;
  if (levelSelect) levelSelect.value = learningPathState.level;
  popover.hidden = false;
  popover.removeAttribute('inert');
  bridgeSelect?.focus();
}

function closeChangeCombinationPopover() {
  const popover = document.getElementById('changeComboPopover');
  if (!popover) return;
  popover.hidden = true;
  popover.setAttribute('inert', '');
}

function applyChangeCombination() {
  const bridgeSelect = document.getElementById('comboBridgeSelect');
  const languageSelect = document.getElementById('comboLanguageSelect');
  const levelSelect = document.getElementById('comboLevelSelect');
  if (!bridgeSelect || !languageSelect || !levelSelect) return;

  if (!setBridgeLanguage(bridgeSelect.value)) return;
  if (!setTargetLanguage(languageSelect.value, { level: levelSelect.value })) return;
  closeChangeCombinationPopover();
  showView(getViewFromHash());
}

const SKILL_VIEW_RENDERERS = {
  listening: (section, lesson) => renderListeningView(section, lesson),
  reading: (section, lesson) => renderReadingView(section, lesson),
  writing: (section, lesson) => renderWritingView(section, lesson),
  speaking: (section, lesson) => renderSpeakingView(section, lesson),
  grammar: (section, lesson) => renderGrammarView(section, lesson),
  vocabulary: (section, lesson) => renderVocabularyView(section, lesson)
};

// The section's "← Volver a la ruta" link is static markup (untouched by
// renderSkillView's .skill-view-content re-renders), so its label/behavior
// is toggled in place: back-to-the-Ruta-tab by default, or back-to-this-
// skill's-library when a unit-aware language (English A1) has an activity
// open from that library. onclick assignment (not addEventListener) is
// intentionally idempotent - each call just replaces the previous handler.
function updateSkillViewBackLink(section, skill, showLibraryBack) {
  const link = section.querySelector('.back-to-route-btn');
  if (!link) return;
  if (showLibraryBack) {
    link.textContent = '← Volver a la biblioteca';
    link.href = `#${skill}`;
    link.onclick = (event) => {
      event.preventDefault();
      if (skill === 'reading') readingSpeechPlayer.teardown();
      learningPathState.activeSlug = '';
      renderSkillView(skill);
    };
  } else {
    link.textContent = '← Volver a la ruta';
    link.href = '#learn';
    link.onclick = null;
  }
}

// A grid of every activity for this skill across all units (e.g. every
// Reading activity in English A1), ordered by unit - this is what "Cuando
// el usuario seleccione Reading, debe abrir una biblioteca con todos los
// readings" asks for, instead of a single generic lesson per skill.
function renderSkillLibraryHtml(skill, activities) {
  if (!activities.length) {
    return `<p class="skill-graph-empty">No hay actividades de ${getSkillLabel(skill)} disponibles en este nivel todavía.</p>`;
  }
  const nextSlug = getNextRecommendedLesson()?.slug;
  const isListening = skill === 'listening';
  const cardsHtml = activities
    .map((item) => {
      const unit = learningPathState.units.find((u) => u.id === item.unitId);
      const duration = getLessonDurationMinutes(item);
      const xp = item.xpReward ?? item.xp_reward ?? 20;
      // Listening's badge reflects real official-audio availability (see
      // wireSkillLibrary's fetchListeningAudioStatus call below), not the
      // generic completed/locked/next state every other skill uses -
      // "disponible" must never be shown for a lesson with no lesson_audio
      // row yet.
      const state = isListening
        ? { key: 'loading', label: 'Comprobando…' }
        : getLessonStateInfo(item, false, nextSlug);
      return `
      <button type="button" class="skill-library-card skill-library-card--${state.key}" data-lesson-slug="${escapeHtml(item.slug)}">
        ${unit ? `<span class="skill-library-card-unit">Unidad ${escapeHtml(String(unit.order))} · ${escapeHtml(unit.title)}</span>` : ''}
        <span class="skill-library-card-title">${escapeHtml(item.title)}</span>
        <span class="skill-library-card-desc">${escapeHtml(item.description || '')}</span>
        <span class="skill-library-card-meta">
          ${duration ? `<span>⏱ ${escapeHtml(String(duration))} min</span>` : ''}
          <span>⭐ ${escapeHtml(String(xp))} XP</span>
          <span class="path-lesson-state path-lesson-state--${state.key}"${isListening ? ' data-listening-state' : ''}>${state.label}</span>
        </span>
      </button>
    `;
    })
    .join('');

  return `
    <p class="skill-library-intro">${activities.length} actividades de ${getSkillLabel(skill)} en ${escapeHtml(languageDisplayNames[learningPathState.language] || learningPathState.language)} ${escapeHtml(learningPathState.level)}, una por unidad.</p>
    <div class="skill-library-grid">${cardsHtml}</div>
  `;
}

function wireSkillLibrary(section, skill) {
  section.querySelectorAll('.skill-library-card').forEach((card) => {
    card.addEventListener('click', () => {
      setActiveLesson(card.dataset.lessonSlug);
      renderSkillView(skill);
      updateLearnHash(skill);
    });
  });

  // Listening only: replace each card's "Comprobando…" placeholder with the
  // real state (spec §13 - "disponible" only once at least the normal audio
  // exists in public.lesson_audio, "próximamente" otherwise). Never assumes
  // availability from local content/state, only from the same
  // GET /api/listening/audio call the player itself uses.
  if (skill !== 'listening') return;
  section.querySelectorAll('.skill-library-card').forEach((card) => {
    const slug = card.dataset.lessonSlug;
    const lesson = learningPathState.lessons.find((item) => item.slug === slug);
    const stateEl = card.querySelector('[data-listening-state]');
    if (!lesson || !stateEl) return;
    fetchListeningAudioStatus(lesson).then((data) => {
      const available = data.status === 'official';
      card.classList.remove('skill-library-card--loading');
      card.classList.add(available ? 'skill-library-card--available' : 'skill-library-card--soon');
      stateEl.className = `path-lesson-state path-lesson-state--${available ? 'available' : 'soon'}`;
      stateEl.textContent = available ? 'Disponible' : 'Próximamente';
    });
  });
}

// Dispatches to the right renderer for the currently-active skill view,
// loading lessons first if they haven't been fetched yet for this
// language/level (mirrors the loading guard the old inline card handler had).
// Unit-aware languages (English A1 today) get a library-then-detail flow
// (see renderSkillLibraryHtml/wireSkillLibrary above); every other
// language/level keeps the original single-lesson-per-skill behavior.
function renderSkillView(skill) {
  const section = document.getElementById(skill);
  if (!section) return;
  renderSkillViewHeader(section);

  const content = section.querySelector('.skill-view-content');
  if (!learningPathState.lessons.length) {
    if (content)
      content.innerHTML = `<p class="skill-graph-empty">Preparando ${getSkillLabel(skill)}…</p>`;
    updateSkillViewBackLink(section, skill, false);
    // Consult the hash here too (not just bootstrapLearningPath) - a cold
    // reload/shared link straight into a skill view (e.g.
    // #reading/french/A1/unit-02/lesson-slug) reaches this branch before
    // bootstrapLearningPath's own restore runs, since lessons are still
    // empty at that point. Loading with the hash's language/level here
    // avoids a flash of the wrong language before the correct one loads.
    const hashState = parseLearnHashState();
    loadLearningPath({
      language: hashState.language || learningPathState.language,
      level: hashState.level || learningPathState.level,
      restoreUnitId: hashState.unitId,
      restoreSlug: hashState.lessonSlug
    }).then(() => renderSkillView(skill));
    return;
  }

  if (hasUnits()) {
    const activities = getSkillActivities(skill);
    const selected = activities.find((item) => item.slug === learningPathState.activeSlug);
    section.dataset.activeLessonSlug = selected?.slug || '';

    if (!selected) {
      section.querySelector('.unit-learning-sequence')?.remove();
      if (content) content.innerHTML = renderSkillLibraryHtml(skill, activities);
      updateSkillViewBackLink(section, skill, false);
      wireSkillLibrary(section, skill);
      return;
    }

    updateSkillViewBackLink(section, skill, true);
    renderSkillUnitSequence(section, selected);
    SKILL_VIEW_RENDERERS[skill]?.(section, selected);
    return;
  }

  const lesson = learningPathState.lessons.find((item) => item.skill === skill);
  section.dataset.activeLessonSlug = lesson?.slug || '';
  updateSkillViewBackLink(section, skill, false);
  if (!lesson) {
    if (content)
      content.innerHTML = `<p class="skill-graph-empty">No hay lección de ${getSkillLabel(skill)} disponible en este nivel todavía.</p>`;
    return;
  }

  renderSkillUnitSequence(section, lesson);
  SKILL_VIEW_RENDERERS[skill]?.(section, lesson);
}

// Renders every paragraph of the reading as visible text - this is the
// single source of truth for what's on screen and in the printed PDF alike
// (nothing else duplicates this markup). Each sentence is wrapped in its
// own span carrying the same segmentIndex buildReadingSegments() assigns it
// (both walk the exact same paragraphs via getReadingParagraphs() and the
// same splitReadingSentences()), so the audio player can highlight
// whichever sentence is currently being spoken via a plain class toggle -
// see updateReadingHighlight() - without touching which text is visible,
// scrolling, or re-rendering anything.
function renderReadingParagraphsHtml(paragraphs) {
  let segmentIndex = 1; // 0 is the lesson title - see buildReadingSegments()
  return paragraphs
    .map((paragraph) => {
      const sentences = splitReadingSentences(paragraph);
      if (!sentences.length) return '';
      const spansHtml = sentences
        .map((sentence) => {
          const span = `<span class="reading-sentence" data-segment-index="${segmentIndex}">${escapeHtml(sentence)}</span>`;
          segmentIndex += 1;
          return span;
        })
        .join(' ');
      return `<p>${spansHtml}</p>`;
    })
    .join('');
}

const readingTranslationCache = new Map();
let readingSelectionState = null;
let readingSelectionRequestId = 0;
let lastReadingTap = null;
let lastReadingTouchTranslationAt = 0;

function ensureReadingTranslationPopover() {
  let popover = document.getElementById('readingTranslationPopover');
  if (popover) return popover;
  popover = document.createElement('aside');
  popover.id = 'readingTranslationPopover';
  popover.className = 'reading-translation-popover';
  popover.hidden = true;
  popover.setAttribute('role', 'dialog');
  popover.setAttribute('aria-label', 'Traductor contextual de ANDERGO');
  document.body.appendChild(popover);
  return popover;
}

function closeReadingTranslationPopover({ clearSelection = false } = {}) {
  const popover = document.getElementById('readingTranslationPopover');
  if (popover) popover.hidden = true;
  readingSelectionRequestId += 1;
  readingSelectionState = null;
  if (clearSelection) window.getSelection()?.removeAllRanges();
}

function positionReadingTranslationPopover(popover, rect) {
  const width = Math.min(360, window.innerWidth - 24);
  const left = Math.max(12, Math.min(rect.left + rect.width / 2 - width / 2, window.innerWidth - width - 12));
  const top = Math.max(12, Math.min(rect.bottom + 10, window.innerHeight - 180));
  popover.style.width = `${width}px`;
  popover.style.left = `${left}px`;
  popover.style.top = `${top}px`;
}

function readingContextFromRange(range, term) {
  const node = range.commonAncestorContainer.nodeType === Node.TEXT_NODE
    ? range.commonAncestorContainer.parentElement
    : range.commonAncestorContainer;
  const readingText = node?.closest?.('.reading-text');
  if (!readingText || !readingText.contains(range.startContainer) || !readingText.contains(range.endContainer)) {
    return null;
  }
  if (!term || term.length > 120) return null;
  const paragraph = node.closest?.('p') || range.startContainer.parentElement?.closest?.('p');
  const context = String(paragraph?.textContent || term).replace(/\s+/g, ' ').trim().slice(0, 1000);
  const section = readingText.closest('.skill-view-section');
  const lesson = learningPathState.lessons.find(
    (item) => item.slug === section?.dataset.activeLessonSlug
  );
  return { term, context, lesson, rect: range.getBoundingClientRect() };
}

function selectedReadingContext(selection) {
  if (!selection?.rangeCount || selection.isCollapsed) return null;
  const range = selection.getRangeAt(0);
  const term = selection.toString().replace(/\s+/g, ' ').trim();
  return readingContextFromRange(range, term);
}

function isReadingWordCharacter(character) {
  return Boolean(character) && /[\p{L}\p{M}\p{N}'’\-]/u.test(character);
}

function readingWordContextAtPoint(clientX, clientY) {
  let textNode = null;
  let offset = 0;
  if (document.caretPositionFromPoint) {
    const position = document.caretPositionFromPoint(clientX, clientY);
    textNode = position?.offsetNode || null;
    offset = position?.offset || 0;
  } else if (document.caretRangeFromPoint) {
    const caretRange = document.caretRangeFromPoint(clientX, clientY);
    textNode = caretRange?.startContainer || null;
    offset = caretRange?.startOffset || 0;
  }
  if (textNode?.nodeType !== Node.TEXT_NODE || !textNode.parentElement?.closest?.('.reading-text')) {
    return null;
  }

  const text = textNode.textContent || '';
  if (!text) return null;
  let anchor = Math.min(offset, text.length - 1);
  if (!isReadingWordCharacter(text[anchor]) && anchor > 0 && isReadingWordCharacter(text[anchor - 1])) {
    anchor -= 1;
  }
  if (!isReadingWordCharacter(text[anchor])) return null;

  let start = anchor;
  let end = anchor + 1;
  while (start > 0 && isReadingWordCharacter(text[start - 1])) start -= 1;
  while (end < text.length && isReadingWordCharacter(text[end])) end += 1;
  while (start < end && /['’\-]/u.test(text[start])) start += 1;
  while (end > start && /['’\-]/u.test(text[end - 1])) end -= 1;
  if (start >= end) return null;

  const range = document.createRange();
  range.setStart(textNode, start);
  range.setEnd(textNode, end);
  const selection = window.getSelection();
  selection?.removeAllRanges();
  selection?.addRange(range);
  return readingContextFromRange(range, text.slice(start, end));
}

function openReadingTranslation(selectionData) {
  readingSelectionState = {
    ...selectionData,
    sourceLanguage: learningPathState.language,
    targetLanguage: learningPathState.bridgeLanguage
  };
  const popover = ensureReadingTranslationPopover();
  popover.hidden = false;
  positionReadingTranslationPopover(popover, selectionData.rect);
  translateReadingSelection();
}

function savedVocabularyRequiresUpgrade() {
  return (
    !authStatus.session?.access_token ||
    (authStatus.entitlements !== null && !isPremiumUser())
  );
}

function renderReadingTranslationResult(popover, state, translation) {
  const locale = getPronunciationLocale(state.sourceLanguage);
  const saveIsLocked = savedVocabularyRequiresUpgrade();
  popover.innerHTML = `
    <div class="reading-translation-card">
      <div class="reading-translation-head">
        <span>Traductor ANDERGO</span>
        <button type="button" class="reading-translation-close" aria-label="Cerrar">×</button>
      </div>
      <p class="reading-translation-term">${escapeHtml(state.term)}</p>
      <p class="reading-translation-result">${escapeHtml(translation)}</p>
      <div class="reading-translation-actions">
        <button type="button" class="secondary-btn reading-translation-listen">🔊 Escuchar</button>
        <button type="button" class="secondary-btn reading-translation-save${saveIsLocked ? ' is-premium-only' : ''}">${saveIsLocked ? '🔒 Guardar' : '＋ Guardar'}</button>
        <button type="button" class="secondary-btn reading-translation-tutor">Tutor</button>
        <button type="button" class="secondary-btn reading-translation-open">Abrir Traductor</button>
      </div>
      <span class="reading-translation-status" role="status" aria-live="polite"></span>
    </div>
  `;
  popover.querySelector('.reading-translation-close')?.addEventListener('click', () =>
    closeReadingTranslationPopover({ clearSelection: true })
  );
  popover.querySelector('.reading-translation-listen')?.addEventListener('click', () =>
    speakText(state.term, { locale, rate: getDefaultPronunciationRate(state.sourceLanguage, state.lesson?.level) })
  );
  popover.querySelector('.reading-translation-open')?.addEventListener('click', () => {
    openTranslator({
      text: state.term,
      sourceLanguage: state.sourceLanguage,
      targetLanguage: state.targetLanguage,
      returnHash: window.location.hash || '#reading',
      returnLabel: 'Volver a Reading'
    });
    closeReadingTranslationPopover({ clearSelection: true });
  });
  popover.querySelector('.reading-translation-tutor')?.addEventListener('click', () => {
    openTutorDrawer({
      skill: 'reading',
      lessonTitle: state.lesson?.title || '',
      lessonIntro: state.lesson?.description || '',
      lessonSlug: state.lesson?.slug || '',
      supportMode: 'explain',
      currentActivity: 'Comprendiendo una palabra del Reading',
      prefill: `Explícame el significado y el uso de “${state.term}” en esta oración: ${state.context}`,
      transcript: state.context,
      vocabulary: state.term
    });
    closeReadingTranslationPopover({ clearSelection: true });
  });
  popover.querySelector('.reading-translation-save')?.addEventListener('click', () =>
    saveReadingSelectionVocabulary(popover, state, translation)
  );
}

async function translateReadingSelection() {
  const state = readingSelectionState;
  const popover = ensureReadingTranslationPopover();
  if (!state) return;
  const requestId = ++readingSelectionRequestId;
  popover.innerHTML = '<div class="reading-translation-loading" role="status">Traduciendo con ANDERGO…</div>';
  const cacheKey = `${state.sourceLanguage}|${state.targetLanguage}|${state.term}|${state.context}`.toLowerCase();
  try {
    let translation = readingTranslationCache.get(cacheKey);
    if (!translation) {
      const response = await fetch(`${backendBaseUrl}/api/translate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...authHeaders() },
        body: JSON.stringify({
          text: state.term,
          context: state.context,
          sourceLanguage: state.sourceLanguage,
          targetLanguage: state.targetLanguage
        })
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok || !data.ok) throw new Error(data.message || 'No se pudo traducir esta selección.');
      translation = data.translatedText;
      readingTranslationCache.set(cacheKey, translation);
    }
    if (requestId !== readingSelectionRequestId || popover.hidden) return;
    renderReadingTranslationResult(popover, state, translation);
    positionReadingTranslationPopover(popover, state.rect);
  } catch (error) {
    if (requestId !== readingSelectionRequestId || popover.hidden) return;
    popover.innerHTML = `
      <div class="reading-translation-error">
        <p>${escapeHtml(error.message || 'No se pudo traducir esta selección.')}</p>
        <button type="button" class="secondary-btn reading-translation-open-fallback">Abrir Traductor</button>
        <button type="button" class="reading-translation-close" aria-label="Cerrar">×</button>
      </div>
    `;
    popover.querySelector('.reading-translation-open-fallback')?.addEventListener('click', () =>
      openTranslator({
        text: state.term,
        sourceLanguage: state.sourceLanguage,
        targetLanguage: state.targetLanguage,
        returnHash: window.location.hash || '#reading',
        returnLabel: 'Volver a Reading'
      })
    );
    popover.querySelector('.reading-translation-close')?.addEventListener('click', () =>
      closeReadingTranslationPopover({ clearSelection: true })
    );
  }
}

async function saveReadingSelectionVocabulary(popover, state, translation) {
  const status = popover.querySelector('.reading-translation-status');
  const item = {
    sourceLanguage: state.sourceLanguage,
    targetLanguage: state.targetLanguage,
    term: state.term,
    translation,
    context: state.context,
    lessonSlug: state.lesson?.slug || '',
    unitSlug: state.lesson?.unitId || ''
  };
  if (savedVocabularyRequiresUpgrade()) {
    if (status) status.textContent = 'Guardar palabras en Vocabulary es una función Premium.';
    openPaywallModal({
      title: 'Guardar palabras es una función Premium.',
      message: 'Desbloquea el vocabulario personal para guardar, escuchar y repasar palabras de tus lecturas.'
    });
    return;
  }
  if (!authStatus.session?.access_token) {
    if (status) status.textContent = 'Tu sesión terminó. Inicia sesión de nuevo para guardar esta palabra.';
    openModal('login');
    return;
  }
  try {
    const response = await fetch(`${backendBaseUrl}/api/vocabulary/saved`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...authHeaders() },
      body: JSON.stringify(item)
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      if (response.status === 403 && data.code === 'PREMIUM_REQUIRED') {
        authStatus.entitlements = { ...(authStatus.entitlements || {}), isPremium: false };
        openPaywallModal({
          title: 'Guardar palabras es una función Premium.',
          message: data.error
        });
      }
      throw new Error(data.error || 'No se pudo guardar esta palabra.');
    }
    if (status) status.textContent = 'Guardada en tu Vocabulary.';
    const saveButton = popover.querySelector('.reading-translation-save');
    if (saveButton) {
      saveButton.textContent = '✓ Guardada';
      saveButton.disabled = true;
    }
  } catch (error) {
    if (status) status.textContent = error.message || 'No se pudo guardar esta palabra.';
  }
}

function setupReadingSelectionTranslator() {
  const handleSelection = (pointerEvent = null) => {
    window.setTimeout(() => {
      const data =
        selectedReadingContext(window.getSelection()) ||
        (pointerEvent
          ? readingWordContextAtPoint(pointerEvent.clientX, pointerEvent.clientY)
          : null);
      if (data) openReadingTranslation(data);
    }, 0);
  };
  document.addEventListener('pointerup', (event) => {
    if (event.target.closest?.('#readingTranslationPopover')) return;
    if (!event.target.closest?.('.reading-text')) {
      lastReadingTap = null;
      closeReadingTranslationPopover();
      return;
    }
    if (event.pointerType === 'mouse') return;

    const now = Date.now();
    const previous = lastReadingTap;
    const isDoubleTap =
      previous &&
      now - previous.time <= 450 &&
      Math.hypot(event.clientX - previous.clientX, event.clientY - previous.clientY) <= 28;
    lastReadingTap = isDoubleTap
      ? null
      : { time: now, clientX: event.clientX, clientY: event.clientY };
    if (isDoubleTap) {
      lastReadingTouchTranslationAt = now;
      handleSelection(event);
    }
  });
  document.addEventListener('dblclick', (event) => {
    if (event.target.closest?.('#readingTranslationPopover')) return;
    if (!event.target.closest?.('.reading-text')) return;
    if (Date.now() - lastReadingTouchTranslationAt < 600) return;
    handleSelection(event);
  });
  document.addEventListener('keyup', (event) => {
    if (event.key === 'Escape') {
      closeReadingTranslationPopover({ clearSelection: true });
      return;
    }
    if (event.key === 'Enter' && event.target.closest?.('.reading-text')) handleSelection();
  });
  window.addEventListener('scroll', () => closeReadingTranslationPopover(), { passive: true });
  window.addEventListener('resize', () => closeReadingTranslationPopover(), { passive: true });
}

// A lightweight, Word-compatible .doc export for the active reading. The
// document is HTML by design: Microsoft Word opens it natively, while it
// keeps the exported text independent from the print dialog and preserves
// the learner's selected typeface and alignment.
function downloadReadingWord(lesson) {
  if (!lesson) return;
  const preferences = getReadingDisplayPreferences();
  const paragraphs = getReadingParagraphs(lesson);
  const comprehensionQuestions = renderPrintableExerciseList(lesson.exercises);
  const questionsHeading =
    learningPathState.language === 'french'
      ? 'Questions de compréhension'
      : learningPathState.language === 'spanish'
        ? 'Preguntas de comprensión'
        : 'Comprehension Questions';
  const fontFamily = preferences.font === 'times' ? "'Times New Roman', Times, serif" : 'Arial, sans-serif';
  const textAlign = preferences.alignment === 'justify' ? 'justify' : 'left';
  const level = lesson.level || learningPathState.level || '';
  const wordHtml = `<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>${escapeHtml(lesson.title)}</title>
<style>
  @page { margin: 2.2cm; }
  body { font-family: ${fontFamily}; color: #14213d; font-size: 12pt; line-height: 1.7; }
  h1 { color: #1d4ed8; font-size: 22pt; line-height: 1.2; margin: 0 0 8pt; }
  h2 { color: #14213d; font-size: 16pt; line-height: 1.25; margin: 26pt 0 12pt; border-bottom: 1px solid #bfdbfe; padding-bottom: 6pt; }
  .meta { color: #64748b; font-size: 10pt; margin: 0 0 24pt; }
  p { margin: 0 0 14pt; text-indent: 1.25em; text-align: ${textAlign}; }
  .skill-print-question { margin: 0 0 16pt; page-break-inside: avoid; }
  .skill-print-question p { margin: 0 0 6pt; text-indent: 0; text-align: left; }
  .skill-print-options { margin: 0; padding: 0; list-style: none; }
  .skill-print-option { margin: 0 0 4pt; padding-left: 12pt; }
</style></head><body>
  <h1>${escapeHtml(lesson.title)}</h1>
  <p class="meta">ANDERGO Language Academy${level ? ` · ${escapeHtml(level)}` : ''}</p>
  ${paragraphs.map((paragraph) => `<p>${escapeHtml(paragraph)}</p>`).join('')}
  ${comprehensionQuestions ? `<h2>${questionsHeading}</h2>${comprehensionQuestions}` : ''}
</body></html>`;
  const file = new Blob(['\ufeff', wordHtml], { type: 'application/msword;charset=utf-8' });
  const url = URL.createObjectURL(file);
  const link = document.createElement('a');
  link.href = url;
  link.download = `${String(lesson.slug || lesson.title || 'andergo-reading')
    .replace(/[^a-z0-9_-]+/gi, '-')
    .replace(/(^-|-$)/g, '') || 'andergo-reading'}.doc`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

// A plain 2-option True/False (or Vrai/Faux, or Verdadero/Falso) mcq is
// grouped under its own heading in the reading view so it reads as a
// distinct activity type, without needing a separate schema field - see
// scripts/content/english-a1-units.js (['True', 'False']),
// scripts/content/french-a1-units.js (['Vrai', 'Faux']) and Spanish content
// (['Verdadero', 'Falso']). Without 'verdadero'/'falso' here, Spanish
// true/false questions fell through into the 4-option "Preguntas de
// comprensión" section instead of their own block.
function isTrueFalseExercise(item) {
  return (
    Array.isArray(item.options) &&
    item.options.length === 2 &&
    item.options.some((opt) =>
      ['true', 'vrai', 'verdadero', 'false', 'faux', 'falso'].includes(
        optionLabel(opt).trim().toLowerCase()
      )
    )
  );
}

// Markup for the full-reading audio player (spec section A) - the only
// control surface that can move forward/back through the reading; the
// visible text below never paginates or otherwise reacts to these
// buttons. Hidden entirely (with a short explanatory message, no console
// errors) when the browser has no speechSynthesis at all - same
// graceful-degradation rule as flashcard pronunciation.
function renderReadingAudioPlayerHtml(snapshot) {
  if (!readingSpeechPlayer.isSupported()) {
    return `<p class="reading-audio-unavailable no-print">La reproducción de voz no está disponible en este dispositivo.</p>`;
  }
  const isPlaying = snapshot.state === 'playing';
  const isPaused = snapshot.state === 'paused';
  const playPauseLabel = isPlaying ? '⏸ Pausar' : isPaused ? '▶ Continuar' : '▶ Reproducir';
  const playPauseAria = isPlaying
    ? 'Pausar lectura'
    : isPaused
      ? 'Continuar lectura'
      : 'Reproducir lectura completa';
  const statusLabel = readingAudioStatusLabel(snapshot.state);
  const seekDisabled = snapshot.state === 'idle' || snapshot.state === 'error' ? 'disabled' : '';
  return `
    <div class="reading-audio-player no-print" role="group" aria-label="Reproductor de audio: escucha el texto completo de esta lectura">
      <div class="reading-audio-controls">
        <button type="button" class="reading-audio-btn reading-audio-playpause-btn${isPlaying ? ' is-active' : ''}" aria-label="${playPauseAria}">${playPauseLabel}</button>
        <button type="button" class="reading-audio-btn reading-audio-rewind-btn" aria-label="Retroceder cinco segundos" ${seekDisabled}>↶ 5 s</button>
        <button type="button" class="reading-audio-btn reading-audio-stop-btn" aria-label="Detener lectura" ${snapshot.state === 'idle' || snapshot.state === 'stopped' ? 'disabled' : ''}>⏹ Detener</button>
        <button type="button" class="reading-audio-btn reading-audio-voice-btn" aria-label="Cambiar voz" title="${snapshot.voiceName ? `Voz: ${escapeHtml(snapshot.voiceName)}` : ''}" ${snapshot.canChangeVoice ? '' : 'hidden'}>🔄 <span class="reading-audio-voice-label">${escapeHtml(snapshot.voiceLabel || '')}</span></button>
        <div class="reading-audio-rate-group" role="group" aria-label="Velocidad de lectura">
          <button type="button" class="reading-audio-rate-btn${snapshot.rateKey === 'slow' ? ' is-active' : ''}" data-rate="slow" aria-pressed="${snapshot.rateKey === 'slow'}">Lenta</button>
          <button type="button" class="reading-audio-rate-btn${snapshot.rateKey === 'normal' ? ' is-active' : ''}" data-rate="normal" aria-pressed="${snapshot.rateKey === 'normal'}">Normal</button>
        </div>
        <div class="reading-audio-progress" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${snapshot.progressPct}" aria-label="Progreso de la lectura">
          <div class="reading-audio-progress-fill" style="width:${snapshot.progressPct}%"></div>
        </div>
        <div class="reading-audio-meta">
          <span class="reading-audio-time">${formatReadingTime(snapshot.elapsedSeconds)} / ${formatReadingTime(snapshot.totalDurationSeconds)}</span>
          <span class="reading-audio-percent">${snapshot.progressPct}%</span>
          <span class="reading-audio-status" aria-live="polite">${statusLabel}</span>
        </div>
      </div>
    </div>
  `;
}

function readingAudioStatusLabel(state) {
  if (state === 'playing') return 'Leyendo…';
  if (state === 'paused') return 'En pausa';
  if (state === 'completed') return 'Lectura completa';
  return '';
}

// Patches the audio player's own DOM in place (progress bar, clock,
// button labels/states) rather than re-rendering the whole reading - this
// runs up to 4x/second while playing, and a full re-render would wipe
// focus, scroll position and any in-progress exercise selections. There is
// no other trigger for a full re-render while a reading is open: playing,
// pausing, rewinding and switching voice/rate all only ever patch this
// player's DOM and the current sentence highlight (see
// updateReadingHighlight) - the visible text never moves or reflows.
function updateReadingPlayerUI(section, snapshot) {
  const player = section.querySelector('.reading-audio-player');
  if (!player) return;

  const fill = player.querySelector('.reading-audio-progress-fill');
  if (fill) fill.style.width = `${snapshot.progressPct}%`;
  const progressWrap = player.querySelector('.reading-audio-progress');
  if (progressWrap) progressWrap.setAttribute('aria-valuenow', String(snapshot.progressPct));

  const timeEl = player.querySelector('.reading-audio-time');
  if (timeEl) {
    timeEl.textContent = `${formatReadingTime(snapshot.elapsedSeconds)} / ${formatReadingTime(snapshot.totalDurationSeconds)}`;
  }
  const pctEl = player.querySelector('.reading-audio-percent');
  if (pctEl) pctEl.textContent = `${snapshot.progressPct}%`;

  const playPauseBtn = player.querySelector('.reading-audio-playpause-btn');
  if (playPauseBtn) {
    const isPlaying = snapshot.state === 'playing';
    const isPaused = snapshot.state === 'paused';
    playPauseBtn.textContent = isPlaying ? '⏸ Pausar' : isPaused ? '▶ Continuar' : '▶ Reproducir';
    playPauseBtn.setAttribute(
      'aria-label',
      isPlaying ? 'Pausar lectura' : isPaused ? 'Continuar lectura' : 'Reproducir lectura completa'
    );
    playPauseBtn.classList.toggle('is-active', isPlaying);
  }

  const rewindBtn = player.querySelector('.reading-audio-rewind-btn');
  if (rewindBtn) rewindBtn.disabled = snapshot.state === 'idle' || snapshot.state === 'error';

  const stopBtn = player.querySelector('.reading-audio-stop-btn');
  if (stopBtn) stopBtn.disabled = snapshot.state === 'idle' || snapshot.state === 'stopped';

  const voiceBtn = player.querySelector('.reading-audio-voice-btn');
  if (voiceBtn) {
    voiceBtn.hidden = !snapshot.canChangeVoice;
    voiceBtn.title = snapshot.voiceName ? `Voz: ${snapshot.voiceName}` : '';
    const label = voiceBtn.querySelector('.reading-audio-voice-label');
    if (label) label.textContent = snapshot.voiceLabel || '';
  }

  player.querySelectorAll('.reading-audio-rate-btn').forEach((btn) => {
    const isActive = btn.dataset.rate === snapshot.rateKey;
    btn.classList.toggle('is-active', isActive);
    btn.setAttribute('aria-pressed', String(isActive));
  });

  const statusEl = player.querySelector('.reading-audio-status');
  if (statusEl) statusEl.textContent = readingAudioStatusLabel(snapshot.state);

  player.classList.toggle('is-completed', snapshot.state === 'completed');
}

// Toggles which sentence/paragraph reads as "currently being spoken" -
// pure class patch driven by the player's own segmentIndex, matching the
// data-segment-index values renderReadingParagraphsHtml() assigned. Never
// scrolls, never re-renders, never changes what text is visible.
function updateReadingHighlight(section, snapshot) {
  const prev = section.querySelector('.reading-sentence.is-speaking');
  if (prev) prev.classList.remove('is-speaking');
  if (snapshot.state !== 'playing') return;
  const current = section.querySelector(`.reading-sentence[data-segment-index="${snapshot.currentSegmentIndex}"]`);
  if (current) current.classList.add('is-speaking');
}

// Deterministic inline SVG illustration, used whenever a reading has no
// artwork of its own configured yet - keeps the illustration figure always
// present (per spec) without depending on any external image asset - a
// small, flat, pastel icon card (an open-book glyph on a soft rounded
// square), not a hero-sized gradient block. No animation: at this size a
// static icon reads as an intentional design element, while motion on
// something this small mostly reads as a distracting flicker. Same look
// for every load of the same lesson (seeded by unitId/slug), a different
// (but always muted, low-saturation) hue across units.
function buildGenericIllustrationDataUri(seed) {
  let hash = 0;
  for (let i = 0; i < seed.length; i += 1) hash = (hash * 31 + seed.charCodeAt(i)) >>> 0;
  const hue = hash % 360;
  const bg = `hsl(${hue}, 45%, 96%)`;
  const border = `hsl(${hue}, 35%, 87%)`;
  const page = `hsl(${hue}, 30%, 91%)`;
  const ink = `hsl(${hue}, 45%, 42%)`;
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 160 160"><rect x="1.5" y="1.5" width="157" height="157" rx="24" fill="${bg}" stroke="${border}" stroke-width="2"/><path d="M80 54 C62 43 38 45 28 54 L28 104 C38 95 62 93 80 104 Z" fill="${page}" stroke="${ink}" stroke-width="3" stroke-linejoin="round"/><path d="M80 54 C98 43 122 45 132 54 L132 104 C122 95 98 93 80 104 Z" fill="${page}" stroke="${ink}" stroke-width="3" stroke-linejoin="round"/><line x1="80" y1="54" x2="80" y2="104" stroke="${ink}" stroke-width="3"/><line x1="42" y1="63" x2="66" y2="59" stroke="${ink}" stroke-width="2.5" stroke-linecap="round" opacity="0.7"/><line x1="42" y1="73" x2="66" y2="69" stroke="${ink}" stroke-width="2.5" stroke-linecap="round" opacity="0.7"/><line x1="42" y1="83" x2="66" y2="79" stroke="${ink}" stroke-width="2.5" stroke-linecap="round" opacity="0.7"/><line x1="94" y1="59" x2="118" y2="63" stroke="${ink}" stroke-width="2.5" stroke-linecap="round" opacity="0.7"/><line x1="94" y1="69" x2="118" y2="73" stroke="${ink}" stroke-width="2.5" stroke-linecap="round" opacity="0.7"/><line x1="94" y1="79" x2="118" y2="83" stroke="${ink}" stroke-width="2.5" stroke-linecap="round" opacity="0.7"/></svg>`;
  return `data:image/svg+xml,${encodeURIComponent(svg)}`;
}

// Each reading can define its own illustration (lesson.reading.illustration
// = { src, alt }, see scripts/content/*-a1-units.js), falling back to a
// unit-level one (lesson.unitIllustration) and finally to the generated
// placeholder above, so the figure is never a broken image while real
// artwork hasn't been authored for a given lesson yet.
function resolveReadingIllustration(lesson) {
  const chosen = lesson.reading?.illustration?.src
    ? lesson.reading.illustration
    : lesson.unitIllustration?.src
      ? lesson.unitIllustration
      : null;
  const seed = lesson.unitId || lesson.slug || lesson.title || 'andergo';
  return {
    src: chosen?.src || null,
    fallbackSrc: buildGenericIllustrationDataUri(String(seed)),
    alt: chosen?.alt || lesson.title || ''
  };
}

// When a real illustration path is configured but the asset hasn't been
// uploaded yet, onerror swaps it for the generated placeholder instead of
// showing a broken-image icon.
function renderReadingIllustrationHtml(lesson) {
  const { src, fallbackSrc, alt } = resolveReadingIllustration(lesson);
  const onerror = src ? ` onerror="this.onerror=null;this.src='${fallbackSrc}';"` : '';
  return `
    <figure class="reading-illustration no-print">
      <img src="${escapeHtml(src || fallbackSrc)}" alt="${escapeHtml(alt)}" loading="lazy"${onerror}>
    </figure>
  `;
}

// ---------------------------------------------------------------------
// Reading comprehension quiz ("Preguntas de comprensión"): batch-graded,
// four-option (A/B/C/D) multiple choice. Picking an option only stores it
// locally (single-select, picking another swaps it) - nothing is checked
// until "Calificar" is pressed, which grades every question against the
// real answer key (kept server-side only, never shipped to the browser -
// see lib/lessonsService.js#sanitizeExerciseForClient/checkAnswer) via the
// same /check-answer endpoint the rest of the app already uses, then shows
// a 0-100 score plus per-question correct/incorrect feedback. Kept
// deliberately separate from renderLessonExercise/.mcq-option (shared by
// Listening/Grammar/dialogue exercises, which keep their existing
// immediate-grading behavior) - only Reading's comprehension section
// changes shape here.
const readingComprehensionState = new Map();

function getReadingComprehensionRuntime(slug) {
  let runtime = readingComprehensionState.get(slug);
  if (!runtime) {
    runtime = {
      selections: {},
      results: {},
      gradingItems: {},
      graded: false,
      grading: false,
      error: ''
    };
    readingComprehensionState.set(slug, runtime);
  }
  return runtime;
}

function resetReadingComprehensionRuntime(slug) {
  readingComprehensionState.set(slug, {
    selections: {},
    results: {},
    gradingItems: {},
    graded: false,
    grading: false,
    error: ''
  });
}

// 90-100/80-89/70-79/60-69/<60 score bands - wording per spec, never
// "reprobado", for a platform used by kids as young as ~9.
function readingComprehensionScoreMessage(score) {
  const french = isFrenchAdvancedImmersion();
  if (score >= 90) return french ? 'Excellente compréhension du texte !' : '¡Excelente comprensión del texto!';
  if (score >= 80) return french ? 'Très bon travail !' : '¡Muy buen trabajo!';
  if (score >= 70) return french ? 'Bon travail. Continuez à vous entraîner.' : 'Buen trabajo. Sigue practicando.';
  if (score >= 60) return french ? 'Vous progressez. Relisez le texte.' : 'Vas avanzando. Revisa el texto nuevamente.';
  return french ? 'Relisez le texte et réessayez.' : 'Repasa la lectura e inténtalo otra vez.';
}

function renderReadingComprehensionResultHtml(runtime, total) {
  const correctCount = Object.values(runtime.results).filter((r) => r.correct).length;
  const incorrectCount = total - correctCount;
  const score = total > 0 ? Math.round((correctCount / total) * 100) : 0;
  const french = isFrenchAdvancedImmersion();
  const persistenceHtml = !authStatus.session?.access_token
    ? `<button type="button" class="primary-btn reading-comp-signup-btn">${french ? 'Inscrivez-vous gratuitement pour enregistrer votre résultat, vos XP et vos succès' : 'Regístrate gratis para guardar tu resultado, XP y logros'}</button>`
    : runtime.serverResult
      ? `<p class="reading-comp-result-detail">+${runtime.serverResult.earnedXp || 0} XP ${french ? 'enregistrés' : 'registrados'}</p>`
      : '';
  return `
    <div class="reading-comp-result">
      <p class="reading-comp-result-score">${french ? 'Score' : 'Puntuación'} : ${score}/100</p>
      <p class="reading-comp-result-detail">${correctCount} ${french ? 'sur' : 'de'} ${total} ${french ? 'bonnes réponses' : 'respuestas correctas'}</p>
      <p class="reading-comp-result-detail">${incorrectCount} ${french ? `réponse${incorrectCount === 1 ? '' : 's'} incorrecte${incorrectCount === 1 ? '' : 's'}` : `incorrecta${incorrectCount === 1 ? '' : 's'}`} · ${score}%</p>
      <p class="reading-comp-result-message">${escapeHtml(readingComprehensionScoreMessage(score))}</p>
      ${persistenceHtml}
    </div>
  `;
}

function getLocalExerciseCorrectKey(item) {
  if (item?.answer == null) return null;
  const answerIndex = Number(item.answer);
  if (!Number.isInteger(answerIndex)) return null;
  const option = item.options?.[answerIndex];
  return option != null ? optionKey(option, answerIndex) : null;
}

function renderReadingComprehensionQuiz(lesson, entries) {
  const french = isFrenchAdvancedImmersion();
  if (!entries.length) {
    return `<p class="skill-graph-empty">${french ? 'Aucune question de compréhension pour cette leçon.' : 'No hay preguntas de comprensión para esta lección.'}</p>`;
  }

  const runtime = getReadingComprehensionRuntime(lesson.slug);
  const total = entries.length;

  const questionsHtml = entries
    .map(({ item, exerciseIndex }, displayIndex) => {
      const selectedKey = runtime.selections[exerciseIndex];
      const result = runtime.results[exerciseIndex] || null;
      const isChecking = Boolean(runtime.gradingItems?.[exerciseIndex]);

      const optionsHtml = (item.options || [])
        .map((option, optionIndex) => {
          const key = optionKey(option, optionIndex);
          const letter = String.fromCharCode(65 + optionIndex);
          const isSelected = selectedKey != null && String(selectedKey) === String(key);
          const classes = ['reading-comp-option'];
          if (isSelected) classes.push('is-selected');
          if (result) {
            const isCorrectOption =
              result.correctOption != null && String(result.correctOption) === String(key);
            if (isSelected) classes.push(result.correct ? 'is-correct' : 'is-incorrect');
            else if (isCorrectOption) classes.push('is-correct-answer');
          }
          const statusIcon = isSelected && result ? (result.correct ? '✓' : '×') : '';
          const disabled = runtime.graded || runtime.grading || isChecking || result ? 'disabled' : '';
          return `
            <button type="button" class="${classes.join(' ')}" data-option-key="${escapeHtml(String(key))}" ${disabled}>
              <span class="reading-comp-option-letter">${letter}</span>
              <span class="reading-comp-option-text">${escapeHtml(optionLabel(option))}</span>
              ${statusIcon ? `<span class="reading-comp-option-status" aria-hidden="true">${statusIcon}</span>` : ''}
            </button>
          `;
        })
        .join('');

      let feedbackHtml = '';
      if (result) {
        feedbackHtml = result.correct
          ? `<span class="reading-comp-feedback is-correct">✅ ${french ? 'Correct' : 'Correcto'}</span>`
          : `<span class="reading-comp-feedback is-incorrect">❌ ${french ? 'Incorrect' : 'Incorrecto'}${result.correctLabel ? ` · ${french ? 'Bonne réponse' : 'Respuesta correcta'} : ${escapeHtml(result.correctLabel)}` : ''}</span>`;
      }

      return `
        <div class="reading-comp-question" data-exercise-index="${exerciseIndex}" data-lesson-slug="${escapeHtml(lesson.slug || '')}">
          <strong class="reading-comp-prompt">${displayIndex + 1}. ${escapeHtml(item.prompt)}</strong>
          <div class="reading-comp-options">${optionsHtml}</div>
          ${isChecking ? `<span class="reading-comp-feedback">${french ? 'Vérification de la réponse…' : 'Comprobando respuesta…'}</span>` : ''}
          ${feedbackHtml}
        </div>
      `;
    })
    .join('');

  const answeredCount = entries.filter(
    ({ exerciseIndex }) => runtime.selections[exerciseIndex] != null
  ).length;
  const allAnswered =
    answeredCount === total &&
    entries.every(({ exerciseIndex }) => runtime.results[exerciseIndex] != null);

  const actionsHtml = runtime.graded
    ? `<button type="button" class="primary-btn reading-comp-retry-btn" data-lesson-slug="${escapeHtml(lesson.slug)}">${french ? 'Réessayer' : 'Intentar de nuevo'}</button>`
    : `
      <button type="button" class="primary-btn reading-comp-submit-btn" data-lesson-slug="${escapeHtml(lesson.slug)}" ${allAnswered && !runtime.grading ? '' : 'disabled'}>${runtime.grading ? (french ? 'Évaluation…' : 'Evaluando...') : (french ? 'Évaluer' : 'Evaluar')}</button>
      ${!allAnswered ? `<p class="reading-comp-hint">${french ? 'Répondez à toutes les questions avant l’évaluation.' : 'Responde todas las preguntas antes de evaluar.'}</p>` : ''}
    `;

  const errorHtml = runtime.error ? `<p class="reading-comp-error">${escapeHtml(runtime.error)}</p>` : '';
  const resultHtml = runtime.graded ? renderReadingComprehensionResultHtml(runtime, total) : '';

  return `
    <div class="reading-comp-quiz">
      ${questionsHtml}
      <div class="reading-comp-actions">${actionsHtml}</div>
      ${errorHtml}
      ${resultHtml}
    </div>
  `;
}

const READING_DISPLAY_STORAGE_KEY = 'andergoReadingDisplay';

function getReadingDisplayPreferences() {
  try {
    const saved = JSON.parse(localStorage.getItem(READING_DISPLAY_STORAGE_KEY) || '{}');
    return {
      size: ['small', 'normal', 'large'].includes(saved.size) ? saved.size : 'normal',
      font: ['arial', 'times', 'sans', 'serif'].includes(saved.font)
        ? saved.font === 'sans'
          ? 'arial'
          : saved.font === 'serif'
            ? 'times'
            : saved.font
        : 'arial',
      alignment: ['left', 'justify'].includes(saved.alignment) ? saved.alignment : 'left'
    };
  } catch {
    return { size: 'normal', font: 'arial', alignment: 'left' };
  }
}

function updateStartLearningButton() {
  const button = document.getElementById('pathStartLearningBtn');
  if (!button) return;
  const labels = {
    english: 'Learn',
    french: 'Apprendre',
    spanish: 'Aprender'
  };
  const label = labels[learningPathState.language] || 'Learn';
  button.textContent = label;
  button.setAttribute(
    'aria-label',
    `${label}: ${languageDisplayNames[learningPathState.language] || learningPathState.language} ${learningPathState.level}`
  );
}

function updateLanguagePreviewSelection() {
  document.querySelectorAll('.language-preview-card[data-preview-language]').forEach((card) => {
    const selected = card.dataset.previewLanguage === learningPathState.language;
    card.classList.toggle('is-selected', selected);
    card.setAttribute('aria-current', selected ? 'true' : 'false');
    const button = card.querySelector('.language-preview-btn');
    if (button) button.textContent = selected ? 'Idioma seleccionado' : 'Seleccionar idioma';
  });
}

function setReadingDisplayPreferences(preferences) {
  try {
    localStorage.setItem(READING_DISPLAY_STORAGE_KEY, JSON.stringify(preferences));
  } catch {
    // The controls still work for the current reading when storage is unavailable.
  }
}

function applyReadingDisplayPreferences(area, preferences) {
  if (!area) return;
  area.dataset.readingSize = preferences.size;
  area.dataset.readingFont = preferences.font;
  area.dataset.readingAlignment = preferences.alignment;
  area.querySelectorAll('.reading-size-btn').forEach((button) => {
    const isActive = button.dataset.readingSize === preferences.size;
    button.classList.toggle('is-active', isActive);
    button.setAttribute('aria-pressed', String(isActive));
  });
  const fontSelect = area.querySelector('.reading-font-select');
  if (fontSelect) {
    fontSelect.value = preferences.font;
  }
  const alignButton = area.querySelector('.reading-align-btn');
  if (alignButton) {
    const justified = preferences.alignment === 'justify';
    alignButton.textContent = justified
      ? advancedFrenchText('↤ Alinear a la izquierda', '↤ Aligner à gauche')
      : advancedFrenchText('☰ Justificar', '☰ Justifier');
    alignButton.setAttribute('aria-pressed', String(justified));
  }
}

function renderReadingReferencesHtml(references) {
  const items = (Array.isArray(references) ? references : [])
    .filter((reference) => reference && reference.title && /^https:\/\//i.test(String(reference.url || '')))
    .map((reference) => {
      const author = reference.author ? `${escapeHtml(reference.author)}. ` : '';
      const year = reference.year ? ` (${escapeHtml(reference.year)}).` : '';
      return `<li>${author}<a href="${escapeHtml(reference.url)}" target="_blank" rel="noopener noreferrer"><cite>${escapeHtml(reference.title)}</cite></a>${year}</li>`;
    })
    .join('');

  if (!items) return '';
  return `
    <section class="reading-references" aria-labelledby="reading-references-title">
      <h4 id="reading-references-title">References</h4>
      <ol>${items}</ol>
    </section>
  `;
}

function renderReadingView(section, lesson) {
  const content = section.querySelector('.skill-view-content');
  if (!content) return;
  const { total, attempted } = getExerciseProgress(lesson);
  const pct = total ? Math.round((attempted / total) * 100) : 0;
  const paragraphs = getReadingParagraphs(lesson);
  // Only show a separate description line when it's distinct from the
  // reading body itself - if neither reading.parts nor reading.text is set,
  // getReadingParagraphs() above falls back to lesson.description as the
  // body, and repeating it here would duplicate the same text on screen.
  const hasDedicatedReadingBody =
    (Array.isArray(lesson.reading?.parts) && lesson.reading.parts.length > 0) || Boolean(lesson.reading?.text);
  const vocabHtml = (lesson.vocabulary || [])
    .map(
      (item) => `
    <div class="reading-vocab-item">
      <strong>${escapeHtml(item.word)}</strong>
      <span class="reading-vocab-support" hidden>${escapeHtml(resolveVocabTranslation(item))}</span>
    </div>
  `
    )
    .join('');
  // Keep each exercise's real position in lesson.exercises (not its position
  // within this filtered subset) - check-answer grades by that real index
  // server-side (lib/lessonsService.js#checkAnswer), and non-mcq exercises
  // interleaved in the source data would otherwise desync the index sent
  // from the one actually graded.
  const mcqEntries = (lesson.exercises || [])
    .map((item, exerciseIndex) => ({ item, exerciseIndex }))
    .filter(({ item }) => item.type === 'mcq');
  // True/false questions are not shown in Reading (product decision - only
  // the 4-option comprehension quiz is graded here) - excluded so they never
  // leak into it either.
  const comprehensionEntries = mcqEntries.filter(({ item }) => !isTrueFalseExercise(item));
  const exercisesHtml = renderReadingComprehensionQuiz(lesson, comprehensionEntries);

  // Attaching is a no-op when this is the same lesson already loaded -
  // continuous playback survives the DOM rebuild below either way, since
  // nothing during playback (play/pause/rewind/advance/restart/voice/rate)
  // ever triggers another full re-render - see updateReadingPlayerUI/
  // updateReadingHighlight below, which patch this render's DOM in place.
  readingSpeechPlayer.attach(lesson, learningPathState.language);
  const audioSnapshot = readingSpeechPlayer.getSnapshot();
  const audioPlayerHtml = renderReadingAudioPlayerHtml(audioSnapshot);
  const illustrationHtml = renderReadingIllustrationHtml(lesson);
  const durationLabel = lesson.estimatedMinutes ? `${lesson.estimatedMinutes} min · ` : '';
  // Full reading text + vocabulary word list, reused as context for both the
  // Tutor shortcuts (data-tutor-transcript/-vocabulary) and the "Traducir
  // este texto" shortcut below - so both actually know what's on screen
  // instead of just a generic prompt string.
  const readingTranscript = paragraphs.join(' ');
  const readingVocabWords = (lesson.vocabulary || []).map((item) => item.word).join(', ');
  const hasVocabulary = Boolean(vocabHtml);
  const displayPreferences = getReadingDisplayPreferences();
  const referencesHtml = renderReadingReferencesHtml(lesson.reading?.references);
  const french = isFrenchAdvancedImmersion();

  content.innerHTML = `
    <div class="reading-print-area skill-print-area" data-reading-size="${displayPreferences.size}" data-reading-font="${displayPreferences.font}" data-reading-alignment="${displayPreferences.alignment}">
      ${renderSkillPrintHeaderHtml(lesson)}
      <div class="reading-progress-bar no-print" role="progressbar" aria-valuenow="${pct}" aria-valuemin="0" aria-valuemax="100"><div style="width:${pct}%"></div></div>
      <div class="reading-reader-card">
        ${audioPlayerHtml}
        <div class="reading-display-controls no-print" aria-label="${french ? 'Réglages de lecture' : 'Ajustes de lectura'}">
          <span class="reading-display-label">${french ? 'Taille du texte' : 'Tamaño del texto'}</span>
          <div class="reading-size-controls" role="group" aria-label="${french ? 'Taille du texte' : 'Tamaño del texto'}">
            <button type="button" class="reading-display-btn reading-size-btn" data-reading-size="small" aria-label="${french ? 'Petit texte' : 'Texto pequeño'}">A−</button>
            <button type="button" class="reading-display-btn reading-size-btn" data-reading-size="normal" aria-label="${french ? 'Texte normal' : 'Texto normal'}">A</button>
            <button type="button" class="reading-display-btn reading-size-btn" data-reading-size="large" aria-label="${french ? 'Grand texte' : 'Texto grande'}">A+</button>
          </div>
          <label class="reading-font-control">${french ? 'Police' : 'Fuente'}
            <select class="reading-font-select" aria-label="${french ? 'Police du texte' : 'Tipo de letra del texto'}">
              <option value="arial">Arial</option>
              <option value="times">Times New Roman</option>
            </select>
          </label>
          <button type="button" class="reading-display-btn reading-align-btn" aria-pressed="false">☰ Justificar</button>
        </div>
        <div class="reading-hero reading-hero--near-text">
          <div class="reading-heading">
            <p class="reading-level-tag">${durationLabel}${escapeHtml(lesson.level)} · ${escapeHtml(getSkillLabel('reading'))}</p>
            <h3><span class="reading-sentence" data-segment-index="0">${escapeHtml(lesson.title)}</span></h3>
            ${hasDedicatedReadingBody && lesson.description ? `<p class="reading-description">${escapeHtml(lesson.description)}</p>` : ''}
          </div>
          ${illustrationHtml}
        </div>
        <article class="reading-text">${renderReadingParagraphsHtml(paragraphs)}</article>
        ${referencesHtml}
        <p class="reading-selection-hint reading-selection-hint--footer no-print">
          <span aria-hidden="true">🌐</span>
          ${french ? 'Double-cliquez sur un mot ou touchez-le deux fois pour le traduire, l’écouter ou interroger le Tutor. Les membres Premium peuvent aussi l’enregistrer dans Vocabulary.' : 'Haz doble clic en una palabra o tócala dos veces para traducirla, escucharla o consultarla con el Tutor. Los usuarios Premium también pueden guardarla en Vocabulary.'}
        </p>
      </div>
      <div class="reading-vocab-section no-print"${hasVocabulary ? '' : ' hidden'}>
        <div class="reading-vocab-actions">
          <button type="button" class="secondary-btn reading-toggle-vocab" aria-expanded="false">${french ? 'Voir le vocabulaire' : 'Ver vocabulario'}</button>
          <button type="button" class="secondary-btn reading-toggle-support" aria-pressed="false">${escapeHtml(french ? "Afficher l’aide" : 'Mostrar ayuda en español')}</button>
        </div>
        <div class="reading-vocab-list" hidden>${vocabHtml}</div>
      </div>
      <div class="reading-questions">
        <h4>${french ? 'Questions de compréhension' : 'Preguntas de comprensión'}</h4>
        ${exercisesHtml}
      </div>
      <div class="reading-print-answer-space skill-print-answer-space print-only">
        <h4>${french ? 'Vos réponses' : 'Tus respuestas'}</h4>
        <div class="reading-print-answer-lines"><div></div><div></div><div></div><div></div></div>
      </div>
    </div>
    <div class="skill-view-tutor-cta no-print">
      <button type="button" class="secondary-btn open-tutor-btn" data-tutor-prompt="${french ? 'Explique-moi ce paragraphe' : 'Explícame este párrafo'} : ${escapeHtml(paragraphs[0] || lesson.title)}" data-support-mode="explain" data-tutor-transcript="${escapeHtml(readingTranscript)}" data-tutor-vocabulary="${escapeHtml(readingVocabWords)}">${french ? 'Expliquer ce paragraphe' : 'Explicar este párrafo'}</button>
      <button type="button" class="secondary-btn open-tutor-btn" data-tutor-prompt="${french ? 'Résume cette lecture en deux phrases.' : 'Resume esta lectura en un par de frases.'}" data-support-mode="explain" data-tutor-transcript="${escapeHtml(readingTranscript)}" data-tutor-vocabulary="${escapeHtml(readingVocabWords)}">${french ? 'Résumer avec le Tutor IA' : 'Resumir con Tutor IA'}</button>
      <button type="button" class="secondary-btn open-tutor-btn" data-tutor-prompt="${french ? 'Donne-moi un indice sans révéler la réponse.' : 'Dame una pista para responder las preguntas de comprensión, sin darme la respuesta.'}" data-support-mode="hint" data-tutor-transcript="${escapeHtml(readingTranscript)}">${french ? 'Demander un indice' : 'Pedir pista'}</button>
      <button type="button" class="secondary-btn open-tutor-btn" data-tutor-prompt="${french ? 'Crée une nouvelle question de compréhension sur ce texte.' : 'Crea otra pregunta de comprensión sobre este texto.'}" data-support-mode="practice" data-tutor-transcript="${escapeHtml(readingTranscript)}">${french ? 'Créer une autre question' : 'Crear otra pregunta'}</button>
      <button type="button" class="secondary-btn open-translator-btn" data-translate-text="${escapeHtml(readingTranscript)}" data-return-label="${french ? 'Retour à Reading' : 'Volver a Reading'}">${french ? 'Traduire ce texte' : 'Traducir este texto'}</button>
      <button type="button" class="primary-btn reading-print-btn">${french ? 'Télécharger en PDF' : 'Descargar PDF'}</button>
      <button type="button" class="secondary-btn reading-word-btn">${french ? 'Télécharger en Word' : 'Descargar Word'}</button>
    </div>
  `;
  applyReadingDisplayPreferences(content.querySelector('.reading-print-area'), displayPreferences);

  // Re-registered on every render (cheap, idempotent) so the player's
  // callbacks always point at the DOM this exact render produced, even
  // though attach() above only actually resets playback state when the
  // lesson changes. Both callbacks only ever patch existing DOM in place -
  // see updateReadingPlayerUI/updateReadingHighlight - so none of them
  // re-render or reflow the visible reading text.
  readingSpeechPlayer.setHandlers({
    onUpdate: (snap) => {
      updateReadingPlayerUI(section, snap);
      updateReadingHighlight(section, snap);
    }
  });
}

function renderWritingView(section, lesson) {
  const content = section.querySelector('.skill-view-content');
  if (!content) return;
  const writingExercise = (lesson.exercises || []).find((item) => item.type === 'writing');
  const draftKey = `andergoWritingDraft:${lesson.slug}`;
  const savedDraft = localStorage.getItem(draftKey) || '';
  const wordLimit = 80;

  content.innerHTML = `
    <h3>${escapeHtml(lesson.title)}</h3>
    <p class="writing-consigna">${escapeHtml(writingExercise?.prompt || lesson.mission || lesson.intro || '')}</p>
    <div class="writing-model">
      <strong>Modelo</strong>
      <p>${escapeHtml(lesson.dialogue?.[0]?.line || lesson.phrases?.[0] || '')}</p>
    </div>
    <div class="writing-connectors">
      <strong>Vocabulario y conectores</strong>
      <div class="writing-connectors-list">${(lesson.phrases || []).map((p) => `<span>${escapeHtml(p)}</span>`).join('')}</div>
    </div>
    <label class="writing-editor-label" for="writingEditor">Tu texto <span class="writing-word-limit">(límite sugerido: ${wordLimit} palabras)</span></label>
    <textarea id="writingEditor" class="writing-editor" rows="10">${escapeHtml(savedDraft)}</textarea>
    <p class="writing-word-count" id="writingWordCount">0 palabras</p>
    <div class="skill-view-tutor-cta">
      <button type="button" class="secondary-btn writing-review-btn" data-support-mode="review-grammar">Revisar gramática</button>
      <button type="button" class="secondary-btn writing-review-btn" data-support-mode="review-vocabulary">Mejorar vocabulario</button>
      <button type="button" class="secondary-btn writing-review-btn" data-support-mode="review-coherence">Revisar coherencia</button>
      <button type="button" class="secondary-btn writing-review-btn" data-support-mode="explain-errors">Explicar errores en español</button>
      <button type="button" class="secondary-btn writing-review-btn" data-support-mode="hint">Darme una pista</button>
    </div>
    <div class="writing-tutor-panel" id="writingTutorPanel" hidden>
      <div class="writing-tutor-original"><strong>Original</strong><p></p></div>
      <div class="writing-tutor-suggestion"><strong>Sugerencia del Tutor IA</strong><p></p></div>
      <div class="writing-tutor-current" hidden><strong>Tu texto actual</strong><p></p></div>
      <div class="writing-tutor-actions">
        <button type="button" class="secondary-btn writing-compare-btn">Comparar versiones</button>
        <button type="button" class="secondary-btn writing-reject-btn">Rechazar</button>
        <button type="button" class="primary-btn writing-accept-btn">Aceptar</button>
      </div>
    </div>
  `;

  const editor = content.querySelector('#writingEditor');
  const wordCountEl = content.querySelector('#writingWordCount');
  const updateWordCount = () => {
    const words = editor.value.trim().split(/\s+/).filter(Boolean).length;
    wordCountEl.textContent = `${words} palabra${words === 1 ? '' : 's'}`;
    localStorage.setItem(draftKey, editor.value);
  };
  editor?.addEventListener('input', updateWordCount);
  updateWordCount();
}

// Speaking recorder state - kept in memory only, never in localStorage/
// sessionStorage/IndexedDB. teardownSpeakingResources() is the single place
// that releases the mic, stops the MediaRecorder, stops any live
// transcription, and revokes the object URL; resetSpeakingRecorder() calls
// it and returns the UI to idle. Both are safe to call at any time,
// including when nothing is active (no-op).
let speakingRecorder = {
  mediaRecorder: null,
  stream: null,
  recordedChunks: [],
  audioBlob: null,
  audioUrl: null,
  audioEl: null,
  mimeType: '',
  timerId: null,
  elapsedSeconds: 0,
  status: 'idle', // idle | requesting | recording | stopped | denied | unsupported
  config: { minimumSeconds: 5, targetSeconds: 30, maximumSeconds: 60, allowShortSubmission: false },
  container: null,
  // Transcription (Web Speech API) runs alongside MediaRecorder purely to
  // produce editable text for the corrector (§5) - it never replaces the
  // audio capture above, and nothing about it is ever sent anywhere itself,
  // only the resulting plain text. `recognition` is the live instance (null
  // when not listening); `transcriptEdited` stops live results from
  // clobbering text the student has started correcting by hand.
  recognition: null,
  recognitionSupported: null,
  transcript: '',
  transcriptEdited: false,
  // Tutor IA correction result for the current transcript - cleared
  // together with everything else on delete/redo/teardown.
  correction: { status: 'idle', text: '', error: '' } // idle | loading | done | error
};

function pickSpeakingMimeType() {
  if (typeof MediaRecorder === 'undefined' || !MediaRecorder.isTypeSupported) return '';
  const candidates = [
    'audio/webm;codecs=opus',
    'audio/webm',
    'audio/ogg;codecs=opus',
    'audio/ogg',
    'audio/mp4'
  ];
  return candidates.find((type) => MediaRecorder.isTypeSupported(type)) || '';
}

function teardownSpeakingResources() {
  const r = speakingRecorder;
  if (r.timerId) {
    window.clearInterval(r.timerId);
    r.timerId = null;
  }
  if (r.mediaRecorder && r.mediaRecorder.state !== 'inactive') {
    try {
      r.mediaRecorder.stop();
    } catch {
      /* already stopped/inactive */
    }
  }
  r.stream?.getTracks().forEach((track) => track.stop());
  if (r.recognition) {
    try {
      r.recognition.stop();
    } catch {
      /* already stopped */
    }
    r.recognition = null;
  }
  if (r.audioEl) {
    try {
      r.audioEl.pause();
    } catch {
      /* ignore */
    }
    r.audioEl.src = '';
  }
  if (r.audioUrl) URL.revokeObjectURL(r.audioUrl);
  r.mediaRecorder = null;
  r.stream = null;
  r.recordedChunks = [];
  r.audioBlob = null;
  r.audioUrl = null;
  r.audioEl = null;
  r.elapsedSeconds = 0;
  r.transcript = '';
  r.transcriptEdited = false;
  r.correction = { status: 'idle', text: '', error: '' };
}

// Called on: Eliminar, before Volver a grabar, on lesson/language/skill
// navigation (showView), and on window unload - covers every cleanup
// trigger the feature requires without needing a cleanup call at each site.
function resetSpeakingRecorder() {
  teardownSpeakingResources();
  speakingRecorder.status = 'idle';
  if (speakingRecorder.container && document.body.contains(speakingRecorder.container)) {
    updateSpeakingUI(speakingRecorder.container);
  }
}

function formatSpeakingTime(totalSeconds) {
  const m = Math.floor(totalSeconds / 60);
  const s = totalSeconds % 60;
  return `${m}:${String(s).padStart(2, '0')}`;
}

function updateSpeakingCorrectButtonState(container) {
  const r = speakingRecorder;
  const btn = container.querySelector('.speaking-correct-btn');
  if (!btn) return;
  const hasText = Boolean(r.transcript && r.transcript.trim());
  btn.disabled = !hasText || r.correction.status === 'loading';
  btn.textContent = r.correction.status === 'loading' ? 'Revisando…' : 'Revisar con Tutor IA';
}

function updateSpeakingUI(container) {
  if (!container) return;
  const r = speakingRecorder;
  const byAction = (action) => container.querySelector(`[data-recording-action="${action}"]`);
  const meetsMinimum = r.elapsedSeconds >= r.config.minimumSeconds || r.config.allowShortSubmission;

  const disabledByStatus = {
    idle: { record: false, stop: true, play: true, delete: true, redo: true },
    requesting: { record: true, stop: true, play: true, delete: true, redo: true },
    recording: { record: true, stop: false, play: true, delete: false, redo: true },
    stopped: { record: true, stop: true, play: false, delete: false, redo: false },
    denied: { record: false, stop: true, play: true, delete: true, redo: true },
    unsupported: { record: true, stop: true, play: true, delete: true, redo: true }
  };
  const d = disabledByStatus[r.status] || disabledByStatus.idle;
  ['record', 'stop', 'play', 'delete', 'redo'].forEach((action) => {
    const btn = byAction(action);
    if (btn) btn.disabled = d[action];
  });

  const statusLabels = {
    idle: 'Disponible',
    requesting: 'Preparando micrófono…',
    recording: 'Grabando…',
    stopped: 'Listo para escuchar',
    denied: 'No se pudo acceder al micrófono. Puedes escribir tu respuesta en el cuadro de texto.',
    unsupported: 'Tu navegador no admite grabación de audio. Escribe tu respuesta en el cuadro de texto.'
  };
  const statusEl = container.querySelector('.speaking-record-status');
  if (statusEl) statusEl.textContent = statusLabels[r.status] || '';

  const timerEl = container.querySelector('.speaking-record-timer');
  if (timerEl) {
    timerEl.hidden = r.status === 'idle' || r.status === 'unsupported' || r.status === 'denied';
    timerEl.textContent = `${formatSpeakingTime(r.elapsedSeconds)} / ${formatSpeakingTime(r.config.targetSeconds)} (máx. ${formatSpeakingTime(r.config.maximumSeconds)})`;
  }

  const warningEl = container.querySelector('.speaking-record-warning');
  if (warningEl) {
    const showWarning = r.status === 'stopped' && !meetsMinimum;
    warningEl.hidden = !showWarning;
    if (showWarning) {
      warningEl.textContent = `Tu respuesta es muy corta. Intenta hablar al menos ${r.config.minimumSeconds} segundos.`;
    }
  }

  // Only overwrite the textarea from live recognition results while the
  // student isn't actively focused on/editing it - never fight their cursor.
  const transcriptEl = container.querySelector('.speaking-transcript');
  if (transcriptEl && document.activeElement !== transcriptEl && transcriptEl.value !== r.transcript) {
    transcriptEl.value = r.transcript;
  }

  updateSpeakingCorrectButtonState(container);
}

// Runs alongside MediaRecorder (never instead of it) purely to get an
// editable text transcript for the corrector - see §5 of the Speaking
// redesign spec. Only the resulting text ever leaves the browser; this is
// the same browser API (and the same trust boundary) as the Tutor prompt's
// startTutorDictation() elsewhere in this file, just feeding a different
// textarea. If unsupported, the recording/playback flow is entirely
// unaffected - the student just types (or corrects) the transcript by hand.
function startSpeakingTranscription(container) {
  const r = speakingRecorder;
  const Ctor = getSpeechRecognitionCtor();
  if (!Ctor) {
    r.recognitionSupported = false;
    return;
  }
  r.recognitionSupported = true;
  r.transcript = '';
  r.transcriptEdited = false;

  const recognition = new Ctor();
  recognition.lang = getPronunciationLocale(learningPathState.language);
  recognition.continuous = true;
  recognition.interimResults = true;

  let finalText = '';
  recognition.onresult = (event) => {
    let interim = '';
    for (let i = event.resultIndex; i < event.results.length; i++) {
      const result = event.results[i];
      if (result.isFinal) finalText += `${result[0].transcript} `;
      else interim += result[0].transcript;
    }
    if (!r.transcriptEdited) {
      r.transcript = `${finalText}${interim}`.trim();
      updateSpeakingUI(container);
    }
  };
  recognition.onerror = () => {
    /* Silent degrade to manual entry - the audio recording is unaffected. */
  };
  recognition.onend = () => {
    if (r.recognition === recognition) r.recognition = null;
  };

  try {
    recognition.start();
    r.recognition = recognition;
  } catch {
    r.recognitionSupported = false;
  }
}

function stopSpeakingTranscription() {
  const r = speakingRecorder;
  if (r.recognition) {
    try {
      r.recognition.stop();
    } catch {
      /* already stopped */
    }
  }
}

async function startSpeakingRecording(container) {
  const r = speakingRecorder;
  if (typeof MediaRecorder === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
    r.status = 'unsupported';
    updateSpeakingUI(container);
    return;
  }

  r.status = 'requesting';
  updateSpeakingUI(container);

  let stream;
  try {
    stream = await navigator.mediaDevices.getUserMedia({ audio: true });
  } catch {
    r.status = 'denied';
    updateSpeakingUI(container);
    return;
  }

  const mimeType = pickSpeakingMimeType();
  const recorder = mimeType ? new MediaRecorder(stream, { mimeType }) : new MediaRecorder(stream);
  r.stream = stream;
  r.mediaRecorder = recorder;
  r.mimeType = mimeType || recorder.mimeType || 'audio/webm';
  r.recordedChunks = [];
  r.elapsedSeconds = 0;
  r.correction = { status: 'idle', text: '', error: '' };

  recorder.addEventListener('dataavailable', (event) => {
    if (event.data && event.data.size > 0) r.recordedChunks.push(event.data);
  });
  recorder.addEventListener('stop', () => {
    r.audioBlob = new Blob(r.recordedChunks, { type: r.mimeType });
    r.audioUrl = URL.createObjectURL(r.audioBlob);
    r.stream?.getTracks().forEach((track) => track.stop());
    r.stream = null;
    r.status = 'stopped';
    stopSpeakingTranscription();
    updateSpeakingUI(container);
  });

  recorder.start();
  r.status = 'recording';
  startSpeakingTranscription(container);
  updateSpeakingUI(container);

  r.timerId = window.setInterval(() => {
    r.elapsedSeconds += 1;
    updateSpeakingUI(container);
    if (r.elapsedSeconds >= r.config.maximumSeconds) stopSpeakingRecording();
  }, 1000);
}

function stopSpeakingRecording() {
  const r = speakingRecorder;
  if (r.timerId) {
    window.clearInterval(r.timerId);
    r.timerId = null;
  }
  if (r.mediaRecorder && r.mediaRecorder.state !== 'inactive') r.mediaRecorder.stop();
  stopSpeakingTranscription();
}

function playSpeakingRecording() {
  const r = speakingRecorder;
  if (!r.audioUrl) return;
  if (!r.audioEl) r.audioEl = new Audio();
  r.audioEl.src = r.audioUrl;
  r.audioEl.play().catch(() => {});
}

function deleteSpeakingRecording(container) {
  teardownSpeakingResources();
  speakingRecorder.status = 'idle';
  updateSpeakingUI(container);
}

function redoSpeakingRecording(container) {
  teardownSpeakingResources();
  speakingRecorder.status = 'idle';
  startSpeakingRecording(container);
}

// Best-effort pull of just the corrected phrase out of the corrector's
// reply, so "Escuchar modelo" doesn't read labels like "Casi correcta"
// aloud - falls back to the full (already short, ≤50-word for A1-A2) text
// when neither pattern matches.
function extractCorrectedPhrase(text) {
  const patterns = [/Repite:\s*[""]?([^"\n"]+)[""]?/i, /Corrección:\s*[""]?([^"\n"]+)[""]?/i];
  for (const pattern of patterns) {
    const match = text.match(pattern);
    if (match?.[1]) return match[1].trim();
  }
  return text;
}

// Model-phrase audio for the correction card (§14): tries the same real
// neural-voice backend the AI Tutor's own voice controls already use
// (/api/speech/synthesize - OpenAI/ElevenLabs, gated by sign-in plus the
// existing free-tier voice quota - see voiceAccessService.js), then falls
// back to the browser's speechSynthesis. Always uses
// getPronunciationLocale(targetLanguage), never the interface/bridge
// language's voice. Azure Speech is intentionally NOT wired up here (no
// credentials/authorization) - this is the one slot it would occupy later,
// ahead of the speechSynthesis fallback.
async function playModelPhrase(text, locale) {
  if (!text) return;
  try {
    const response = await fetch(`${backendBaseUrl}/api/speech/synthesize`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...authHeaders() },
      body: JSON.stringify({
        text,
        language: learningPathState.language,
        locale,
        speed: 'normal',
        turnIndex: 1
      })
    });
    const data = await response.json().catch(() => ({}));
    if (response.ok && data.mode === 'neural' && data.audioBase64) {
      const audio = new Audio(`data:${data.mimeType || 'audio/mpeg'};base64,${data.audioBase64}`);
      await audio.play();
      return;
    }
  } catch {
    /* fall through to speechSynthesis */
  }
  speakText(text, {
    locale,
    rate: getDefaultPronunciationRate(learningPathState.language, learningPathState.level)
  });
}

// Marks a Speaking activity done the first time it earns a correction - "at
// least one valid attempt", never a perfect answer (§15). Reuses the same
// /api/lessons/:slug/complete endpoint and success-handling every other
// skill already goes through (updateProgressDisplay/gamification/XP toast);
// guests simply don't persist progress, same as the rest of the app. Only
// completed/attempts-implicit/XP/date are ever sent - no audio, no
// transcript.
async function completeSpeakingActivity(lesson) {
  if (!lesson || lesson.completed || !authStatus.session?.access_token) return;
  try {
    const response = await fetch(`${backendBaseUrl}/api/lessons/${lesson.slug}/complete`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...authHeaders() },
      body: JSON.stringify({ answers: [] })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || 'No se pudo guardar tu progreso.');
    lesson.completed = true;
    updateProgressDisplay(data, true);
    window.AndergoGamification?.recordLessonCompletion({
      slug: lesson.slug,
      language: learningPathState.language,
      ...getLessonGamificationContext(lesson),
      score: data.score ?? 100,
      xpReward: lesson.xpReward || 20
    });
    window.AndergoGamification?.syncFromServer(data);
    showHomeToast(`Actividad completada. +${data.earnedXp || lesson.xpReward || 20} XP`);
    celebrateActivityCompletion();
  } catch (error) {
    console.warn('No se pudo guardar el progreso de Speaking', error);
  }
}

function renderSpeakingCorrectionResult(container, lesson, text) {
  const resultEl = container.querySelector('.speaking-correction-result');
  if (!resultEl) return;
  const locale = getPronunciationLocale(learningPathState.language);
  const modelPhrase = extractCorrectedPhrase(text);
  resultEl.hidden = false;
  resultEl.innerHTML = `
    <div class="speaking-correction-card">
      <p class="speaking-correction-text">${escapeHtml(text).replace(/\n/g, '<br>')}</p>
      <div class="speaking-correction-actions">
        <button type="button" class="secondary-btn speaking-listen-model-btn">🔊 Escuchar modelo</button>
        <button type="button" class="secondary-btn speaking-retry-btn">↻ Volver a intentarlo</button>
      </div>
    </div>
  `;
  resultEl.querySelector('.speaking-listen-model-btn')?.addEventListener('click', () => {
    playModelPhrase(modelPhrase, locale);
  });
  resultEl.querySelector('.speaking-retry-btn')?.addEventListener('click', () => {
    redoSpeakingRecording(container);
  });
}

// Sends only the transcribed TEXT (never audio - §5/§12) to the Tutor IA's
// speaking-correction task. Payload is deliberately narrow (§10): no full
// unit/lesson content, no whole Tutor history - just this activity's own
// situation/turn/response plus the last couple of conversation turns.
async function requestSpeakingCorrection(container, lesson, context = {}) {
  const r = speakingRecorder;
  const transcript = (r.transcript || '').trim();
  if (!transcript) return;

  r.correction = { status: 'loading', text: '', error: '' };
  updateSpeakingUI(container);

  const resultEl = container.querySelector('.speaking-correction-result');
  if (resultEl) {
    resultEl.hidden = false;
    resultEl.innerHTML = '<p class="speaking-correction-loading">Revisando tu respuesta…</p>';
  }

  const payload = {
    task: 'speaking_correction',
    language: learningPathState.language,
    bridgeLanguage: learningPathState.bridgeLanguage,
    level: learningPathState.level,
    skill: 'speaking',
    unitId: lesson?.unitId || '',
    lessonId: lesson?.slug || '',
    activityType: context.activityType || 'free_response',
    situation: (context.situation || '').slice(0, 400),
    prompt: (context.prompt || '').slice(0, 400),
    studentResponse: transcript.slice(0, 800),
    conversationHistory: (context.conversationHistory || []).slice(-3).map((turn) => ({
      role: turn.role === 'tutor' ? 'tutor' : 'student',
      content: String(turn.content || '').slice(0, 300)
    }))
  };

  let fullText = '';
  try {
    const response = await fetch(`${backendBaseUrl}/api/ai/tutor`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...authHeaders() },
      body: JSON.stringify(payload)
    });
    if (!response.ok || !response.body) {
      const data = await response.json().catch(() => ({}));
      throw new Error(data.error || 'No se pudo conectar con el Tutor IA.');
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    let sawError = null;
    let done = false;
    while (!done) {
      const chunk = await reader.read();
      done = chunk.done;
      if (chunk.value) buffer += decoder.decode(chunk.value, { stream: true });
      let frameEnd;
      while ((frameEnd = buffer.indexOf('\n\n')) !== -1) {
        const frame = buffer.slice(0, frameEnd);
        buffer = buffer.slice(frameEnd + 2);
        const line = frame.split('\n').find((l) => l.startsWith('data: '));
        if (!line) continue;
        const parsed = JSON.parse(line.slice(6));
        if (parsed.delta) fullText += parsed.delta;
        if (parsed.error) sawError = parsed.message;
      }
    }
    if (sawError) throw new Error(sawError);
    if (!fullText.trim()) throw new Error('El Tutor IA no devolvió una corrección.');

    r.correction = { status: 'done', text: fullText.trim(), error: '' };
    renderSpeakingCorrectionResult(container, lesson, fullText.trim());
    completeSpeakingActivity(lesson);
  } catch (error) {
    r.correction = {
      status: 'error',
      text: '',
      error: error.message || 'No se pudo revisar tu respuesta.'
    };
    if (resultEl) {
      resultEl.innerHTML = `<p class="speaking-correction-error" role="alert">${escapeHtml(error.message || 'No se pudo revisar tu respuesta. Intenta de nuevo.')}</p>`;
    }
  }
  updateSpeakingUI(container);
}

// Shared building block reused by every Speaking mode (Práctica guiada,
// Diálogos, Respuesta libre): record/stop/play/delete/redo, an always-
// editable transcript textarea (auto-filled by Web Speech API results when
// available, plain manual entry otherwise - §5/§6), and the "Revisar con
// Tutor IA" correction action + result card. One instance is ever wired at
// a time (speakingRecorder.container), matching the single-recorder-at-once
// assumption the rest of this feature already relies on.
function renderSpeakingRecorderHtml() {
  return `
    <div class="speaking-recorder-block">
      <div class="speaking-record-row" role="group" aria-label="Grabación de voz">
        <button type="button" class="speaking-record-btn" data-recording-action="record" aria-label="Grabar respuesta">🎙 Grabar</button>
        <button type="button" class="speaking-record-btn" data-recording-action="stop" aria-label="Detener grabación">■ Detener</button>
        <button type="button" class="speaking-record-btn" data-recording-action="play" aria-label="Escuchar mi voz">▶ Escuchar</button>
        <button type="button" class="speaking-record-btn" data-recording-action="delete" aria-label="Eliminar grabación">🗑 Eliminar</button>
        <button type="button" class="speaking-record-btn" data-recording-action="redo" aria-label="Volver a grabar">↻ Volver a grabar</button>
      </div>
      <p class="speaking-record-status" aria-live="polite"></p>
      <p class="speaking-record-timer" hidden></p>
      <p class="speaking-record-warning" role="alert" hidden></p>
      <div class="speaking-transcript-block">
        <label class="speaking-transcript-label" for="speakingTranscript">Esto fue lo que entendimos:</label>
        <textarea id="speakingTranscript" class="speaking-transcript" rows="3" placeholder="Escribe o corrige aquí lo que dijiste…" aria-label="Transcripción de tu respuesta, editable"></textarea>
        <p class="speaking-transcript-hint">Corrige una palabra, completa lo que no se reconoció, o vuelve a grabar antes de enviarlo.</p>
      </div>
      <div class="speaking-actions">
        <button type="button" class="primary-btn speaking-correct-btn" disabled>Revisar con Tutor IA</button>
      </div>
      <div class="speaking-correction-result" aria-live="polite" hidden></div>
      <p class="speaking-privacy-note">Tu grabación se procesa temporalmente y no se conserva. Puedes revisar el texto antes de enviarlo al Tutor IA.</p>
    </div>
  `;
}

function wireSpeakingRecorderControls(container, lesson, context) {
  speakingRecorder.container = container;
  updateSpeakingUI(container);

  container.querySelector('[data-recording-action="record"]')?.addEventListener('click', () => {
    startSpeakingRecording(container);
  });
  container.querySelector('[data-recording-action="stop"]')?.addEventListener('click', () => {
    stopSpeakingRecording();
  });
  container.querySelector('[data-recording-action="play"]')?.addEventListener('click', () => {
    playSpeakingRecording();
  });
  container.querySelector('[data-recording-action="delete"]')?.addEventListener('click', () => {
    deleteSpeakingRecording(container);
  });
  container.querySelector('[data-recording-action="redo"]')?.addEventListener('click', () => {
    redoSpeakingRecording(container);
  });

  const transcriptEl = container.querySelector('.speaking-transcript');
  transcriptEl?.addEventListener('input', () => {
    speakingRecorder.transcript = transcriptEl.value;
    speakingRecorder.transcriptEdited = true;
    updateSpeakingCorrectButtonState(container);
  });

  container.querySelector('.speaking-correct-btn')?.addEventListener('click', () => {
    requestSpeakingCorrection(container, lesson, context);
  });
}

window.addEventListener('beforeunload', () => {
  teardownSpeakingResources();
});

// ---------------------------------------------------------------------
// Speaking: reorganized so Dialogues live inside it instead of as their own
// top-level skill/nav destination (see the removed #dialogue section/
// SKILL_VIEWS entry). Three modes share the recorder block above:
//   - guided: turn-by-turn walkthrough of the unit's dialogue lines.
//   - dialogue: Écouter/Escuchar + Jouer un rôle/Interpretar un papel,
//     migrated from the old standalone Dialogue view.
//   - free: the original open speaking prompt.
// Dialogue content comes from the sibling `dialogue`-skill lesson in the
// same unit when one exists (French A1's 12 standalone dialogue
// activities), or falls back to this Speaking lesson's own lesson.dialogue
// array (English/Español A1) - never hardcoded in this component.
// ---------------------------------------------------------------------

function playDialogueLinesSequentially(lines, locale, rate, index = 0) {
  if (index >= lines.length) return;
  speakText(lines[index], {
    locale,
    rate,
    onEnd: () => playDialogueLinesSequentially(lines, locale, rate, index + 1)
  });
}

// Per-lesson UI-only state for which Speaking mode/turn is showing - reset
// whenever a different lesson is opened (see renderSpeakingView).
let speakingViewState = { lessonSlug: '', mode: 'guided', guidedTurnIndex: 0 };

function getSpeakingDialogueSource(lesson) {
  const sibling = learningPathState.lessons.find(
    (item) => item.unitId && item.unitId === lesson.unitId && item.skill === 'dialogue'
  );
  const source = sibling || lesson;
  return {
    // sourceLesson (not necessarily `lesson` itself) is what comprehension
    // exercises actually belong to - renderLessonExercise tags each mcq
    // with this lesson's own slug so answers grade against the right row
    // (POST /api/lessons/:slug/check-answer), not the Speaking activity's.
    sourceLesson: source,
    lines: source.dialogue || [],
    situacion: source.intro || source.description || lesson.mission || lesson.intro || '',
    phrases: source.phrases?.length ? source.phrases : lesson.phrases || [],
    exercises: source.exercises || []
  };
}

function renderSpeakingModeTabsHtml(activeMode) {
  const modes = [
    { id: 'guided', label: '🧭 Práctica guiada' },
    { id: 'dialogue', label: '💬 Diálogos' },
    { id: 'free', label: '🗣 Respuesta libre' }
  ];
  return `
    <div class="speaking-mode-tabs" role="group" aria-label="Modos de Speaking">
      ${modes
        .map(
          (mode) =>
            `<button type="button" class="secondary-btn speaking-mode-btn${mode.id === activeMode ? ' is-active' : ''}" data-speaking-mode="${mode.id}" aria-pressed="${mode.id === activeMode}">${mode.label}</button>`
        )
        .join('')}
    </div>
  `;
}

// Turn-by-turn walkthrough (§3.A): the first distinct speaker plays as the
// tutor/character turn (auto-playable, "Continuar" advances); the second
// distinct speaker is treated as the student's turn and gets the shared
// recorder block. Kept short by construction - it just replays however many
// turns the unit's own dialogue already has (3-7 for A1 content), never
// invented here.
function renderGuidedPracticeHtml(lesson, dialogueSource) {
  const lines = dialogueSource.lines;
  if (!lines.length) {
    return `<p class="skill-graph-empty">Todavía no hay un diálogo guiado para esta unidad.</p>`;
  }
  const participants = [...new Set(lines.map((line) => line.speaker).filter(Boolean))];
  const studentRole = participants[1] || participants[0];
  const turnIndex = Math.min(speakingViewState.guidedTurnIndex, lines.length - 1);
  const turn = lines[turnIndex];
  const isStudentTurn = turn.speaker === studentRole && participants.length > 1;
  const progressLabel = `Turno ${turnIndex + 1} de ${lines.length}`;

  const historyHtml = lines
    .slice(0, turnIndex)
    .map(
      (line) =>
        `<li class="dialogue-line dialogue-line--done"><span class="dialogue-speaker">${escapeHtml(line.speaker || '')}</span><span class="dialogue-text">${escapeHtml(line.line || '')}</span></li>`
    )
    .join('');

  return `
    <p class="speaking-situation"><strong>Situación:</strong> ${escapeHtml(dialogueSource.situacion)}</p>
    <p class="speaking-guided-progress">${escapeHtml(progressLabel)}</p>
    ${historyHtml ? `<ul class="dialogue-lines-list dialogue-lines-list--history">${historyHtml}</ul>` : ''}
    <div class="speaking-guided-turn">
      <span class="dialogue-speaker">${escapeHtml(turn.speaker || '')}${isStudentTurn ? ' (tú)' : ''}</span>
      <p class="speaking-guided-turn-text">${escapeHtml(turn.line || '')}</p>
      ${supportsSpeech() ? `<button type="button" class="secondary-btn speaking-guided-listen-btn">🔊 Escuchar</button>` : ''}
    </div>
    ${
      isStudentTurn
        ? renderSpeakingRecorderHtml() +
          `<div class="speaking-guided-actions"><button type="button" class="secondary-btn speaking-guided-next-btn" ${turnIndex >= lines.length - 1 ? 'hidden' : ''}>Continuar diálogo →</button></div>`
        : `<div class="speaking-guided-actions"><button type="button" class="primary-btn speaking-guided-next-btn" ${turnIndex >= lines.length - 1 ? 'hidden' : ''}>Continuar →</button></div>`
    }
  `;
}

function wireGuidedPracticeMode(content, lesson, dialogueSource) {
  const lines = dialogueSource.lines;
  if (!lines.length) return;
  const participants = [...new Set(lines.map((line) => line.speaker).filter(Boolean))];
  const studentRole = participants[1] || participants[0];
  const turnIndex = Math.min(speakingViewState.guidedTurnIndex, lines.length - 1);
  const turn = lines[turnIndex];
  const isStudentTurn = turn.speaker === studentRole && participants.length > 1;
  const locale = getPronunciationLocale(learningPathState.language);
  const rate = getDefaultPronunciationRate();

  content.querySelector('.speaking-guided-listen-btn')?.addEventListener('click', () => {
    speakText(turn.line, { locale, rate });
  });

  if (isStudentTurn) {
    const priorTurns = lines.slice(Math.max(0, turnIndex - 3), turnIndex).map((line) => ({
      role: line.speaker === studentRole ? 'student' : 'tutor',
      content: line.line
    }));
    resetSpeakingRecorder();
    wireSpeakingRecorderControls(content, lesson, {
      activityType: 'guided_dialogue',
      situation: dialogueSource.situacion,
      prompt: turn.line,
      conversationHistory: priorTurns
    });
  }

  content.querySelector('.speaking-guided-next-btn')?.addEventListener('click', () => {
    speakingViewState.guidedTurnIndex = Math.min(turnIndex + 1, lines.length - 1);
    renderSpeakingModeContent(content.closest('.skill-view-content'), lesson);
  });
}

// Diálogos cotidianos (§2/§3.B): Écouter (sequential + per-line playback,
// translation toggle) and Jouer un rôle (pick a character; the other role's
// lines play back as scripted audio/text - not a live AI improvisation, see
// the redesign report's noted limitation; the student's own lines now get
// the full record/transcribe/correct block instead of a plain textarea).
function renderDialogueModeHtml(dialogueSource) {
  const lines = dialogueSource.lines;
  const participants = [...new Set(lines.map((line) => line.speaker).filter(Boolean))];
  const canSpeak = supportsSpeech();

  if (!lines.length) {
    return `<p class="speaking-situation"><strong>Situación:</strong> ${escapeHtml(dialogueSource.situacion)}</p><p class="skill-graph-empty">Todavía no hay un diálogo de ejemplo para esta unidad.</p>`;
  }

  const linesHtml = lines
    .map(
      (line, index) => `
      <li class="dialogue-line" data-index="${index}">
        <span class="dialogue-speaker">${escapeHtml(line.speaker || '')}</span>
        <span class="dialogue-text">${escapeHtml(line.line || '')}</span>
        ${canSpeak ? `<button type="button" class="dialogue-line-speak-btn" data-speak-text="${escapeHtml(line.line || '')}" aria-label="Escuchar esta línea" title="Escuchar">🔊</button>` : ''}
        ${line.translation ? `<span class="dialogue-translation reading-vocab-support" hidden>${escapeHtml(line.translation)}</span>` : ''}
      </li>`
    )
    .join('');

  const roleOptionsHtml = participants
    .map(
      (name) =>
        `<button type="button" class="secondary-btn dialogue-role-btn" data-role="${escapeHtml(name)}">${escapeHtml(name)}</button>`
    )
    .join('');

  const exercisesHtml = (dialogueSource.exercises || [])
    .filter((item) => item.type === 'mcq')
    .map((item, index) => renderLessonExercise(item, index, dialogueSource.sourceLesson))
    .join('');

  return `
    <p class="dialogue-situation"><strong>Situación:</strong> ${escapeHtml(dialogueSource.situacion)}</p>
    <div class="dialogue-modes" role="group" aria-label="Modos del diálogo">
      <button type="button" class="secondary-btn dialogue-mode-btn is-active" data-mode="listen">🎧 Escuchar</button>
      <button type="button" class="secondary-btn dialogue-mode-btn" data-mode="roleplay">🎭 Interpretar un papel</button>
    </div>
    <div class="dialogue-panel dialogue-listen-panel">
      ${canSpeak ? `<button type="button" class="primary-btn dialogue-play-all-btn">▶ Escuchar todo el diálogo</button>` : ''}
      <ul class="dialogue-lines-list">${linesHtml}</ul>
      ${lines.some((line) => line.translation) ? `<button type="button" class="secondary-btn dialogue-toggle-translation-btn">Mostrar apoyo en español</button>` : ''}
    </div>
    <div class="dialogue-panel dialogue-roleplay-panel" hidden>
      <p>Elige tu personaje:</p>
      <div class="dialogue-role-options">${roleOptionsHtml}</div>
      <ul class="dialogue-roleplay-lines"></ul>
    </div>
    ${
      dialogueSource.phrases?.length
        ? `<div class="dialogue-phrases"><strong>Vocabulario útil</strong><ul>${dialogueSource.phrases.map((phrase) => `<li>${escapeHtml(phrase)}</li>`).join('')}</ul></div>`
        : ''
    }
    ${
      exercisesHtml
        ? `<div class="reading-questions"><h4>Preguntas de comprensión</h4>${exercisesHtml}</div>`
        : ''
    }
  `;
}

function wireDialogueMode(content, lesson, dialogueSource) {
  const lines = dialogueSource.lines;
  if (!lines.length) return;
  const locale = getPronunciationLocale(learningPathState.language);
  const rate = getDefaultPronunciationRate();
  const canSpeak = supportsSpeech();

  content.querySelectorAll('.dialogue-mode-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      content.querySelectorAll('.dialogue-mode-btn').forEach((b) => b.classList.toggle('is-active', b === btn));
      const showListen = btn.dataset.mode === 'listen';
      content.querySelector('.dialogue-listen-panel')?.toggleAttribute('hidden', !showListen);
      content.querySelector('.dialogue-roleplay-panel')?.toggleAttribute('hidden', showListen);
    });
  });

  content.querySelector('.dialogue-play-all-btn')?.addEventListener('click', () => {
    playDialogueLinesSequentially(lines.map((line) => line.line), locale, rate);
  });

  content.querySelectorAll('.dialogue-line-speak-btn').forEach((btn) => {
    btn.addEventListener('click', () => speakText(btn.dataset.speakText, { locale, rate }));
  });

  content.querySelector('.dialogue-toggle-translation-btn')?.addEventListener('click', (event) => {
    const btn = event.currentTarget;
    const nowHidden = content.querySelector('.dialogue-translation')?.hidden;
    content.querySelectorAll('.dialogue-translation').forEach((el) => {
      el.hidden = !nowHidden;
    });
    btn.textContent = nowHidden ? 'Ocultar apoyo en español' : 'Mostrar apoyo en español';
  });

  content.querySelectorAll('.dialogue-role-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      content.querySelectorAll('.dialogue-role-btn').forEach((b) => b.classList.toggle('is-active', b === btn));
      const myRole = btn.dataset.role;
      const list = content.querySelector('.dialogue-roleplay-lines');
      if (!list) return;

      // Rebuilding the list below would otherwise orphan a live
      // "Responder oralmente" recorder if one was mounted for the
      // previously chosen character - release it first.
      resetSpeakingRecorder();

      list.innerHTML = lines
        .map((line, index) => {
          const isMine = line.speaker === myRole;
          if (!isMine) {
            return `
              <li class="dialogue-line">
                <span class="dialogue-speaker">${escapeHtml(line.speaker || '')}</span>
                <span class="dialogue-text">${escapeHtml(line.line || '')}</span>
                ${canSpeak ? `<button type="button" class="dialogue-line-speak-btn" data-speak-text="${escapeHtml(line.line || '')}" aria-label="Escuchar esta línea">🔊</button>` : ''}
              </li>`;
          }
          return `
            <li class="dialogue-line dialogue-line--mine" data-index="${index}">
              <span class="dialogue-speaker">${escapeHtml(line.speaker || '')} (tú)</span>
              <p class="dialogue-model-line" hidden>${escapeHtml(line.line || '')}</p>
              <button type="button" class="secondary-btn dialogue-show-model-btn">Ver el modelo</button>
              <button type="button" class="secondary-btn dialogue-respond-btn" data-index="${index}">🎙 Responder oralmente</button>
              <div class="dialogue-respond-block" hidden></div>
            </li>`;
        })
        .join('');

      list.querySelectorAll('.dialogue-line-speak-btn').forEach((speakBtn) => {
        speakBtn.addEventListener('click', () => speakText(speakBtn.dataset.speakText, { locale, rate }));
      });
      list.querySelectorAll('.dialogue-show-model-btn').forEach((modelBtn) => {
        modelBtn.addEventListener('click', () => {
          const modelLine = modelBtn.previousElementSibling;
          if (modelLine) modelLine.hidden = !modelLine.hidden;
        });
      });
      // "Responder oralmente" lazily mounts the shared recorder block into
      // this specific line's own slot, the first time it's clicked, so
      // switching characters never leaves multiple live recorders wired at
      // once (only the most recently mounted one is ever active - matches
      // speakingRecorder's single-instance assumption).
      list.querySelectorAll('.dialogue-respond-btn').forEach((respondBtn) => {
        respondBtn.addEventListener('click', () => {
          const li = respondBtn.closest('.dialogue-line--mine');
          const block = li?.querySelector('.dialogue-respond-block');
          if (!block) return;

          // Only one "Responder oralmente" recorder is ever mounted at a
          // time - collapsing any other already-open one first avoids two
          // live copies of the shared recorder block (duplicate ids,
          // stale button handlers still pointing at a container that's no
          // longer speakingRecorder.container) if the student answers more
          // than one line in the same roleplay pass.
          resetSpeakingRecorder();
          list.querySelectorAll('.dialogue-respond-block:not([hidden])').forEach((openBlock) => {
            openBlock.hidden = true;
            openBlock.innerHTML = '';
          });
          list.querySelectorAll('.dialogue-respond-btn[hidden]').forEach((hiddenBtn) => {
            hiddenBtn.hidden = false;
          });

          const lineIndex = Number(respondBtn.dataset.index);
          const priorTurns = lines.slice(Math.max(0, lineIndex - 3), lineIndex).map((l) => ({
            role: l.speaker === myRole ? 'student' : 'tutor',
            content: l.line
          }));
          block.hidden = false;
          block.innerHTML = renderSpeakingRecorderHtml();
          wireSpeakingRecorderControls(block, lesson, {
            activityType: 'roleplay',
            situation: dialogueSource.situacion,
            prompt: lines[lineIndex]?.line || '',
            conversationHistory: priorTurns
          });
          respondBtn.hidden = true;
        });
      });
    });
  });
}

// Respuesta libre (§13's original flow): the open speaking prompt this
// section always had, now feeding the shared recorder/transcript/correction
// block instead of the old plain textarea + audio-upload button.
function renderFreeResponseHtml(lesson) {
  const situacion = lesson.mission || lesson.intro || lesson.description || '';
  const fraseModelo = lesson.dialogue?.[0]?.line || lesson.phrases?.[0] || '';
  return `
    <p class="speaking-situation"><strong>Situación:</strong> ${escapeHtml(situacion)}</p>
    ${fraseModelo ? `<p class="speaking-model"><strong>Frase o turno del Tutor:</strong> ${escapeHtml(fraseModelo)}</p>` : ''}
    ${
      lesson.phrases?.length
        ? `<div class="dialogue-phrases"><strong>Vocabulario útil</strong><ul>${lesson.phrases.map((phrase) => `<li>${escapeHtml(phrase)}</li>`).join('')}</ul></div>`
        : ''
    }
    ${renderSpeakingRecorderHtml()}
  `;
}

function wireFreeResponseMode(content, lesson) {
  const situacion = lesson.mission || lesson.intro || lesson.description || '';
  const fraseModelo = lesson.dialogue?.[0]?.line || lesson.phrases?.[0] || '';
  resetSpeakingRecorder();
  wireSpeakingRecorderControls(content, lesson, {
    activityType: 'free_response',
    situation: situacion,
    prompt: fraseModelo,
    conversationHistory: []
  });
}

// Renders whichever mode is active into #speakingStage without touching the
// mode tabs or the lesson header - called on first render and again every
// time the student switches modes or advances a guided-practice turn.
function renderSpeakingModeContent(content, lesson) {
  const stage = content.querySelector('#speakingStage');
  if (!stage) return;
  // Rebuilding the stage's innerHTML below would otherwise orphan a live
  // MediaRecorder/mic stream or Web Speech recognition instance if the
  // student switches modes (or advances a guided-practice turn) mid-
  // recording - always release it first, exactly like navigating away from
  // Speaking entirely already does.
  resetSpeakingRecorder();
  const dialogueSource = getSpeakingDialogueSource(lesson);

  content.querySelectorAll('.speaking-mode-btn').forEach((btn) => {
    btn.classList.toggle('is-active', btn.dataset.speakingMode === speakingViewState.mode);
    btn.setAttribute('aria-pressed', String(btn.dataset.speakingMode === speakingViewState.mode));
  });

  if (speakingViewState.mode === 'dialogue') {
    stage.innerHTML = renderDialogueModeHtml(dialogueSource);
    wireDialogueMode(stage, lesson, dialogueSource);
  } else if (speakingViewState.mode === 'free') {
    stage.innerHTML = renderFreeResponseHtml(lesson);
    wireFreeResponseMode(stage, lesson);
  } else {
    stage.innerHTML = renderGuidedPracticeHtml(lesson, dialogueSource);
    wireGuidedPracticeMode(stage, lesson, dialogueSource);
  }
}

function renderSpeakingView(section, lesson) {
  const content = section.querySelector('.skill-view-content');
  if (!content) return;
  resetSpeakingRecorder();

  if (speakingViewState.lessonSlug !== lesson.slug) {
    speakingViewState = { lessonSlug: lesson.slug, mode: 'guided', guidedTurnIndex: 0 };
  }

  const taskConfig = {
    minimumSeconds: 5,
    targetSeconds: 30,
    maximumSeconds: 60,
    allowShortSubmission: false,
    ...(lesson.speakingTask || {})
  };
  speakingRecorder.config = taskConfig;

  content.innerHTML = `
    <h3>${escapeHtml(lesson.title)}</h3>
    ${renderSpeakingModeTabsHtml(speakingViewState.mode)}
    <div id="speakingStage" class="speaking-stage"></div>
    <div class="skill-view-tutor-cta">
      <button type="button" class="secondary-btn open-tutor-btn" data-tutor-prompt="Quiero practicar esta conversación de Speaking." data-support-mode="practice">Abrir Tutor IA (chat libre)</button>
      <button type="button" class="secondary-btn open-translator-btn" data-translate-text="" data-return-label="Volver a Speaking">Traducir</button>
    </div>
  `;

  content.querySelectorAll('.speaking-mode-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      speakingViewState.mode = btn.dataset.speakingMode;
      speakingViewState.guidedTurnIndex = 0;
      renderSpeakingModeContent(content, lesson);
    });
  });

  renderSpeakingModeContent(content, lesson);
}

// Print-only Q&A worksheet shared by Grammar and Vocabulary PDFs -
// deliberately independent from the interactive .mcq-option exercises
// rendered on-screen (renderLessonExercise), so the printable answer key
// (showAnswers: true) never touches or risks the interactive component.
// Letters (A/B/C/D) are a print-worksheet convention only - the on-screen
// exercises never show them (see renderLessonExercise).
function renderPrintableExerciseList(exercises, { showAnswers = false } = {}) {
  const letters = ['A', 'B', 'C', 'D'];
  return (exercises || [])
    .filter((item) => item.type === 'mcq' && Array.isArray(item.options))
    .map((item, index) => {
      const optionsHtml = item.options
        .map((option, optIndex) => {
          const isCorrect = showAnswers && optIndex === Number(item.answer);
          return `<li class="skill-print-option${isCorrect ? ' is-correct-answer' : ''}">${letters[optIndex] || optIndex + 1}) ${escapeHtml(optionLabel(option) || '')}</li>`;
        })
        .join('');
      return `
        <div class="skill-print-question">
          <p><strong>${index + 1}.</strong> ${escapeHtml(item.prompt)}</p>
          <ul class="skill-print-options">${optionsHtml}</ul>
        </div>
      `;
    })
    .join('');
}

// Shared compact print header for every printable skill document. It keeps
// the course metadata but omits the redundant "ANDERGO Language Academy"
// line below the official logo so page-one content starts higher.
// `answerKey` renders the teacher/admin variant
// (correct options marked) instead of the student worksheet (blank answer
// lines) - gated by entitlements.role==='ceo' (this app's only staff/admin
// role today - see lib/entitlementsService.js) at the call site, never
// decided here.
function renderSkillPrintHeaderHtml(lesson) {
  const bridgeLabel = LanguagePair
    ? LanguagePair.languageNameIn(learningPathState.bridgeLanguage, learningPathState.bridgeLanguage)
    : languageDisplayNames[learningPathState.bridgeLanguage] || learningPathState.bridgeLanguage;
  const targetLabel = LanguagePair
    ? LanguagePair.languageNameIn(learningPathState.bridgeLanguage, learningPathState.language)
    : languageDisplayNames[learningPathState.language] || learningPathState.language;
  const unit = lesson?.unitId
    ? learningPathState.units.find((item) => item.id === lesson.unitId)
    : null;
  return `
    <div class="print-only reading-print-header skill-print-header">
      <img class="skill-print-brand-image" src="/andergo-logo.png" alt="ANDERGO - Learn Any Language. Unlock Your World." />
      <p class="skill-print-language-pair">
        <span>Idioma puente: <strong>${escapeHtml(bridgeLabel)}</strong></span>
        <span aria-hidden="true">→</span>
        <span>Idioma meta: <strong>${escapeHtml(targetLabel)}</strong></span>
        <span>· Nivel <strong>${escapeHtml(learningPathState.level)}</strong></span>
      </p>
      ${unit?.title ? `<p class="skill-print-unit">${escapeHtml(unit.title)}</p>` : ''}
      <p class="reading-print-date">${escapeHtml(new Date().toLocaleDateString('es'))}</p>
    </div>
  `;
}

function isStaffEntitled() {
  return authStatus.entitlements?.role === 'ceo';
}

function renderGrammarConceptCards(lesson) {
  const note = String(lesson.grammar || lesson.description || '').trim();
  const phrases = Array.isArray(lesson.phrases) ? lesson.phrases.filter(Boolean) : [];
  const profile = lesson.extra?.grammarProfile || {};
  const parsedSections = parseGrammarNoteSections(note);
  const sectionBody = (...keys) =>
    parsedSections.find((section) => keys.includes(section.key))?.body || '';
  const sentences = note
    .split(/(?<=[.!?])\s+/)
    .map((item) => item.trim())
    .filter(Boolean);
  const french = isFrenchTargetLanguage();
  const cards = [
    {
      label: french ? 'Définition' : 'Definition',
      title: french ? 'Comprendre la règle' : 'What this grammar is',
      body:
        profile.definition ||
        profile.explanation ||
        sectionBody('rule') ||
        sentences[0] ||
        note
    },
    {
      label: 'Structure',
      title: french ? 'Construire la phrase' : 'How it is formed',
      body:
        profile.structure ||
        sectionBody('pattern', 'affirmative', 'negative', 'questions') ||
        (phrases[0]
          ? `${french ? 'Schéma central' : 'Core pattern'} : ${phrases[0]}`
          : french
            ? `Étudiez la forme et la place de ${profile.name || lesson.title}.`
            : `Study the form and sentence position of ${profile.name || lesson.title}.`)
    },
    {
      label: french ? 'Emploi en français' : 'Function in English',
      title: french ? 'Ce qu’elle permet d’exprimer' : 'What it communicates',
      body:
        profile.function ||
        profile.purpose ||
        sectionBody('goal', 'use') ||
        lesson.description ||
        (french
          ? 'Utilisez-la pour exprimer des idées complexes avec clarté et précision.'
          : 'Use it to communicate the main ideas clearly and accurately.')
    },
    {
      label: french ? 'Exemples' : 'Practical examples',
      title: french ? 'Formes à retenir' : 'Examples from the lesson',
      body:
        (profile.examples || []).filter(Boolean).join(' · ') ||
        sectionBody('examples', 'affirmative', 'negative', 'questions') ||
        (phrases.length
          ? phrases.join(' · ')
          : french
            ? 'Créez votre propre phrase avec cette structure.'
            : 'Create your own sentence with this structure.')
    }
  ];

  return `
    <div class="grammar-card-grid">
      ${cards
        .map(
          (card) => `
        <article class="grammar-concept-card">
          <span>${escapeHtml(card.label)}</span>
          <h4>${escapeHtml(card.title)}</h4>
          <p>${escapeHtml(card.body)}</p>
        </article>
      `
        )
        .join('')}
    </div>
  `;
}

function renderGrammarView(section, lesson) {
  const content = section.querySelector('.skill-view-content');
  if (!content) return;
  const french = isFrenchTargetLanguage();
  // Scored Grammar test pilot (course_lessons.extra.grammarTest, see
  // lib/grammarTestSanitizer.js) - only a couple of lessons have this so
  // far; every other Grammar lesson falls through to the flat
  // inline-feedback view below, unchanged.
  if (lesson.extra?.grammarTest?.questions?.length) {
    renderGrammarTestView(content, lesson);
    return;
  }
  const example = lesson.dialogue?.[0] || lesson.vocabulary?.[0] || null;
  const exercisesHtml = (lesson.exercises || [])
    .filter((item) => item.type === 'mcq')
    .map((item, index) => renderLessonExercise(item, index, lesson))
    .join('');
  const staff = isStaffEntitled();
  const printExercisesHtml = renderPrintableExerciseList(lesson.exercises, { showAnswers: staff });

  content.innerHTML = `
    <div class="skill-print-area">
      ${renderSkillPrintHeaderHtml(lesson)}
      <h3>${escapeHtml(lesson.title)}</h3>
      ${renderGrammarConceptCards(lesson)}
      ${
        example
          ? `
        <div class="grammar-example no-print">
          <div class="grammar-example-target"><span>${french ? 'Exemple' : 'Target'}</span><strong>${escapeHtml(example.line || example.word || '')}</strong></div>
          <div class="grammar-example-bridge"><span>${french ? 'Explication' : 'Bridge'}</span><strong>${escapeHtml(resolveVocabTranslation(example))}</strong></div>
        </div>
      `
          : ''
      }
      <div class="grammar-exercise no-print">
        <h4>${french ? 'Mini-exercice' : 'Mini ejercicio'}</h4>
        ${exercisesHtml || `<p class="skill-graph-empty">${french ? 'Aucun exercice de grammaire pour cette leçon.' : 'No hay ejercicios de gramática para esta lección.'}</p>`}
      </div>
      <div class="print-only">
        <h4>${staff ? (french ? 'Corrigé' : 'Clave de respuestas') : (french ? 'Activité à compléter' : 'Actividad para completar')}</h4>
        ${printExercisesHtml || `<p>${french ? 'Aucun exercice pour cette leçon.' : 'No hay ejercicios para esta lección.'}</p>`}
        ${
          staff
            ? ''
            : `<div class="reading-print-answer-space skill-print-answer-space print-only">
                <h4>${french ? 'Vos réponses' : 'Tus respuestas'}</h4>
                <div class="reading-print-answer-lines"><div></div><div></div><div></div><div></div></div>
              </div>`
        }
      </div>
    </div>
    <div class="skill-view-tutor-cta no-print">
      <button type="button" class="primary-btn open-tutor-btn" data-tutor-prompt="${french ? 'Explique-moi pourquoi cette structure est utilisée' : 'Explícame por qué se usa esta estructura'} : ${escapeHtml(lesson.grammar || '')}" data-support-mode="explain" data-tutor-transcript="${escapeHtml(lesson.grammar || '')}">${french ? 'Expliquer cette structure' : 'Explícame esta estructura'}</button>
      <button type="button" class="secondary-btn open-translator-btn" data-translate-text="${escapeHtml(lesson.grammar || '')}" data-return-label="${french ? 'Retour à Grammar' : 'Volver a Grammar'}">${french ? 'Traduire l’explication' : 'Traducir explicación'}</button>
      <button type="button" class="secondary-btn skill-print-btn">${staff ? (french ? 'Télécharger le corrigé' : 'Descargar clave de respuestas') : (french ? 'Télécharger l’activité en PDF' : 'Descargar actividad en PDF')}</button>
    </div>
  `;
}

// ---------------------------------------------------------------------
// Scored Grammar test (course_lessons.extra.grammarTest - see
// lib/grammarTestSanitizer.js). State is purely local (which question
// we're on, what's been typed/picked so far) until the student submits -
// the server re-grades everything from the real answer key
// (lib/courseLessonsService.js#gradeGrammarTest), this never trusts its
// own scoring or shows a result the server didn't compute.
const grammarTestState = new Map();

function getGrammarTestRuntime(lesson) {
  let runtime = grammarTestState.get(lesson.slug);
  if (!runtime) {
    runtime = { phase: 'instructions', currentIndex: 0, answers: {}, lastResult: null };
    grammarTestState.set(lesson.slug, runtime);
  }
  return runtime;
}

// 90-100/80-89/70-79/60-69/<60 per the spec - "Necesitas practicar", never
// "reprobado", for a platform used by kids as young as ~9.
function gradeBandForScore(score) {
  const french = isFrenchTargetLanguage();
  if (score >= 90) return { label: french ? 'Excellent' : 'Excellent', emoji: '🌟' };
  if (score >= 80) return { label: french ? 'Très bien' : 'Very good', emoji: '👍' };
  if (score >= 70) return { label: french ? 'Bien' : 'Good', emoji: '🙂' };
  if (score >= 60) return { label: french ? 'En progression' : 'In progress', emoji: '💪' };
  return { label: french ? 'Continuez à vous entraîner' : 'Keep practising', emoji: '📚' };
}

function isGrammarTestQuestionAnswered(runtime, question) {
  const value = runtime.answers[question.id];
  if (value === undefined || value === null) return false;
  if (Array.isArray(value)) return value.length > 0 && value.length === (question.items || []).length;
  return String(value).trim().length > 0;
}

// "Lección completa" (spec §4: objetivo/explicación/patrones/ejemplos/
// afirmativa/negativa/interrogativa/contracciones/errores frecuentes/
// práctica guiada/resumen). Already hand-authored, one field per unit
// (course_lessons.grammar_note / lesson.grammar), as a sequence of
// "Label: body" paragraphs separated by a blank line - confirmed the exact
// same label set across all 12 English A1 units. This just splits that
// text back into labeled sections for display instead of one long
// undifferentiated paragraph; it doesn't invent or reformat any content.
const GRAMMAR_NOTE_SECTION_TITLES = [
  { key: 'goal', match: /^(goal|objectif|but)/i, title: 'What it is used for', frenchTitle: 'Objectif' },
  { key: 'use', match: /^(use|emploi|usage)/i, title: 'What it is used for', frenchTitle: 'Emploi' },
  { key: 'rule', match: /^(rule|règle)/i, title: 'Brief explanation', frenchTitle: 'Règle essentielle' },
  { key: 'pattern', match: /^(pattern|structure|schéma)/i, title: 'Pattern', frenchTitle: 'Structure' },
  { key: 'examples', match: /^(examples|exemples)/i, title: 'Practical examples', frenchTitle: 'Exemples pratiques' },
  { key: 'affirmative', match: /^(affirmative|forme affirmative)/i, title: 'Affirmative form', frenchTitle: 'Forme affirmative' },
  { key: 'negative', match: /^(negative|négative|forme négative)/i, title: 'Negative form', frenchTitle: 'Forme négative' },
  { key: 'questions', match: /^(questions|interrogation|forme interrogative)/i, title: 'Question form', frenchTitle: 'Forme interrogative' },
  { key: 'contractions', match: /^contractions/i, title: 'Contractions', frenchTitle: 'Contractions' },
  { key: 'common-mistakes', match: /^(common mistakes|erreurs fréquentes)/i, title: 'Common mistakes', frenchTitle: 'Erreurs fréquentes' },
  { key: 'compare', match: /^(compare|comparaison)/i, title: 'Comparison', frenchTitle: 'Comparaison' },
  { key: 'mini-practice', match: /^(mini practice|pratique guidée)/i, title: 'Guided practice', frenchTitle: 'Pratique guidée' },
  { key: 'summary', match: /^(summary|résumé)/i, title: 'Summary', frenchTitle: 'Résumé' }
];

function parseGrammarNoteSections(grammarNote) {
  const french = isFrenchTargetLanguage();
  return String(grammarNote || '')
    .split(/\n\n+/)
    .map((para) => para.trim())
    .filter(Boolean)
    .map((para) => {
      const colonIdx = para.indexOf(':');
      const label = colonIdx > -1 ? para.slice(0, colonIdx).trim() : '';
      const body = (colonIdx > -1 ? para.slice(colonIdx + 1).trim() : para) || '';
      const known = GRAMMAR_NOTE_SECTION_TITLES.find((entry) => entry.match.test(label));
      return {
        key: known?.key || 'note',
        title: known ? (french ? known.frenchTitle : known.title) : label || (french ? 'Note' : 'Note'),
        body
      };
    })
    .filter((section) => section.body);
}

function renderGrammarLessonContentHtml(lesson) {
  const sections = parseGrammarNoteSections(lesson.grammar);
  if (!sections.length) return '';
  const sectionsHtml = sections
    .map(
      (section) => `
        <div class="grammar-lesson-section">
          <h4>${escapeHtml(section.title)}</h4>
          <p>${escapeHtml(section.body).replace(/\n/g, '<br>')}</p>
        </div>`
    )
    .join('');
  return `
    <details class="grammar-lesson-content" open>
      <summary>📘 ${isFrenchTargetLanguage() ? 'Leçon de grammaire complète' : 'Complete grammar lesson'}</summary>
      <div class="grammar-lesson-sections-grid">${sectionsHtml}</div>
    </details>
  `;
}

function renderGrammarTestView(content, lesson) {
  const test = lesson.extra.grammarTest;
  const runtime = getGrammarTestRuntime(lesson);
  if (runtime.phase === 'question') {
    content.innerHTML = renderGrammarTestQuestionHtml(lesson, test, runtime);
  } else if (runtime.phase === 'review') {
    content.innerHTML = renderGrammarTestReviewHtml(lesson, test, runtime);
  } else if (runtime.phase === 'results') {
    content.innerHTML = renderGrammarTestResultsHtml(lesson, test, runtime);
    loadGrammarTestHistory(lesson, content.querySelector('.grammar-test-history'));
  } else {
    content.innerHTML = renderGrammarTestInstructionsHtml(lesson, test, runtime);
    loadGrammarTestHistory(lesson, content.querySelector('.grammar-test-history'));
  }
}

function renderGrammarTestInstructionsHtml(lesson, test) {
  const total = test.questions.length;
  const french = isFrenchTargetLanguage();
  return `
    <div class="grammar-test-card card-enter">
      <h3>${escapeHtml(lesson.title)}</h3>
      ${renderGrammarConceptCards(lesson)}
      <p class="grammar-test-instructions-text">${escapeHtml(lesson.description || (french ? 'Faites le test pour appliquer la grammaire de cette unité.' : 'Take the test to apply the grammar from this story.'))}</p>
      ${renderGrammarLessonContentHtml(lesson)}
      <ul class="grammar-test-meta-list">
        <li>📝 ${total} ${french ? 'questions à choix multiple' : 'multiple-choice questions'}</li>
        <li>🎯 ${french ? 'Score de réussite recommandé' : 'Recommended passing score'} : ${test.passingScore || 70}/100</li>
        ${lesson.bestScore != null ? `<li>🏆 ${french ? 'Meilleur score' : 'Best score'} : ${lesson.bestScore}/100</li>` : ''}
      </ul>
      <button type="button" class="primary-btn hover-lift btn-press grammar-test-start-btn">${french ? 'Commencer le test' : 'Start practice test'}</button>
      <div class="grammar-test-history"></div>
    </div>
  `;
}

function renderGrammarTestQuestionHtml(lesson, test, runtime) {
  const total = test.questions.length;
  const answered = test.questions.filter((question) =>
    isGrammarTestQuestionAnswered(runtime, question)
  ).length;
  const pct = Math.round((answered / total) * 100);
  const french = isFrenchTargetLanguage();
  const questionsHtml = test.questions
    .map(
      (question, index) => `
        <article class="grammar-test-question-item" data-question-id="${escapeHtml(question.id)}">
          <p class="grammar-test-question-prompt"><span>${index + 1}.</span> ${escapeHtml(question.prompt)}</p>
          ${renderGrammarTestQuestionBodyHtml(question, runtime)}
        </article>
      `
    )
    .join('');

  return `
    <div class="grammar-test-card card-enter">
      <h3>${escapeHtml(lesson.title)} — ${french ? 'Test pratique' : 'Practice test'}</h3>
      <div class="grammar-test-progress-row">
        <span class="grammar-test-counter">${answered} ${french ? 'sur' : 'of'} ${total} ${french ? 'réponses' : 'answered'}</span>
        <div class="grammar-test-progress-bar"><div class="progress-fill-animated" style="width:${pct}%"></div></div>
      </div>
      <div class="grammar-test-question-list">${questionsHtml}</div>
      <p class="grammar-test-review-warning" ${answered === total ? 'hidden' : ''}>${french ? 'Répondez à toutes les questions avant de soumettre le test.' : 'Answer every question before submitting the test.'}</p>
      <div class="grammar-test-submit-bar">
        <span>${french ? 'Score final' : 'Final score'} : 0–100</span>
        <button type="button" class="primary-btn hover-lift btn-press grammar-test-submit-btn" ${answered === total ? '' : 'disabled'}>${french ? 'Soumettre toutes les réponses' : 'Submit all answers'}</button>
      </div>
    </div>
  `;
}

function renderGrammarTestQuestionBodyHtml(question, runtime) {
  const french = isFrenchTargetLanguage();
  const saved = runtime.answers[question.id];

  if (question.type === 'mcq') {
    // A/B/C/D letters (spec §4: "opciones A, B, C y D") + aria-pressed so
    // the selected option is never signaled by color/the .is-selected class
    // alone - same "no depender únicamente del color" rule the results
    // breakdown follows.
    const optionLetters = ['A', 'B', 'C', 'D', 'E', 'F'];
    const optionsHtml = (question.options || [])
      .map((opt, index) => {
        const isSelected = saved != null && String(saved) === String(opt.id);
        const letter = optionLetters[index] || String(index + 1);
        return `<button type="button" class="grammar-test-option${isSelected ? ' is-selected' : ''}" data-option-id="${escapeHtml(opt.id)}" aria-pressed="${isSelected}"><span class="grammar-test-option-letter" aria-hidden="true">${letter}</span><span class="grammar-test-option-text">${escapeHtml(opt.text)}</span></button>`;
      })
      .join('');
    return `<div class="grammar-test-options">${optionsHtml}</div>`;
  }

  if (question.type === 'fill_blank') {
    return `
      <div class="grammar-test-fill-wrap">
        <input type="text" class="grammar-test-fill-input" value="${escapeHtml(saved || '')}" autocomplete="off" placeholder="${french ? 'Écrivez votre réponse' : 'Write your answer'}" />
      </div>
    `;
  }

  if (question.type === 'ordering') {
    const savedOrder = Array.isArray(saved) ? saved : [];
    const itemCount = (question.items || []).length;
    const itemsHtml = (question.items || [])
      .map((item) => {
        const savedPosition = savedOrder.indexOf(item.id) + 1; // 0 if not picked yet
        const positionOptionsHtml = Array.from({ length: itemCount }, (_, i) => i + 1)
          .map(
            (position) =>
              `<option value="${position}" ${position === savedPosition ? 'selected' : ''}>${position}</option>`
          )
          .join('');
        return `
          <li class="grammar-test-order-item">
            <select class="grammar-test-order-select" data-item-id="${escapeHtml(item.id)}" aria-label="${french ? 'Position de' : 'Position of'} ${escapeHtml(item.text)}">
              <option value="" ${savedPosition === 0 ? 'selected' : ''}>#</option>
              ${positionOptionsHtml}
            </select>
            <span>${escapeHtml(item.text)}</span>
          </li>
        `;
      })
      .join('');
    return `<ol class="grammar-test-order-list">${itemsHtml}</ol>`;
  }

  return '';
}

// Reads whatever is currently on screen for the active question straight
// out of the DOM and stores it into runtime.answers - called right before
// every navigation (prev/next/review), so nothing is lost moving between
// questions without needing a live input/change listener on every field.
function collectGrammarTestAnswer(content, test, runtime) {
  const question = test.questions[runtime.currentIndex];
  if (!question) return;

  if (question.type === 'mcq') {
    const selected = content.querySelector('.grammar-test-option.is-selected');
    if (selected) {
      runtime.answers[question.id] = selected.dataset.optionId;
    } else {
      delete runtime.answers[question.id];
    }
    return;
  }

  if (question.type === 'fill_blank') {
    const value = content.querySelector('.grammar-test-fill-input')?.value.trim() || '';
    if (value) runtime.answers[question.id] = value;
    else delete runtime.answers[question.id];
    return;
  }

  if (question.type === 'ordering') {
    const picks = [...content.querySelectorAll('.grammar-test-order-select')].map((select) => ({
      itemId: select.dataset.itemId,
      position: Number(select.value)
    }));
    const complete = picks.length > 0 && picks.every((p) => p.position);
    const positions = picks.map((p) => p.position);
    const noDuplicates = new Set(positions).size === positions.length;
    if (complete && noDuplicates) {
      runtime.answers[question.id] = picks
        .slice()
        .sort((a, b) => a.position - b.position)
        .map((p) => p.itemId);
    } else {
      delete runtime.answers[question.id];
    }
  }
}

function renderGrammarTestReviewHtml(lesson, test, runtime) {
  const french = isFrenchTargetLanguage();
  const itemsHtml = test.questions
    .map((question, index) => {
      const answered = isGrammarTestQuestionAnswered(runtime, question);
      return `
        <li class="grammar-test-review-item${answered ? ' is-answered' : ' is-unanswered'}">
          <span class="grammar-test-review-status" aria-hidden="true">${answered ? '✅' : '⚠️'}</span>
          <span class="grammar-test-review-prompt">${index + 1}. ${escapeHtml(question.prompt)}</span>
          <button type="button" class="secondary-btn grammar-test-review-edit-btn" data-question-index="${index}">${answered ? (french ? 'Modifier' : 'Editar') : (french ? 'Répondre' : 'Responder')}</button>
        </li>
      `;
    })
    .join('');
  const allAnswered = test.questions.every((question) => isGrammarTestQuestionAnswered(runtime, question));

  return `
    <div class="grammar-test-card card-enter">
      <h3>${french ? 'Vérifiez vos réponses' : 'Review your answers'}</h3>
      <p class="grammar-test-instructions-text">${french ? 'Vous pouvez modifier chaque réponse avant de soumettre le test.' : 'You can edit any answer before submitting the test.'}</p>
      <ul class="grammar-test-review-list">${itemsHtml}</ul>
      ${!allAnswered ? `<p class="grammar-test-review-warning">${french ? 'Répondez à toutes les questions avant de soumettre le test.' : 'Answer every question before submitting the test.'}</p>` : ''}
      <div class="grammar-test-nav-row">
        <button type="button" class="secondary-btn hover-lift btn-press grammar-test-review-edit-btn" data-question-index="${test.questions.length - 1}">${french ? 'Revenir à la dernière question' : 'Return to last question'}</button>
        <button type="button" class="primary-btn hover-lift btn-press grammar-test-submit-btn" ${!allAnswered ? 'disabled' : ''}>${french ? 'Soumettre le test' : 'Submit test'}</button>
      </div>
    </div>
  `;
}

// Looks up the actual correct answer's display text from the (already
// sanitized, option-text-only) question data + the result row's
// correctOptionId/correctAnswer/correctOrder - see
// lib/courseLessonsService.js#correctAnswerForQuestion, only ever attached
// to a result AFTER that question has been graded server-side.
function resolveGrammarCorrectAnswerText(question, result) {
  if (!result) return '';
  if (question.type === 'mcq' && result.correctOptionId) {
    return question.options?.find((opt) => String(opt.id) === String(result.correctOptionId))?.text || '';
  }
  if (question.type === 'fill_blank' && result.correctAnswer) return result.correctAnswer;
  if (question.type === 'ordering' && Array.isArray(result.correctOrder)) {
    return result.correctOrder
      .map((id) => question.items?.find((item) => item.id === id)?.text)
      .filter(Boolean)
      .join(' → ');
  }
  return '';
}

function renderGrammarTestResultsHtml(lesson, test, runtime) {
  const result = runtime.lastResult;
  if (!result) {
    runtime.phase = 'instructions';
    return renderGrammarTestInstructionsHtml(lesson, test);
  }

  const band = gradeBandForScore(result.score);
  const french = isFrenchTargetLanguage();
  const resultsByQuestionId = new Map((result.results || []).map((r) => [String(r.questionId), r]));
  const correctCount = (result.results || []).filter((r) => r.correct).length;

  const breakdownHtml = test.questions
    .map((question, index) => {
      const r = resultsByQuestionId.get(String(question.id));
      const correct = Boolean(r?.correct);
      // Never color-only (spec §4: "no depender únicamente del color; usar
      // icono, texto y atributos accesibles") - the emoji is aria-hidden,
      // but the "Correcta"/"Incorrecta" text right next to it is real,
      // visible, screen-reader-readable text, not just a CSS color class.
      const correctAnswerText = !correct ? resolveGrammarCorrectAnswerText(question, r) : '';
      return `
        <li class="grammar-test-breakdown-item${correct ? ' is-correct' : ' is-incorrect'}">
          <span class="grammar-test-breakdown-icon" aria-hidden="true">${correct ? '✅' : '❌'}</span>
          <div>
            <p class="grammar-test-breakdown-prompt">
              <span class="grammar-test-breakdown-status-text">${correct ? (french ? 'Correcte' : 'Correct') : (french ? 'Incorrecte' : 'Incorrect')}:</span>
              ${index + 1}. ${escapeHtml(question.prompt)}
            </p>
            ${correctAnswerText ? `<p class="grammar-test-breakdown-correct-answer">${french ? 'Bonne réponse' : 'Correct answer'} : <strong>${escapeHtml(correctAnswerText)}</strong></p>` : ''}
            ${r?.explanation ? `<p class="grammar-test-breakdown-explanation">${escapeHtml(r.explanation)}</p>` : ''}
          </div>
        </li>
      `;
    })
    .join('');

  return `
    <div class="grammar-test-card card-enter skill-print-area">
      <div class="print-only">${renderSkillPrintHeaderHtml(lesson)}</div>
      <h3 class="print-only">${escapeHtml(lesson.title)} — ${french ? 'Résultat du test de grammaire' : 'Grammar test result'}</h3>
      <div class="grammar-test-score-band">
        <span class="grammar-test-score-emoji" aria-hidden="true">${band.emoji}</span>
        <strong class="grammar-test-score-number">${result.score}/100</strong>
        <span class="grammar-test-score-label">${band.label}</span>
      </div>
      <p class="grammar-test-score-detail">${french ? 'Bonnes réponses' : 'Correct answers'} : ${correctCount} ${french ? 'sur' : 'of'} ${test.questions.length}</p>
      <p class="grammar-test-score-detail">
        ${result.bestScore != null ? `${french ? 'Meilleur score' : 'Best score'} : ${result.bestScore}/100 · ` : ''}${french ? 'Tentative' : 'Attempt'} ${result.attemptNumber ?? ''} · ${new Date().toLocaleDateString(french ? 'fr-FR' : 'en-US')}
      </p>
      <ul class="grammar-test-breakdown-list">${breakdownHtml}</ul>
      <div class="grammar-test-result-actions no-print">
        <button type="button" class="primary-btn hover-lift btn-press grammar-test-retry-btn">${french ? 'Réessayer' : 'Try again'}</button>
        <button type="button" class="secondary-btn skill-print-btn">${french ? 'Télécharger le résultat en PDF' : 'Download result as PDF'}</button>
      </div>
      <div class="grammar-test-history"></div>
    </div>
  `;
}

// "Historial de intentos" (spec §4) - fetched lazily after the instructions/
// results screen is already on screen, so a slow/failed request never
// blocks the test itself. Guest students (no session) simply see nothing -
// the endpoint requires auth the same way submitting the test already does.
async function loadGrammarTestHistory(lesson, containerEl) {
  if (!containerEl || !authStatus.session?.access_token) return;
  const french = isFrenchTargetLanguage();
  try {
    const response = await fetch(`${backendBaseUrl}/api/lessons/${lesson.slug}/grammar-test-history`, {
      headers: authHeaders()
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok || !Array.isArray(data.history) || !data.history.length) return;

    const rowsHtml = data.history
      .map((attempt) => {
        const date = attempt.completedAt
          ? new Date(attempt.completedAt).toLocaleDateString(french ? 'fr-FR' : 'en-US')
          : '';
        return `
          <li class="grammar-test-history-item${attempt.isBest ? ' is-best' : ''}">
            <span>${french ? 'Tentative' : 'Attempt'} ${attempt.attemptNumber}</span>
            <span>${attempt.score}/100</span>
            <span>${attempt.correctAnswers}/${attempt.totalQuestions} ${french ? 'réponses correctes' : 'correct answers'}</span>
            <span>${escapeHtml(date)}</span>
            ${attempt.isBest ? `<span class="grammar-test-history-best-tag">🏆 ${french ? 'Meilleur' : 'Best'}</span>` : ''}
          </li>`;
      })
      .join('');
    containerEl.innerHTML = `
      <details class="grammar-test-history-details">
        <summary>🕘 ${french ? 'Historique des tentatives' : 'Attempt history'} (${data.history.length})</summary>
        <ul class="grammar-test-history-list">${rowsHtml}</ul>
      </details>
    `;
  } catch {
    // Silent - the history list is a nice-to-have, never worth an error
    // toast interrupting the test/results flow.
  }
}

// ---------------------------------------------------------------------
// Scored Listening Comprehension test (course_lessons.extra.
// listeningComprehension - same shape/sanitizer/grading as Grammar's
// extra.grammarTest, see lib/grammarTestSanitizer.js and
// lib/courseLessonsService.js#gradeExercises). Renders inside Listening's
// existing tab panel (.listening-mode-panel), not the whole skill view, so
// it needs its own container/nav wrappers - but reuses Grammar's
// per-question body renderer, answer-collector and score-band helper
// as-is (renderGrammarTestQuestionBodyHtml/collectGrammarTestAnswer/
// gradeBandForScore/isGrammarTestQuestionAnswered are already fully
// generic: they only ever read `question`/`test`/`runtime`, never
// anything grammar-specific), so the question-level markup/interaction
// (.grammar-test-option/-fill-input/-order-select and their click/read
// logic) is identical and shared, not duplicated.
const listeningComprehensionState = new Map();

function getListeningComprehensionRuntime(lesson) {
  let runtime = listeningComprehensionState.get(lesson.slug);
  if (!runtime) {
    runtime = { phase: 'instructions', currentIndex: 0, answers: {}, lastResult: null };
    listeningComprehensionState.set(lesson.slug, runtime);
  }
  return runtime;
}

// Legacy fallback for every Listening lesson that doesn't have a
// listeningComprehension question bank yet - today's flat, ungated
// exercises list, unchanged (see the old inline block this replaced in
// renderListeningOfficial).
function renderListeningComprehensionLegacyHtml(lesson) {
  const { total, attempted } = getExerciseProgress(lesson);
  const pct = total ? Math.round((attempted / total) * 100) : 0;
  const exercisesHtml = (lesson.exercises || [])
    .filter((item) => item.type === 'mcq')
    .map((item, index) => renderLessonExercise(item, index, lesson))
    .join('');
  return `
    <div class="listening-questions-section">
      <div class="listening-progress-bar" role="progressbar" aria-valuenow="${pct}" aria-valuemin="0" aria-valuemax="100"><div style="width:${pct}%"></div></div>
      <div class="listening-questions">${exercisesHtml || '<p class="skill-graph-empty">No hay preguntas de comprensión para esta lección.</p>'}</div>
    </div>
  `;
}

function renderListeningComprehensionInstructionsHtml(lesson, bank) {
  const total = bank.questions.length;
  const startLabel = listeningUiText('Comenzar', 'Commencer');
  return `
    <div class="grammar-test-card card-enter">
      <p class="grammar-test-instructions-text">Responde estas preguntas para comprobar cuánto entendiste del audio.</p>
      <ul class="grammar-test-meta-list">
        <li>📝 ${total} preguntas</li>
        <li>🎯 Aprobación recomendada: ${bank.passingScore || 70}/100</li>
        ${lesson.listeningComprehensionBestScore != null ? `<li>🏆 Mejor puntuación: ${lesson.listeningComprehensionBestScore}/100</li>` : ''}
      </ul>
      <button type="button" class="primary-btn hover-lift btn-press listening-comp-start-btn">${startLabel}</button>
    </div>
  `;
}

function renderListeningComprehensionQuestionHtml(lesson, bank, runtime) {
  const total = bank.questions.length;
  const index = Math.min(runtime.currentIndex, total - 1);
  const question = bank.questions[index];
  const pct = Math.round(((index + 1) / total) * 100);
  const isLast = index === total - 1;
  return `
    <div class="grammar-test-card card-enter">
      <div class="grammar-test-progress-row">
        <span class="grammar-test-counter">${listeningUiText('Pregunta', 'Question')} ${index + 1} ${listeningUiText('de', 'sur')} ${total}</span>
        <div class="grammar-test-progress-bar"><div class="progress-fill-animated" style="width:${pct}%"></div></div>
      </div>
      <p class="grammar-test-question-prompt">${escapeHtml(question.prompt)}</p>
      ${renderGrammarTestQuestionBodyHtml(question, runtime)}
      <div class="grammar-test-nav-row">
        <button type="button" class="secondary-btn hover-lift btn-press listening-comp-prev-btn" ${index === 0 ? 'disabled' : ''}>${listeningUiText('Anterior', 'Précédent')}</button>
        <button type="button" class="primary-btn hover-lift btn-press listening-comp-next-btn">${isLast ? listeningUiText('Revisar', 'Vérifier') : listeningUiText('Siguiente', 'Suivant')}</button>
      </div>
    </div>
  `;
}

function renderListeningComprehensionReviewHtml(lesson, bank, runtime) {
  const itemsHtml = bank.questions
    .map((question, index) => {
      const answered = isGrammarTestQuestionAnswered(runtime, question);
      return `
        <li class="grammar-test-review-item${answered ? ' is-answered' : ' is-unanswered'}">
          <span class="grammar-test-review-status" aria-hidden="true">${answered ? '✅' : '⚠️'}</span>
          <span class="grammar-test-review-prompt">${index + 1}. ${escapeHtml(question.prompt)}</span>
          <button type="button" class="secondary-btn listening-comp-review-edit-btn" data-question-index="${index}">${answered ? 'Editar' : 'Responder'}</button>
        </li>
      `;
    })
    .join('');
  const allAnswered = bank.questions.every((question) => isGrammarTestQuestionAnswered(runtime, question));
  return `
    <div class="grammar-test-card card-enter">
      <h4>${listeningUiText('Revisa tus respuestas', 'Vérifiez vos réponses')}</h4>
      <ul class="grammar-test-review-list">${itemsHtml}</ul>
      ${!allAnswered ? '<p class="grammar-test-review-warning">Responde todas las preguntas para poder enviar.</p>' : ''}
      <div class="grammar-test-nav-row">
        <button type="button" class="secondary-btn hover-lift btn-press listening-comp-review-edit-btn" data-question-index="${bank.questions.length - 1}">Volver a la última pregunta</button>
        <button type="button" class="primary-btn hover-lift btn-press listening-comp-submit-btn" ${!allAnswered ? 'disabled' : ''}>${listeningUiText('Enviar', 'Envoyer')}</button>
      </div>
    </div>
  `;
}

function renderListeningComprehensionResultsHtml(lesson, bank, runtime) {
  const result = runtime.lastResult;
  if (!result) {
    runtime.phase = 'instructions';
    return renderListeningComprehensionInstructionsHtml(lesson, bank);
  }
  const band = gradeBandForScore(result.score);
  const resultsByQuestionId = new Map((result.results || []).map((r) => [String(r.questionId), r]));
  const correctCount = (result.results || []).filter((r) => r.correct).length;
  const breakdownHtml = bank.questions
    .map((question, index) => {
      const r = resultsByQuestionId.get(String(question.id));
      const correct = Boolean(r?.correct);
      return `
        <li class="grammar-test-breakdown-item${correct ? ' is-correct' : ' is-incorrect'}">
          <span class="grammar-test-breakdown-icon" aria-hidden="true">${correct ? '✅' : '❌'}</span>
          <div>
            <p class="grammar-test-breakdown-prompt">${index + 1}. ${escapeHtml(question.prompt)}</p>
            ${r?.explanation ? `<p class="grammar-test-breakdown-explanation">${escapeHtml(r.explanation)}</p>` : ''}
          </div>
        </li>
      `;
    })
    .join('');
  return `
    <div class="grammar-test-card card-enter">
      <div class="grammar-test-score-band">
        <span class="grammar-test-score-emoji" aria-hidden="true">${band.emoji}</span>
        <strong class="grammar-test-score-number">${result.score}/100</strong>
        <span class="grammar-test-score-label">${band.label}</span>
      </div>
      <p class="grammar-test-score-detail">Respuestas correctas: ${correctCount} de ${bank.questions.length}</p>
      <p class="grammar-test-score-detail">
        ${result.bestScore != null ? `Mejor puntuación: ${result.bestScore}/100 · ` : ''}Intento n.º ${result.attemptNumber ?? ''} · ${new Date().toLocaleDateString('es-DO')}
      </p>
      <ul class="grammar-test-breakdown-list">${breakdownHtml}</ul>
      <button type="button" class="primary-btn hover-lift btn-press listening-comp-retry-btn">${listeningUiText('Intentar de nuevo', 'Réessayer')}</button>
    </div>
  `;
}

function renderListeningComprehensionPanel(lesson) {
  const bank = lesson.extra?.listeningComprehension;
  if (!bank?.questions?.length) return renderListeningComprehensionLegacyHtml(lesson);

  const runtime = getListeningComprehensionRuntime(lesson);
  if (runtime.phase === 'question') return renderListeningComprehensionQuestionHtml(lesson, bank, runtime);
  if (runtime.phase === 'review') return renderListeningComprehensionReviewHtml(lesson, bank, runtime);
  if (runtime.phase === 'results') return renderListeningComprehensionResultsHtml(lesson, bank, runtime);
  return renderListeningComprehensionInstructionsHtml(lesson, bank);
}

// ---------------------------------------------------------------------
// Shared vocabulary flashcard component. One normalizer + one render
// function produce every vocab card in the app (English/French/Spanish,
// every level/unit, the shuffled "review" order, and any future reuse) -
// see renderVocabularyView() below. Never fork this per language.
//
// normalizeVocabularyItem() maps whatever shape a lesson's raw vocabulary
// entry happens to have (word vs targetWord, category only on some Spanish
// items, partOfSpeech/definition only on some English items, the Spanish
// course's translation direction being reversed vs. every other course)
// onto one consistent card schema, so the renderer never has to branch on
// language or content vintage. Existing raw fields are read, never removed,
// so nothing upstream breaks.
function normalizeVocabularyItem(item, { language, level, bridgeLanguage, index = 0, lessonSlug = '' } = {}) {
  if (!item) return null;
  const targetLanguage = language || learningPathState.language;
  const resolvedBridge = bridgeLanguage || learningPathState.bridgeLanguage;
  const targetWord = item.targetWord || item.word || '';
  const id = item.id || `${lessonSlug}-${slugifyVocabWord(targetWord)}-${index}`;
  // Direct/immersion mode (spec §3/§5/§9): L1 === L2, no translation shown -
  // definition/examples/synonyms/opposites/image in L2 instead, via the
  // shared getLearningSupport() normalizer (src/js/language-pair.js). Falls
  // back to the plain bilingual shape when LanguagePair isn't loaded or the
  // item has no directSupport authored yet (existing bilingual content keeps
  // working unchanged either way).
  const learningMode = LanguagePair
    ? LanguagePair.getLearningMode(resolvedBridge, targetLanguage)
    : resolvedBridge === targetLanguage
      ? 'direct'
      : 'bilingual';
  const support =
    learningMode === 'direct' && LanguagePair
      ? LanguagePair.getLearningSupport({ item, bridgeLanguage: resolvedBridge, targetLanguage, learningMode })
      : null;
  return {
    id,
    targetWord,
    // Never show a translation in direct mode, even if the raw item still
    // carries legacy `translation` data (spec §5: "No mostrar traducción").
    translation: support ? '' : resolveVocabTranslation(item, resolvedBridge),
    example: item.example || '',
    // Direct mode prefers directSupport's own (up to 3) context examples
    // over the single legacy `example` string, when authored (spec §6: max
    // 2-3 examples at A1).
    contexts:
      support?.examples?.length
        ? support.examples.slice(0, 3).map((text) => ({ targetText: text, supportText: '' }))
        : normalizeVocabContexts(item),
    phonetic: item.phonetic || item.pronunciationIpa || '',
    audioText: item.pronunciationText || targetWord,
    category: item.category || item.partOfSpeech || '',
    masteryStatus: getStoredVocabMastery(id) || item.masteryStatus || 'new',
    difficulty: item.difficulty || level || learningPathState.level || '',
    level: level || learningPathState.level || '',
    language: targetLanguage,
    bridgeLanguage: resolvedBridge,
    targetLanguage,
    pronunciationLocale: item.pronunciationLocale || getPronunciationLocale(targetLanguage),
    pronunciationRate: item.pronunciationRate ?? getDefaultPronunciationRate(targetLanguage, level),
    learningMode,
    isAdvancedDirect:
      learningMode === 'direct' && ['C1', 'C2'].includes(level || learningPathState.level || ''),
    l1Translation:
      learningMode === 'direct' &&
      item.translation &&
      item.translation !== item.definition &&
      item.translation !== item.simpleDefinition
        ? resolveVocabTranslation(item, 'spanish')
        : '',
    definition:
      support?.definition ||
      (learningMode === 'direct' ? item.simpleDefinition || item.definition || '' : ''),
    simpleDefinition:
      support?.simpleDefinition ||
      (learningMode === 'direct' ? item.simpleDefinition || item.definition || '' : ''),
    synonyms: support?.synonyms || [],
    opposites: support?.opposites || [],
    usageNote: support?.usageNote || '',
    // Only set when a real, pedagogically-useful image is authored (spec
    // §10) - never a placeholder. renderVocabCardHtml skips the image block
    // entirely when this is empty, no broken box/alt text ever shown.
    image: support?.image || '',
    imageAlt: support?.imageAlt || ''
  };
}

// Card backs show 1-3 "contexts" (an L2 example sentence + optional L1
// gloss). Real content today only has a single flat `example` string per
// word, so that's wrapped into a one-item array here - a future `contexts`
// array on the raw item (richer authored data) is used as-is when present,
// never both at once.
function normalizeVocabContexts(item) {
  const raw = Array.isArray(item.contexts) && item.contexts.length
    ? item.contexts
    : item.example
      ? [{ targetText: item.example, supportText: item.exampleTranslation || '' }]
      : [];
  return raw
    .filter((ctx) => ctx && (ctx.targetText || ctx.text))
    .slice(0, 3)
    .map((ctx) => ({
      targetText: ctx.targetText || ctx.text || '',
      supportText: ctx.supportText || ctx.translation || ''
    }));
}

const VOCABULARY_L2_UI = {
  english: {
    useful: 'Useful expressions',
    show: 'Show',
    hide: 'Hide',
    multipleUses: 'More uses and nuances',
    questions: 'Vocabulary comprehension questions',
    translation: 'Meaning / translation',
    translationUnavailable: 'Meaning unavailable.'
  },
  french: {
    useful: 'Des expressions utiles',
    show: 'Afficher',
    hide: 'Masquer',
    multipleUses: 'Autres emplois et nuances',
    questions: 'Questions de compréhension du vocabulaire',
    translation: 'Sens / traduction',
    translationUnavailable: 'Sens indisponible.'
  },
  spanish: {
    useful: 'Expresiones útiles',
    show: 'Mostrar',
    hide: 'Ocultar',
    multipleUses: 'Otros usos y matices',
    questions: 'Preguntas de comprensión de vocabulario',
    translation: 'Significado / traducción',
    translationUnavailable: 'Significado no disponible.'
  },
  italian: {
    useful: 'Espressioni utili',
    show: 'Mostra',
    hide: 'Nascondi',
    multipleUses: 'Altri usi e sfumature',
    questions: 'Domande di comprensione del vocabolario',
    translation: 'Significato / traduzione',
    translationUnavailable: 'Significato non disponibile.'
  },
  german: {
    useful: 'Nützliche Ausdrücke',
    show: 'Anzeigen',
    hide: 'Ausblenden',
    multipleUses: 'Weitere Verwendungen und Nuancen',
    questions: 'Fragen zum Wortschatzverständnis',
    translation: 'Bedeutung / Übersetzung',
    translationUnavailable: 'Bedeutung nicht verfügbar.'
  }
};

function getVocabularyL2Ui(language = learningPathState.language) {
  return VOCABULARY_L2_UI[language] || VOCABULARY_L2_UI.english;
}

function renderVocabularyContextHtml(ctx, item, canSpeak, isFrench) {
  return `
    <div class="vocab-card-context">
      <p class="vocab-card-context-target">
        <span>${escapeHtml(ctx.targetText)}</span>
        ${
          canSpeak
            ? `<button type="button" class="vocab-example-audio-btn" tabindex="-1" data-speak-text="${escapeHtml(ctx.targetText)}" data-speak-locale="${escapeHtml(item.pronunciationLocale)}" data-speak-rate="${item.pronunciationRate}" aria-label="${isFrench ? 'Écouter la phrase' : 'Escuchar frase'}" title="${isFrench ? 'Écouter la phrase' : 'Escuchar frase'}">🔊</button>`
            : ''
        }
      </p>
      ${ctx.supportText ? `<p class="vocab-card-context-support">${escapeHtml(ctx.supportText)}</p>` : ''}
    </div>`;
}

function slugifyVocabWord(word = '') {
  return (
    String(word)
      .toLowerCase()
      .normalize('NFD')
      .replace(/[̀-ͯ]/g, '')
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '') || 'word'
  );
}

// Per-word mastery is purely a client-side study aid (no server-side vocab
// progress model exists yet - see getExerciseProgress() for the real,
// persisted lesson-completion progress). Stored the same way as the app's
// other localStorage preferences (andergo_voice_*, andergo_rate_*).
const VOCAB_MASTERY_STORAGE_KEY = 'andergo_vocab_mastery_v1';
const VOCAB_MASTERY_META = {
  new: { label: 'Nueva', glyph: '●' },
  learning: { label: 'Aprendiendo', glyph: '◐' },
  practicing: { label: 'En práctica', glyph: '◑' },
  mastered: { label: 'Dominada', glyph: '✓' }
};

function readVocabMasteryStore() {
  try {
    return JSON.parse(localStorage.getItem(VOCAB_MASTERY_STORAGE_KEY) || '{}');
  } catch {
    return {};
  }
}

function getStoredVocabMastery(id) {
  return readVocabMasteryStore()[id] || null;
}

function setStoredVocabMastery(id, status) {
  const store = readVocabMasteryStore();
  store[id] = status;
  try {
    localStorage.setItem(VOCAB_MASTERY_STORAGE_KEY, JSON.stringify(store));
  } catch {
    // Storage unavailable (private browsing / quota) - mastery just won't
    // survive a reload; never block the UI on it.
  }
}

// Dynamic aria-label for the card's flip state - "Ver significado de X" on
// the front, "Volver al frente de X" once flipped. See flipVocabCard().
function vocabCardAriaLabel(word, flipped, isFrench) {
  if (flipped) return isFrench ? `Revenir au recto de ${word}` : `Volver al frente de ${word}`;
  return isFrench ? `Voir le sens de ${word}` : `Ver significado de ${word}`;
}

function renderVocabCardHtml(item, { canSpeak, isFrench, showL1Translation = false }) {
  const meta = VOCAB_MASTERY_META[item.masteryStatus] || VOCAB_MASTERY_META.new;
  const frenchStatusLabels = {
    new: 'Nouvelle',
    learning: 'En apprentissage',
    practicing: 'À pratiquer',
    mastered: 'Maîtrisée'
  };
  const speakAriaLabel = isFrench
    ? `Écouter la prononciation de ${item.targetWord}`
    : `Escuchar pronunciación de ${item.targetWord}`;
  const statusChipHtml = `
    <span class="vocab-card-status" aria-live="polite">
      <span class="vocab-status-dot" aria-hidden="true">${meta.glyph}</span>
      <span class="vocab-status-label">${isFrench ? frenchStatusLabels[item.masteryStatus] || 'Nouvelle' : meta.label}</span>
    </span>`;
  const l2Ui = getVocabularyL2Ui(item.targetLanguage);
  const cardUi = {
    english: {
      front: 'Word',
      back: item.learningMode === 'direct' ? 'Meaning in context' : 'Meaning',
      hint: 'Tap to reveal',
      mode: 'Direct method'
    },
    french: {
      front: 'Mot',
      back: item.learningMode === 'direct' ? 'Sens en contexte' : 'Sens',
      hint: 'Touchez pour découvrir',
      mode: 'Méthode directe'
    },
    spanish: {
      front: 'Palabra',
      back: item.learningMode === 'direct' ? 'Significado en contexto' : 'Significado',
      hint: 'Toca para descubrir',
      mode: 'Método directo'
    }
  }[item.targetLanguage] || {
    front: 'Word',
    back: 'Meaning',
    hint: 'Tap to reveal',
    mode: 'Direct method'
  };
  const firstContext = item.contexts[0];
  const additionalContexts = item.contexts.slice(1);
  const contextsHtml = firstContext
    ? `<div class="vocab-card-contexts">
        ${renderVocabularyContextHtml(firstContext, item, canSpeak, isFrench)}
        ${
          additionalContexts.length || item.usageNote
            ? `<details class="vocab-card-context-info">
                <summary aria-label="${escapeHtml(l2Ui.multipleUses)}">ⓘ ${escapeHtml(l2Ui.multipleUses)}</summary>
                <div class="vocab-card-context-info-body">
                  ${additionalContexts.map((ctx) => renderVocabularyContextHtml(ctx, item, canSpeak, isFrench)).join('')}
                  ${item.usageNote ? `<p class="vocab-card-usage-note">${escapeHtml(item.usageNote)}</p>` : ''}
                </div>
              </details>`
            : ''
        }
      </div>`
    : '';

  // Direct/immersion mode (spec §5/§9): definition + synonyms/opposites +
  // image instead of a translation - translation is already '' for these
  // items (see normalizeVocabularyItem), so the vocab-card-translation
  // block above naturally stays empty. Image only renders when a real one
  // is authored (spec §10) - no placeholder box, no broken alt text.
  const lang = learningPathState.bridgeLanguage;
  const synonymsOppositesParts = [];
  if (item.synonyms?.length) {
    synonymsOppositesParts.push(
      `<span class="vocab-card-synonyms">${escapeHtml(LanguagePair.t('vocabSynonyms', lang))}: ${escapeHtml(item.synonyms.join(', '))}</span>`
    );
  }
  if (item.opposites?.length) {
    synonymsOppositesParts.push(
      `<span class="vocab-card-opposites">${escapeHtml(LanguagePair.t('vocabOpposites', lang))}: ${escapeHtml(item.opposites.join(', '))}</span>`
    );
  }
  const directSupportHtml =
    item.learningMode === 'direct'
      ? `
    ${item.image ? `<img class="vocab-card-image" src="${escapeHtml(item.image)}" alt="${escapeHtml(item.imageAlt || item.targetWord)}" loading="lazy" />` : ''}
    ${
      showL1Translation && item.l1Translation
        ? `<div class="vocab-card-l1-translation">
            <span>${escapeHtml(l2Ui.translation)}</span>
            <p>${escapeHtml(item.l1Translation)}</p>
          </div>`
        : ''
    }
    ${!item.isAdvancedDirect && synonymsOppositesParts.length ? `<p class="vocab-card-synonyms-opposites">${synonymsOppositesParts.join(' · ')}</p>` : ''}
    ${!item.contexts.length && item.usageNote ? `<p class="vocab-card-usage-note">${escapeHtml(item.usageNote)}</p>` : ''}`
      : '';

  return `
    <div class="vocab-card" data-index="${item._displayIndex}" data-card-id="${escapeHtml(item.id)}" data-mastery="${escapeHtml(item.masteryStatus)}" data-learning-mode="${escapeHtml(item.learningMode)}" data-flipped="false" data-is-french="${isFrench}" data-speak-text="${escapeHtml(item.audioText)}" data-speak-locale="${escapeHtml(item.pronunciationLocale)}" data-speak-rate="${item.pronunciationRate}" role="button" tabindex="0" aria-expanded="false" aria-label="${escapeHtml(vocabCardAriaLabel(item.targetWord, false, isFrench))}">
      <div class="vocab-card-inner">
        <div class="vocab-card-face vocab-card-front">
          <div class="vocab-card-header">
            <span class="vocab-card-side-label">${escapeHtml(cardUi.front)}</span>
            ${
              canSpeak
                ? `<button type="button" class="vocab-card-audio-btn" aria-label="${escapeHtml(speakAriaLabel)}" title="${escapeHtml(speakTitle(isFrench))}"><span aria-hidden="true">🔊</span></button>`
                : ''
            }
          </div>
          <div class="vocab-card-word-block">
            ${item.learningMode === 'direct' ? `<span class="vocab-card-method">${escapeHtml(cardUi.mode)}</span>` : ''}
            <p class="vocab-card-target">${escapeHtml(item.targetWord)}</p>
            ${item.phonetic ? `<p class="vocab-card-phonetic">${escapeHtml(item.phonetic)}</p>` : ''}
            ${item.category ? `<span class="vocab-card-tag">${escapeHtml(item.category)}</span>` : ''}
          </div>
          <div class="vocab-card-front-footer">
            ${statusChipHtml}
            <p class="vocab-card-hint"><span aria-hidden="true">↻</span> ${escapeHtml(cardUi.hint)}</p>
          </div>
        </div>
        <div class="vocab-card-face vocab-card-back" aria-hidden="true">
          <div class="vocab-card-header">
            <span class="vocab-card-side-label">${escapeHtml(cardUi.back)}</span>
            ${statusChipHtml}
          </div>
          ${item.translation ? `<p class="vocab-card-translation">${escapeHtml(item.translation)}</p>` : ''}
          ${directSupportHtml}
          ${contextsHtml}
          <div class="vocab-card-actions" role="group" aria-label="${isFrench ? 'Actions d’apprentissage' : 'Acciones de aprendizaje'}">
            <button type="button" class="vocab-know-btn" tabindex="-1" aria-label="${isFrench ? 'Je la connais déjà' : 'Ya sé esta palabra'}" title="${isFrench ? 'Je la connais déjà' : 'Ya sé esta palabra'}">✓ ${isFrench ? 'Je la connais' : 'Ya la sé'}</button>
            <button type="button" class="vocab-retry-btn" tabindex="-1" aria-label="${isFrench ? 'À continuer à pratiquer' : 'Marcar para seguir practicando'}" title="${isFrench ? 'À continuer à pratiquer' : 'Marcar para seguir practicando'}">↻ ${isFrench ? 'À revoir' : 'Practicar'}</button>
            <button type="button" class="vocab-back-btn" tabindex="-1" aria-label="${vocabCardAriaLabel(item.targetWord, true, isFrench)}" title="${isFrench ? 'Revenir au recto' : 'Volver al frente'}">↩ ${isFrench ? 'Retour' : 'Volver'}</button>
          </div>
        </div>
      </div>
    </div>
  `;
}

// vocabCardOrder holds the current (possibly shuffled) display order for
// the active lesson's flashcard deck - reset every time a new vocabulary
// lesson is rendered, never persisted, purely a display convenience so
// "Mezclar tarjetas" can re-render without touching lesson.vocabulary itself.
let vocabCardOrder = [];
let vocabL1TranslationVisible = true;
let vocabTranslationLessonSlug = '';
const vocabL1TranslationCache = new Map();
const vocabL1TranslationRequests = new Set();
const vocabBriefDefinitionCache = new Map();
const vocabBriefDefinitionRequests = new Set();
const vocabPracticeState = new Map();
const vocabPracticeSources = new Map();

async function loadMissingAdvancedVocabTranslations(cards, lessonSlug = '') {
  const missing = cards.filter((card) => card.isAdvancedDirect && !card.l1Translation);
  if (
    !missing.length ||
    learningPathState.language === 'spanish' ||
    (lessonSlug && vocabL1TranslationRequests.has(lessonSlug))
  )
    return false;
  if (lessonSlug) vocabL1TranslationRequests.add(lessonSlug);
  let changed = false;
  await Promise.all(
    missing.map(async (card) => {
      try {
        const data = await postJson(
          '/api/translate',
          {
            text: card.targetWord,
            sourceLanguage: learningPathState.language,
            targetLanguage: 'spanish'
          },
          { auth: true }
        );
        if (data.ok && data.translatedText) {
          vocabL1TranslationCache.set(card.id, data.translatedText);
          card.l1Translation = data.translatedText;
          changed = true;
        }
      } catch {
        // The card remains useful with its L2 brief definition when the
        // optional translator is unavailable.
      }
    })
  );
  return changed;
}

async function loadMissingAdvancedBriefDefinitions(cards, lessonSlug) {
  const missing = cards.filter(
    (card) => card.isAdvancedDirect && !card.simpleDefinition && card.l1Translation
  );
  if (!missing.length || vocabBriefDefinitionRequests.has(lessonSlug)) return false;
  vocabBriefDefinitionRequests.add(lessonSlug);
  let changed = false;
  await Promise.all(
    missing.map(async (card) => {
      try {
        const data = await postJson(
          '/api/translate',
          {
            text: card.l1Translation,
            sourceLanguage: 'spanish',
            targetLanguage: learningPathState.language
          },
          { auth: true }
        );
        if (data.ok && data.translatedText) {
          vocabBriefDefinitionCache.set(card.id, data.translatedText);
          changed = true;
        }
      } catch {
        /* Keep the definition block empty rather than substituting an example. */
      }
    })
  );
  return changed;
}

function getVocabularyPracticeCount(level = learningPathState.level) {
  if (level === 'A1' || level === 'A2') return 6;
  if (level === 'B1' || level === 'B2') return 8;
  return 10;
}

function shuffleVocabularyItems(items) {
  const copy = [...items];
  for (let index = copy.length - 1; index > 0; index -= 1) {
    const swapIndex = Math.floor(Math.random() * (index + 1));
    [copy[index], copy[swapIndex]] = [copy[swapIndex], copy[index]];
  }
  return copy;
}

function buildVocabularyPracticePrompt(item) {
  const french = isFrenchAdvancedImmersion();
  const context = item.contexts?.[0]?.targetText || item.example || '';
  if (context) {
    const escapedWord = String(item.targetWord).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const blanked = context.replace(new RegExp(escapedWord, 'i'), '_____');
    return blanked !== context
      ? `${french ? 'Choisissez le mot qui complète la phrase' : 'Choose the word that completes the sentence'} : « ${blanked} »`
      : `${french ? 'Choisissez le mot qui correspond le mieux à ce contexte' : 'Choose the vocabulary item that best matches this context'} : « ${context} »`;
  }
  if (item.definition || item.simpleDefinition) {
    return `${french ? 'Choisissez le mot correspondant à cette définition' : 'Choose the word for this definition'} : « ${item.simpleDefinition || item.definition} »`;
  }
  return `${french ? 'Identifiez le mot de la leçon' : 'Identify this lesson word'} : « ${item.translation || item.targetWord} »`;
}

function createVocabularyPractice(lesson, cards) {
  const count = getVocabularyPracticeCount(lesson.level);
  const shuffled = shuffleVocabularyItems(cards);
  const selected = Array.from({ length: count }, (_, index) => shuffled[index % shuffled.length]);
  const questions = selected.map((item, index) => {
    const distractors = shuffleVocabularyItems(
      cards.filter((candidate) => candidate.id !== item.id)
    ).slice(0, 3);
    return {
      id: `${lesson.slug}-vocab-practice-${index + 1}`,
      prompt: buildVocabularyPracticePrompt(item),
      correctOptionId: item.id,
      options: shuffleVocabularyItems([item, ...distractors]).map((option) => ({
        id: option.id,
        text: option.targetWord
      }))
    };
  });
  return { questions, answers: {}, submitted: false, score: null, results: [] };
}

function renderVocabularyPracticePanelHtml(lesson) {
  const runtime = vocabPracticeState.get(lesson.slug);
  const count = getVocabularyPracticeCount(lesson.level);
  const french = isFrenchAdvancedImmersion();
  if (!runtime) {
    return `
      <div class="vocab-practice-intro">
        <strong>${count} ${french ? 'mots à pratiquer' : 'palabras para practicar'}</strong>
        <span>${french ? 'Complétez des phrases en contexte, choisissez A–D et obtenez un score sur 100.' : 'Completa frases en contexto, elige A–D y recibe un score sobre 100.'}</span>
      </div>`;
  }
  if (runtime.submitted) {
    return `
      <div class="grammar-test-card vocab-practice-results">
        <div class="grammar-test-score-band">
          <span class="grammar-test-score-emoji" aria-hidden="true">${runtime.score >= 70 ? '🏆' : '📚'}</span>
          <strong class="grammar-test-score-number">${runtime.score}/100</strong>
          <span class="grammar-test-score-label">${runtime.score >= 70 ? (french ? 'Pratique terminée' : 'Practice completed') : (french ? 'Continuez à pratiquer' : 'Keep practicing')}</span>
        </div>
        <ul class="grammar-test-breakdown-list">
          ${runtime.results
            .map(
              (result, index) => `
                <li class="grammar-test-breakdown-item ${result.correct ? 'is-correct' : 'is-incorrect'}">
                  <span aria-hidden="true">${result.correct ? '✅' : '❌'}</span>
                  <div>
                    <p class="grammar-test-breakdown-prompt">${index + 1}. ${escapeHtml(result.prompt)}</p>
                    <p class="grammar-test-breakdown-correct-answer">${french ? 'Bonne réponse' : 'Correct answer'} : <strong>${escapeHtml(result.correctText)}</strong></p>
                  </div>
                </li>`
            )
            .join('')}
        </ul>
        <button type="button" class="primary-btn vocab-practice-retry-btn">${french ? `Pratiquer ${count} autres mots` : `Practice another ${count} words`}</button>
      </div>`;
  }
  const answered = Object.keys(runtime.answers).length;
  return `
    <div class="grammar-test-card vocab-practice-card">
      <div class="grammar-test-progress-row">
        <span class="grammar-test-counter">${answered} ${french ? 'sur' : 'of'} ${runtime.questions.length} ${french ? 'réponses' : 'answered'}</span>
        <div class="grammar-test-progress-bar"><div style="width:${Math.round((answered / runtime.questions.length) * 100)}%"></div></div>
      </div>
      <div class="grammar-test-question-list">
        ${runtime.questions
          .map(
            (question, index) => `
              <article class="grammar-test-question-item vocab-practice-question" data-question-id="${escapeHtml(question.id)}">
                <p class="grammar-test-question-prompt">${index + 1}. ${escapeHtml(question.prompt)}</p>
                <div class="grammar-test-options">
                  ${question.options
                    .map((option, optionIndex) => {
                      const selected = runtime.answers[question.id] === option.id;
                      return `<button type="button" class="grammar-test-option vocab-practice-option${selected ? ' is-selected' : ''}" data-option-id="${escapeHtml(option.id)}" aria-pressed="${selected}">
                        <span class="grammar-test-option-letter" aria-hidden="true">${String.fromCharCode(65 + optionIndex)}</span>
                        <span>${escapeHtml(option.text)}</span>
                      </button>`;
                    })
                    .join('')}
                </div>
              </article>`
          )
          .join('')}
      </div>
      <div class="grammar-test-submit-bar">
        <span>${french ? 'Score final' : 'Final score'} : 0–100</span>
        <button type="button" class="primary-btn vocab-practice-submit-btn" ${answered === runtime.questions.length ? '' : 'disabled'}>${french ? 'Évaluer la pratique' : 'Evaluate practice'}</button>
      </div>
    </div>`;
}

async function loadSavedVocabularyForLesson(lesson) {
  const unitSlug = lesson.unitId || '';
  if (
    !authStatus.session?.access_token ||
    (authStatus.entitlements !== null && !isPremiumUser())
  ) {
    return [];
  }
  const params = new URLSearchParams();
  if (unitSlug) params.set('unitSlug', unitSlug);
  const response = await fetch(`${backendBaseUrl}/api/vocabulary/saved?${params}`, {
    headers: authHeaders()
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(data.error || 'No se pudo cargar el vocabulario guardado.');
    error.code = data.code || '';
    throw error;
  }
  return data.items || [];
}

function renderSavedVocabularyPremiumShelf(shelf) {
  shelf.innerHTML = `
    <div class="saved-reading-vocabulary-premium">
      <div>
        <strong>🔒 Palabras guardadas desde Reading</strong>
        <span>Guarda y repasa tu vocabulario personal con ANDERGO Premium.</span>
      </div>
      <button type="button" class="secondary-btn saved-vocabulary-premium-btn">Ver Premium</button>
    </div>
  `;
  shelf.querySelector('.saved-vocabulary-premium-btn')?.addEventListener('click', () =>
    openPaywallModal({
      title: 'Guardar palabras es una función Premium.',
      message: 'Desbloquea el vocabulario personal para guardar, escuchar y repasar palabras de tus lecturas.'
    })
  );
}

async function renderSavedVocabularyShelf(content, lesson) {
  const shelf = content.querySelector('.saved-reading-vocabulary');
  if (!shelf) return;
  if (savedVocabularyRequiresUpgrade()) {
    renderSavedVocabularyPremiumShelf(shelf);
    return;
  }
  try {
    const items = await loadSavedVocabularyForLesson(lesson);
    if (!items.length) {
      shelf.innerHTML = `
        <div class="saved-reading-vocabulary-empty">
          <strong>Palabras guardadas desde Reading</strong>
          <span>Selecciona una palabra desconocida en la lectura y guárdala para estudiarla aquí.</span>
        </div>
      `;
      return;
    }
    shelf.innerHTML = `
      <div class="saved-reading-vocabulary-heading">
        <div><strong>Palabras guardadas desde Reading</strong><span>${items.length} en esta unidad</span></div>
      </div>
      <div class="saved-reading-vocabulary-grid">
        ${items
          .map(
            (item) => `
              <article class="saved-reading-word" data-saved-word-id="${escapeHtml(item.id || '')}">
                <div><strong>${escapeHtml(item.term)}</strong><span>${escapeHtml(item.translation)}</span></div>
                ${item.context ? `<p>${escapeHtml(item.context)}</p>` : ''}
                <button type="button" class="saved-reading-word-listen" data-speak-text="${escapeHtml(item.term)}">🔊</button>
              </article>
            `
          )
          .join('')}
      </div>
    `;
    shelf.querySelectorAll('.saved-reading-word-listen').forEach((button) => {
      button.addEventListener('click', () =>
        speakText(button.dataset.speakText || '', {
          locale: getPronunciationLocale(learningPathState.language),
          rate: getDefaultPronunciationRate(learningPathState.language, lesson.level)
        })
      );
    });
  } catch (error) {
    if (error.code === 'PREMIUM_REQUIRED') {
      authStatus.entitlements = { ...(authStatus.entitlements || {}), isPremium: false };
      renderSavedVocabularyPremiumShelf(shelf);
      return;
    }
    shelf.innerHTML = `<p class="skill-graph-empty">${escapeHtml(error.message)}</p>`;
  }
}

function getUsefulVocabularyExpressions(lesson, cards) {
  const authored = (lesson.phrases || [])
    .map((phrase) =>
      typeof phrase === 'string'
        ? { text: phrase, explanation: '' }
        : {
            text: phrase?.text || phrase?.expression || phrase?.phrase || '',
            explanation: phrase?.explanation || phrase?.meaning || phrase?.note || ''
          }
    )
    .filter((item) => item.text);
  if (authored.length) return authored.slice(0, 8);

  // Older vocabulary lessons did not carry a dedicated phrases array.
  // Their authored context sentences remain useful expressions, but stay
  // presentation-only and are never passed to the question generator.
  const seen = new Set();
  return cards
    .flatMap((card) => card.contexts || [])
    .map((context) => ({
      text: context.targetText || '',
      explanation: context.supportText || ''
    }))
    .filter((item) => {
      const key = item.text.trim().toLocaleLowerCase();
      if (!key || seen.has(key)) return false;
      seen.add(key);
      return true;
    })
    .slice(0, 6);
}

function renderUsefulVocabularyExpressionsHtml(lesson, cards) {
  const ui = getVocabularyL2Ui();
  const expressions = getUsefulVocabularyExpressions(lesson, cards);
  return `
    <section class="vocab-useful-expressions no-print">
      <button type="button" class="secondary-btn vocab-useful-expressions-toggle" aria-expanded="false" data-show-label="${escapeHtml(ui.show)}" data-hide-label="${escapeHtml(ui.hide)}">
        <span class="vocab-useful-expressions-action">${escapeHtml(ui.show)}</span>
        <span>${escapeHtml(ui.useful)}</span>
      </button>
      <div class="vocab-useful-expressions-panel" hidden>
        ${
          expressions.length
            ? `<ul>${expressions
                .map(
                  (item) => `<li>
                    <strong>${escapeHtml(item.text)}</strong>
                    ${item.explanation ? `<span>${escapeHtml(item.explanation)}</span>` : ''}
                  </li>`
                )
                .join('')}</ul>`
            : `<p>${escapeHtml(ui.useful)}</p>`
        }
      </div>
    </section>`;
}

function isVocabularyTermExercise(exercise, cards) {
  if (exercise?.type !== 'mcq') return false;
  const terms = cards
    .map((card) => String(card.targetWord || '').trim().toLocaleLowerCase())
    .filter(Boolean);
  const prompt = String(exercise.prompt || exercise.q || '').toLocaleLowerCase();
  const options = (exercise.options || []).map((option) =>
    String(optionLabel(option) || '').trim().toLocaleLowerCase()
  );
  return terms.some(
    (term) => prompt.includes(term) || options.some((option) => option === term)
  );
}

function renderVocabularyView(section, lesson) {
  const content = section.querySelector('.skill-view-content');
  if (!content) return;
  const rawCards = lesson.vocabulary || [];
  if (vocabCardOrder.length !== rawCards.length || vocabCardOrder.lessonSlug !== lesson.slug) {
    vocabCardOrder = rawCards.map((_, index) => index);
    vocabCardOrder.lessonSlug = lesson.slug;
  }
  if (vocabTranslationLessonSlug !== lesson.slug) {
    vocabTranslationLessonSlug = lesson.slug;
    vocabL1TranslationVisible = true;
  }
  const cards = rawCards.map((raw, index) =>
    normalizeVocabularyItem(raw, {
      language: learningPathState.language,
      level: lesson.level,
      lessonSlug: lesson.slug,
      index
    })
  );
  cards.forEach((card) => {
    const cachedTranslation = vocabL1TranslationCache.get(card.id);
    if (cachedTranslation) card.l1Translation = cachedTranslation;
    const cachedDefinition = vocabBriefDefinitionCache.get(card.id);
    if (cachedDefinition) {
      card.definition = cachedDefinition;
      card.simpleDefinition = cachedDefinition;
    }
  });
  const advancedDirect = cards.some((card) => card.isAdvancedDirect);
  const canSpeak = supportsSpeech();
  const isFrench = learningPathState.language === 'french';
  const french = isFrenchAdvancedImmersion();
  const staff = isStaffEntitled();
  vocabPracticeSources.set(lesson.slug, cards);
  const vocabularyExercises = (lesson.exercises || []).filter((item) =>
    isVocabularyTermExercise(item, cards)
  );
  const testExercisesHtml = vocabularyExercises
    .map((item, index) => renderLessonExercise(item, index, lesson))
    .join('');
  const printExercisesHtml = renderPrintableExerciseList(vocabularyExercises, { showAnswers: staff });
  const vocabularyUi = getVocabularyL2Ui();

  content.innerHTML = `
    <h3>${escapeHtml(lesson.title)}</h3>
    <section class="saved-reading-vocabulary" aria-live="polite">
      <p class="skill-graph-empty">${french ? 'Chargement des mots enregistrés depuis Reading…' : 'Cargando palabras guardadas desde Reading…'}</p>
    </section>
    <div class="vocab-card-deck-controls no-print">
      <button type="button" class="secondary-btn vocab-shuffle-btn">🔀 ${french ? 'Mélanger les cartes' : 'Mezclar tarjetas'}</button>
      ${
        advancedDirect
          ? `<button type="button" class="secondary-btn vocab-l1-translation-btn${vocabL1TranslationVisible ? ' is-active' : ''}" aria-pressed="${vocabL1TranslationVisible}">
              ${vocabL1TranslationVisible ? '◉' : '◎'} ${french ? (vocabL1TranslationVisible ? 'Masquer la traduction L1' : 'Afficher la traduction L1') : (vocabL1TranslationVisible ? 'Desactivar traducción L1' : 'Activar traducción L1')}
            </button>`
          : ''
      }
    </div>
    <div class="vocab-card-deck">
      ${vocabCardOrder
        .map((cardIndex) =>
          renderVocabCardHtml(
            { ...cards[cardIndex], _displayIndex: cardIndex },
            { canSpeak, isFrench, showL1Translation: vocabL1TranslationVisible }
          )
        )
        .join('')}
    </div>
    ${renderUsefulVocabularyExpressionsHtml(lesson, cards)}
    <div class="skill-view-tutor-cta no-print">
      <button type="button" class="primary-btn vocab-practice-start-btn">${french ? 'Pratiquer' : 'Practicar'} ${getVocabularyPracticeCount(lesson.level)} ${french ? 'mots' : 'palabras'}</button>
      <button type="button" class="secondary-btn open-tutor-btn" data-tutor-prompt="${french ? 'Aide-moi à pratiquer ce vocabulaire' : 'Ayúdame a practicar este vocabulario'} : ${escapeHtml(cards.map((c) => c.targetWord).join(', '))}" data-support-mode="practice" data-tutor-vocabulary="${escapeHtml(cards.map((c) => c.targetWord).join(', '))}">${french ? 'Pratiquer avec le Tutor IA' : 'Practicar con Tutor IA'}</button>
      <button type="button" class="secondary-btn open-translator-btn" data-translate-text="${escapeHtml(cards.map((c) => c.targetWord).join(', '))}" data-return-label="${french ? 'Retour à Vocabulary' : 'Volver a Vocabulary'}">${french ? 'Traduire ces mots' : 'Traducir estas palabras'}</button>
    </div>
    <div class="vocab-practice-panel no-print">${renderVocabularyPracticePanelHtml(lesson)}</div>
    <div class="vocab-test no-print">
      <h4>${escapeHtml(vocabularyUi.questions)}</h4>
      ${testExercisesHtml || `<p class="skill-graph-empty">${french ? 'Aucun test de vocabulaire pour cette leçon.' : 'No hay prueba de vocabulario para esta lección.'}</p>`}
    </div>
    <div class="skill-print-area print-only">
      ${renderSkillPrintHeaderHtml(lesson)}
      <h3 class="print-only">${escapeHtml(lesson.title)}</h3>
      <div class="print-only">
        <h4>${staff ? (french ? 'Corrigé' : 'Clave de respuestas') : (french ? 'Vocabulaire et activité à compléter' : 'Vocabulario y actividad para completar')}</h4>
        <ul class="skill-print-options">
          ${cards.map((item) => `<li class="skill-print-option">${escapeHtml(item.targetWord)} — ${escapeHtml(item.translation)}${item.example ? ` (${escapeHtml(item.example)})` : ''}</li>`).join('')}
        </ul>
        ${printExercisesHtml}
        ${
          staff
            ? ''
            : `<div class="reading-print-answer-space skill-print-answer-space print-only">
                <h4>${french ? 'Vos réponses' : 'Tus respuestas'}</h4>
                <div class="reading-print-answer-lines"><div></div><div></div><div></div><div></div></div>
              </div>`
        }
      </div>
    </div>
    <div class="skill-view-tutor-cta no-print">
      <button type="button" class="secondary-btn skill-print-btn">${staff ? (french ? 'Télécharger le corrigé' : 'Descargar clave de respuestas') : (french ? 'Télécharger le vocabulaire en PDF' : 'Descargar vocabulario en PDF')}</button>
    </div>
  `;
  renderSavedVocabularyShelf(content, lesson);
  if (advancedDirect && cards.some((card) => !card.l1Translation)) {
    void loadMissingAdvancedVocabTranslations(cards, lesson.slug).then((changed) => {
      if (changed && vocabTranslationLessonSlug === lesson.slug && section.isConnected) {
        renderVocabularyView(section, lesson);
      }
    });
  }
  if (advancedDirect && cards.some((card) => !card.simpleDefinition)) {
    void loadMissingAdvancedBriefDefinitions(cards, lesson.slug).then((changed) => {
      if (
        changed &&
        vocabTranslationLessonSlug === lesson.slug &&
        section.isConnected
      ) {
        renderVocabularyView(section, lesson);
      }
    });
  }
}

function getActiveVocabularyPracticeContext(target) {
  const section = target.closest('.skill-view-section[data-skill="vocabulary"]');
  const lesson = learningPathState.lessons.find(
    (item) => item.slug === section?.dataset.activeLessonSlug
  );
  if (!section || !lesson) return null;
  return { section, lesson, cards: vocabPracticeSources.get(lesson.slug) || [] };
}

document.addEventListener('click', (event) => {
  const expressionsToggle = event.target.closest('.vocab-useful-expressions-toggle');
  if (expressionsToggle) {
    const panel = expressionsToggle
      .closest('.vocab-useful-expressions')
      ?.querySelector('.vocab-useful-expressions-panel');
    if (!panel) return;
    const willOpen = panel.hidden;
    panel.hidden = !willOpen;
    expressionsToggle.setAttribute('aria-expanded', String(willOpen));
    const action = expressionsToggle.querySelector('.vocab-useful-expressions-action');
    if (action) {
      action.textContent = willOpen
        ? expressionsToggle.dataset.hideLabel
        : expressionsToggle.dataset.showLabel;
    }
    return;
  }

  const startButton = event.target.closest('.vocab-practice-start-btn, .vocab-practice-retry-btn');
  if (startButton) {
    const context = getActiveVocabularyPracticeContext(startButton);
    if (!context?.cards.length) return;
    vocabPracticeState.set(
      context.lesson.slug,
      createVocabularyPractice(context.lesson, context.cards)
    );
    renderVocabularyView(context.section, context.lesson);
    context.section
      .querySelector('.vocab-practice-panel')
      ?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    return;
  }

  const optionButton = event.target.closest('.vocab-practice-option');
  if (optionButton) {
    const context = getActiveVocabularyPracticeContext(optionButton);
    const runtime = context && vocabPracticeState.get(context.lesson.slug);
    const questionId = optionButton.closest('.vocab-practice-question')?.dataset.questionId;
    if (!context || !runtime || !questionId) return;
    runtime.answers[questionId] = optionButton.dataset.optionId;
    optionButton
      .closest('.grammar-test-options')
      ?.querySelectorAll('.vocab-practice-option')
      .forEach((button) => {
        const selected = button === optionButton;
        button.classList.toggle('is-selected', selected);
        button.setAttribute('aria-pressed', String(selected));
      });
    const answered = Object.keys(runtime.answers).length;
    const panel = context.section.querySelector('.vocab-practice-panel');
    const counter = panel?.querySelector('.grammar-test-counter');
    const progress = panel?.querySelector('.grammar-test-progress-bar div');
    const submit = panel?.querySelector('.vocab-practice-submit-btn');
    if (counter) counter.textContent = `${answered} of ${runtime.questions.length} answered`;
    if (progress)
      progress.style.width = `${Math.round((answered / runtime.questions.length) * 100)}%`;
    if (submit) submit.disabled = answered !== runtime.questions.length;
    return;
  }

  const submitButton = event.target.closest('.vocab-practice-submit-btn');
  if (submitButton) {
    const context = getActiveVocabularyPracticeContext(submitButton);
    const runtime = context && vocabPracticeState.get(context.lesson.slug);
    if (!context || !runtime || submitButton.disabled) return;
    runtime.results = runtime.questions.map((question) => ({
      prompt: question.prompt,
      correct: runtime.answers[question.id] === question.correctOptionId,
      correctText:
        question.options.find((option) => option.id === question.correctOptionId)?.text || ''
    }));
    const correctCount = runtime.results.filter((result) => result.correct).length;
    runtime.score = Math.round((correctCount / runtime.questions.length) * 100);
    runtime.submitted = true;
    renderVocabularyView(context.section, context.lesson);
    context.section
      .querySelector('.vocab-practice-panel')
      ?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
});

// Flips a card between its front (word only) and back (translation +
// contexts + mastery actions), keeping the two faces' focusable buttons,
// aria-hidden and the card's own aria-expanded/aria-label in sync. `toBack`
// forces a direction (used by the "Volver" button and Escape); omitting it
// toggles. `speak` is true only for the tap-the-card-body path going
// front -> back, so the word is read exactly once per flip and never on the
// way back. Marks a never-touched card "learning" the first time it's
// flipped; "Ya la sé"/"Practicar" always set an explicit status afterwards.
function flipVocabCard(card, { toBack, speak = false } = {}) {
  if (!card) return;
  const isFlipped = card.dataset.flipped === 'true';
  const nextFlipped = typeof toBack === 'boolean' ? toBack : !isFlipped;
  if (nextFlipped === isFlipped) return;
  card.dataset.flipped = String(nextFlipped);
  card.classList.toggle('is-flipped', nextFlipped);
  card.setAttribute('aria-expanded', String(nextFlipped));
  const word = card.querySelector('.vocab-card-target')?.textContent || '';
  const isFrench = card.dataset.isFrench === 'true';
  card.setAttribute('aria-label', vocabCardAriaLabel(word, nextFlipped, isFrench));
  const front = card.querySelector('.vocab-card-front');
  if (front) {
    front.setAttribute('aria-hidden', String(nextFlipped));
    front.querySelectorAll('button').forEach((btn) => {
      btn.tabIndex = nextFlipped ? -1 : 0;
    });
  }
  const back = card.querySelector('.vocab-card-back');
  if (back) {
    back.setAttribute('aria-hidden', String(!nextFlipped));
    back.querySelectorAll('button').forEach((btn) => {
      btn.tabIndex = nextFlipped ? 0 : -1;
    });
  }
  if (nextFlipped && card.dataset.mastery === 'new') setVocabCardMastery(card, 'learning');
  if (nextFlipped && speak) {
    const audioBtn = card.querySelector('.vocab-card-audio-btn');
    audioBtn?.classList.add('is-playing');
    speakText(card.dataset.speakText, {
      locale: card.dataset.speakLocale,
      rate: Number(card.dataset.speakRate) || 1,
      onEnd: () => audioBtn?.classList.remove('is-playing')
    });
  }
}

// Status chip is duplicated on both faces (section 8 requirement: visible
// whichever side is showing), so both copies are updated together.
function setVocabCardMastery(card, status) {
  if (!card) return;
  const meta = VOCAB_MASTERY_META[status] || VOCAB_MASTERY_META.new;
  card.dataset.mastery = status;
  setStoredVocabMastery(card.dataset.cardId, status);
  card.querySelectorAll('.vocab-status-label').forEach((el) => {
    el.textContent = meta.label;
  });
  card.querySelectorAll('.vocab-status-dot').forEach((el) => {
    el.textContent = meta.glyph;
  });
}

function speakTitle(isFrench) {
  return isFrench ? 'Écouter la prononciation' : 'Escuchar pronunciación';
}

// Vocab flashcards: Enter/Space flips the focused card (mirroring a tap on
// the card body, including the single audio playback on the front -> back
// flip); Escape always returns to the front. Delegated on document (like
// the click handler below) because renderVocabularyView() replaces the
// whole deck's markup on shuffle/re-render, which would orphan per-card
// listeners. Skipped when focus is already on one of the card's own
// buttons so their native Enter/Space activation isn't double-handled.
document.addEventListener('keydown', (event) => {
  const card = event.target.closest?.('.vocab-card');
  if (!card) return;
  if (event.target.closest('button')) return;
  if (event.key === 'Enter' || event.key === ' ') {
    event.preventDefault();
    const isFlipped = card.dataset.flipped === 'true';
    flipVocabCard(card, { toBack: !isFlipped, speak: !isFlipped });
  } else if (event.key === 'Escape') {
    flipVocabCard(card, { toBack: false });
  }
});

// ---------------------------------------------------------------------
// Listening: real player + dual audio source (official Supabase-hosted
// audio if published, otherwise an ephemeral AI-generated practice) +
// transcript + comprehension questions + Tutor IA context. See
// docs/audio-architecture.md for the two-source design and why
// AI-generated audio is never persisted in this phase.
// ---------------------------------------------------------------------

// Caches the /api/listening/audio status lookup per language+level+lesson so
// re-rendering after answering a comprehension question (see the
// .mcq-option handler) never refetches or rebuilds the <audio> element,
// which would otherwise reset playback to 0.
const listeningAudioStatusCache = new Map();
// Per-lesson UI-only state (never sent to the backend as truth): whether the
// transcript has been revealed, whether the student has pressed play at
// least once (drives the A1/A2 transcript gate), and the currently active
// AI-generated practice (if any) with its locally-graded answers.
const listeningViewRuntime = new Map();

function listeningStatusCacheKey(lesson) {
  return `${learningPathState.language}|${learningPathState.level}|${lesson.slug}`;
}

function getListeningRuntime(lesson) {
  let runtime = listeningViewRuntime.get(lesson.slug);
  if (!runtime) {
    runtime = {
      transcriptRevealed: false,
      storyRevealed: false,
      hasPlayedOnce: false,
      transcriptSoftGateOverride: false,
      usingSlow: false
    };
    listeningViewRuntime.set(lesson.slug, runtime);
  }
  return runtime;
}

function listeningUiText(spanish, french) {
  return learningPathState.language === 'french' ? french : spanish;
}

async function fetchListeningAudioStatus(lesson) {
  const key = listeningStatusCacheKey(lesson);
  if (listeningAudioStatusCache.has(key)) return listeningAudioStatusCache.get(key);
  const promise = (async () => {
    try {
      const params = new URLSearchParams({
        language: learningPathState.language,
        level: learningPathState.level,
        lessonSlug: lesson.slug,
        // Real lesson_id (course_lessons.id) when this lesson came from the
        // normalized schema - server.js prefers this over language/level/
        // slug (spec: resolve audio by the real lesson_id, not just a slug).
        // Empty string for legacy-schema lessons; server.js's uuid guard
        // then falls straight through to the slug-based lookup.
        lessonId: lesson.id || ''
      });
      const response = await fetch(`${backendBaseUrl}/api/listening/audio?${params.toString()}`, {
        headers: authHeaders()
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok)
        throw new Error(data.error || 'No se pudo consultar el audio de Listening.');
      return data;
    } catch (error) {
      return {
        status: 'error',
        error: error.message || 'No se pudo consultar el audio de Listening.'
      };
    }
  })();
  listeningAudioStatusCache.set(key, promise);
  return promise;
}

function formatListeningTime(seconds) {
  if (!Number.isFinite(seconds) || seconds < 0) return '0:00';
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m}:${String(s).padStart(2, '0')}`;
}

function getListeningAllAttempted(lesson) {
  return getExerciseProgress(lesson).allAttempted;
}

// A1/A2: gently discourage reading before listening, but never hard-block
// (accessibility escape hatch). B1/B2: on demand. C1/C2: only as review,
// after every question has been attempted.
function getTranscriptGateState(level, runtime, allAttempted) {
  if (level === 'C1' || level === 'C2') return allAttempted ? 'open' : 'locked-until-review';
  if (level === 'A1' || level === 'A2')
    return runtime.hasPlayedOnce || runtime.transcriptSoftGateOverride ? 'open' : 'soft-gate';
  return 'open';
}

function renderListeningTranscriptControls(content, lesson, runtime) {
  const controlsEl = content.querySelector('.listening-transcript-controls');
  const bodyEl = content.querySelector('.listening-transcript-body');
  if (!controlsEl || !bodyEl) return;
  const allAttempted = getListeningAllAttempted(lesson);
  const gate = getTranscriptGateState(lesson.level, runtime, allAttempted);

  if (gate === 'locked-until-review') {
    controlsEl.innerHTML = `
      <button type="button" class="secondary-btn listening-transcript-toggle" disabled>Ver transcripción y pronunciación</button>
      <p class="listening-transcript-note">Disponible como repaso después de responder todas las preguntas.</p>
    `;
    bodyEl.hidden = true;
    return;
  }

  if (gate === 'soft-gate') {
    controlsEl.innerHTML = `
      <button type="button" class="secondary-btn listening-transcript-toggle" disabled>Ver transcripción y pronunciación</button>
      <p class="listening-transcript-note">Te recomendamos escuchar el audio primero.
        <button type="button" class="secondary-btn listening-transcript-override-btn">Ver de todas formas</button>
      </p>
    `;
    bodyEl.hidden = true;
    controlsEl
      .querySelector('.listening-transcript-override-btn')
      ?.addEventListener('click', () => {
        runtime.transcriptSoftGateOverride = true;
        runtime.transcriptRevealed = true;
        bodyEl.hidden = false;
        renderListeningTranscriptControls(content, lesson, runtime);
      });
    return;
  }

  controlsEl.innerHTML = `<button type="button" class="secondary-btn listening-transcript-toggle">${runtime.transcriptRevealed ? 'Ocultar transcripción y pronunciación' : 'Ver transcripción y pronunciación'}</button>`;
  bodyEl.hidden = !runtime.transcriptRevealed;
  controlsEl.querySelector('.listening-transcript-toggle')?.addEventListener('click', () => {
    runtime.transcriptRevealed = !runtime.transcriptRevealed;
    bodyEl.hidden = !runtime.transcriptRevealed;
    renderListeningTranscriptControls(content, lesson, runtime);
  });
}

// Listening only ever plays official course audio now (no AI-generated
// fallback - see docs/audio-architecture.md), so this banner always reads
// "Audio oficial"; sourceLabel is still a param in case a future distinct
// official variant (e.g. dialogue performance) wants its own label.
function buildListeningPlayerMarkup({ sourceLabel, title, hasSlowVariant }) {
  return `
    <section class="listening-audio-stage" aria-label="${escapeHtml(title)}">
      <div class="listening-stage-heading">
        <span class="listening-stage-icon" aria-hidden="true">🎧</span>
        <div>
          <div class="listening-source-banner is-official">
            <span class="listening-source-label">${escapeHtml(sourceLabel)}</span>
          </div>
          <h3 class="listening-title">${escapeHtml(title)}</h3>
          <p>Escucha primero sin leer. Puedes volver a reproducir las partes que necesites.</p>
        </div>
      </div>
      <div class="listening-player" data-state="preparing">
        <audio class="listening-audio-el" preload="metadata"></audio>
        <p class="listening-player-status" role="status" aria-live="polite">Preparando audio…</p>
        <div class="listening-player-controls">
          <button type="button" class="listening-ctrl-btn listening-play-btn" aria-label="Reproducir" disabled>▶ Reproducir</button>
          <button type="button" class="listening-ctrl-btn listening-restart-btn" aria-label="Reiniciar" disabled>⏮ Reiniciar</button>
          <button type="button" class="listening-ctrl-btn listening-back5-btn" aria-label="Retroceder 5 segundos" disabled>⏪ 5s</button>
          <button type="button" class="listening-ctrl-btn listening-fwd5-btn" aria-label="Avanzar 5 segundos" disabled>⏩ 5s</button>
          <button type="button" class="listening-ctrl-btn listening-repeat-btn" aria-label="Repetir audio" aria-pressed="false" disabled>🔁 Repetir</button>
          ${hasSlowVariant ? '<button type="button" class="listening-ctrl-btn listening-speed-btn" aria-label="Cambiar a la grabación lenta" disabled>🔊 Audio normal</button>' : ''}
        </div>
        <div class="listening-player-progress-row">
          <span class="listening-time-elapsed" aria-hidden="true">0:00</span>
          <input type="range" class="listening-progress-range" min="0" max="100" value="0" step="1" aria-label="Progreso del audio" disabled>
          <span class="listening-time-duration" aria-hidden="true">0:00</span>
        </div>
        <label class="listening-volume-row">
          <span>Volumen</span>
          <input type="range" class="listening-volume-range" min="0" max="1" step="0.05" value="1" aria-label="Volumen">
        </label>
      </div>
    </section>
  `;
}

// Transcript is its own tab (see listeningModeList/wireListeningModePanel)
// rather than embedded in the player markup, so it can be shown next to
// Diálogo/Dictado/Comprensión instead of always taking up space under the
// audio controls. renderListeningTranscriptControls re-queries these two
// elements from `content` (not scoped to this panel), so it works the same
// whether they're inline or in a separate tab panel - only requirement is
// they exist in the DOM when that function runs, which wireListeningModePanel
// guarantees by rendering this panel first.
//
// "Transcripción" and "Transcripción fonética" used to be two separate tabs;
// they're now one ("Transcripción y pronunciación" - see
// listeningExtraModeList) so pronunciation support sits right under the line
// it belongs to instead of in a disconnected tab. .listening-transcript-body
// is filled by renderListeningTranscriptBodyHtml below, not plain text.
function renderListeningTranscriptPanel() {
  return `
    <div class="listening-transcript">
      <div class="listening-transcript-controls"></div>
      <div class="listening-transcript-body" hidden></div>
    </div>
  `;
}

// One entry per dialogue turn when the lesson has a `dialogue` array
// (today: lessons with extra.listeningType === 'dialogue', e.g. the
// English A1 "Hello!" pilot unit); otherwise falls back to sentence-split
// plain text (reusing Reading's splitReadingSentences) with no per-line
// speaker/translation, since a flat transcript blob carries neither.
function listeningTranscriptLines(lesson, runtime) {
  if (lesson.dialogue?.length) {
    return lesson.dialogue.map((item) => ({
      speaker: item.speaker || '',
      text: item.line || '',
      translation: item.translation || ''
    }));
  }
  const text =
    runtime.transcript ||
    lesson.extra?.mainTranscript ||
    (lesson.extra?.transcriptSegments || []).map((segment) => segment.text || segment).join(' ') ||
    lesson.transcript ||
    '';
  return splitReadingSentences(text).map((sentence) => ({
    speaker: '',
    text: sentence,
    translation: ''
  }));
}

// Matches pre-authored phoneticSupport.segments to the line they belong to
// by substring, so pronunciation shows up right under its line - never
// generates/guesses IPA that isn't already in the lesson's own data.
function findPhoneticSegmentsForLine(phoneticSupport, lineText) {
  if (!phoneticSupport?.segments?.length || !lineText) return [];
  const lower = lineText.toLowerCase();
  return phoneticSupport.segments.filter(
    (seg) => seg.text && lower.includes(String(seg.text).toLowerCase())
  );
}

// Direct mode (L1 === L2, spec §3/§9) never shows a translation - instead,
// when the lesson's own `vocabulary` carries directSupport.simpleDefinition
// (English-only glosses, same shape normalizeVocabularyItem's directSupport
// already uses), a compact glossary substitutes for the hidden L1 line.
function renderListeningDirectGlossaryHtml(lesson) {
  const items = (lesson.vocabulary || []).filter((item) => item.directSupport?.simpleDefinition);
  if (!items.length) return '';
  return `
    <div class="listening-direct-glossary">
      <strong>Key words</strong>
      <ul>
        ${items
          .map(
            (item) =>
              `<li><strong>${escapeHtml(item.word)}</strong>: ${escapeHtml(item.directSupport.simpleDefinition)}</li>`
          )
          .join('')}
      </ul>
    </div>
  `;
}

function renderListeningTranscriptBodyHtml(lesson, runtime) {
  const lines = listeningTranscriptLines(lesson, runtime);
  if (!lines.length) {
    return '<p class="skill-graph-empty">Todavía no hay transcripción disponible para esta lección.</p>';
  }
  const isDirectMode = learningPathState.learningMode === 'direct';
  const phoneticSupport = lesson.extra?.phoneticSupport;
  // phoneticSupport.reviewStatus is set by content authors, never inferred -
  // anything other than an explicit 'verified' is labeled as an approximate
  // aid, never presented as certified IPA (spec: "no inventes IPA").
  const isApproxPronunciation = Boolean(phoneticSupport) && phoneticSupport.reviewStatus !== 'verified';

  const linesHtml = lines
    .map((line, index) => {
      const segments = findPhoneticSegmentsForLine(phoneticSupport, line.text);
      const pronunciationHtml = segments.length
        ? `<p class="listening-transcript-pron" data-line-index="${index}" hidden>${segments
            .map((s) => `<span class="phonetic-ipa">${escapeHtml(s.ipa || '')}</span>`)
            .join(' · ')}${isApproxPronunciation ? ' <span class="listening-pron-approx-tag">Pronunciación aproximada</span>' : ''}</p>`
        : '';
      const l1Html =
        !isDirectMode && line.translation
          ? `<p class="listening-transcript-l1" data-line-index="${index}" hidden>${escapeHtml(line.translation)}</p>`
          : '';
      return `
        <div class="listening-transcript-line">
          <p class="listening-transcript-en">${line.speaker ? `<span class="listening-transcript-speaker">${escapeHtml(line.speaker)}</span> ` : ''}${escapeHtml(line.text)}</p>
          ${l1Html}
          ${pronunciationHtml}
        </div>
      `;
    })
    .join('');

  const hasAnyL1 = !isDirectMode && lines.some((line) => line.translation);
  const directGlossaryHtml = isDirectMode ? renderListeningDirectGlossaryHtml(lesson) : '';
  // Lesson-wide pronunciation guidance (focus note, stressed words,
  // syllabification, difficult sounds) - previously its own "Transcripción
  // fonética" tab, now folded into the bottom of this merged tab, shown
  // together with the per-line IPA behind the same pronunciation toggle.
  return `
    <div class="listening-transcript-lines">${linesHtml}</div>
    <div class="listening-transcript-toggle-row">
      ${hasAnyL1 ? '<button type="button" class="secondary-btn listening-l1-toggle" aria-pressed="false">Mostrar apoyo en español</button>' : ''}
    </div>
    ${directGlossaryHtml}
  `;
}

function renderListeningPronunciationPanel(lesson) {
  const support = lesson.extra?.phoneticSupport;
  if (!support) {
    return `<p class="skill-graph-empty">${listeningUiText('No hay apoyo de pronunciación disponible.', 'Aucune aide à la prononciation n’est disponible.')}</p>`;
  }
  return `
    <section class="listening-pronunciation-panel">
      <h4>${listeningUiText('Pronunciación', 'Prononciation')}</h4>
      ${renderListeningPhoneticGuideHtml(support, { visible: true })}
    </section>
  `;
}

// The lesson-wide portion of extra.phoneticSupport (as opposed to the
// per-line segments matched in renderListeningTranscriptBodyHtml above) -
// hidden/shown by the same "Mostrar/Ocultar pronunciación" toggle.
function renderListeningPhoneticGuideHtml(ps, { visible = false } = {}) {
  const isApprox = ps.reviewStatus !== 'verified';
  const focusWords = (ps.focusWords || []).map(escapeHtml).join(', ');
  const syllabHtml = (ps.syllabification || [])
    .map((s) => `<li>${escapeHtml(s.word)}: <em>${escapeHtml(s.syllables)}</em></li>`)
    .join('');
  return `
    <div class="listening-phonetic-guide"${visible ? '' : ' hidden'}>
      ${isApprox ? '<p class="listening-pron-approx-tag">Pronunciación aproximada, sujeta a revisión.</p>' : ''}
      ${ps.focus ? `<p class="listening-phonetic-focus">${escapeHtml(ps.focus)}</p>` : ''}
      ${focusWords ? `<p><strong>Palabras para practicar:</strong> ${focusWords}</p>` : ''}
      ${(ps.stressedWords || []).length ? `<p><strong>Palabras con acento clave:</strong> ${(ps.stressedWords || []).map(escapeHtml).join(', ')}</p>` : ''}
      ${syllabHtml ? `<ul class="listening-phonetic-syllables">${syllabHtml}</ul>` : ''}
      ${(ps.difficultSounds || []).length ? `<p><strong>Sonidos a practicar:</strong> ${(ps.difficultSounds || []).map(escapeHtml).join(', ')}</p>` : ''}
    </div>
  `;
}

// Global show/hide for every line's L1/pronunciation line at once - both
// toggles are independent and "ocultable" per spec.
function wireListeningTranscriptToggles(panel) {
  const l1Toggle = panel.querySelector('.listening-l1-toggle');
  l1Toggle?.addEventListener('click', () => {
    const next = l1Toggle.getAttribute('aria-pressed') !== 'true';
    l1Toggle.setAttribute('aria-pressed', String(next));
    l1Toggle.textContent = next ? 'Ocultar apoyo en español' : 'Mostrar apoyo en español';
    panel.querySelectorAll('.listening-transcript-l1').forEach((el) => {
      el.hidden = !next;
    });
  });
  const pronToggle = panel.querySelector('.listening-pron-toggle');
  pronToggle?.addEventListener('click', () => {
    const next = pronToggle.getAttribute('aria-pressed') !== 'true';
    pronToggle.setAttribute('aria-pressed', String(next));
    pronToggle.textContent = next ? 'Ocultar pronunciación' : 'Mostrar pronunciación';
    panel.querySelectorAll('.listening-transcript-pron').forEach((el) => {
      el.hidden = !next;
    });
    const guideEl = panel.querySelector('.listening-phonetic-guide');
    if (guideEl) guideEl.hidden = !next;
  });
}

function wireListeningPlayerControls(content, lesson, runtime, meta) {
  const playerEl = content.querySelector('.listening-player');
  const audioEl = content.querySelector('.listening-audio-el');
  const statusEl = content.querySelector('.listening-player-status');
  const playBtn = content.querySelector('.listening-play-btn');
  const restartBtn = content.querySelector('.listening-restart-btn');
  const back5Btn = content.querySelector('.listening-back5-btn');
  const fwd5Btn = content.querySelector('.listening-fwd5-btn');
  const repeatBtn = content.querySelector('.listening-repeat-btn');
  const speedBtn = content.querySelector('.listening-speed-btn');
  const elapsedEl = content.querySelector('.listening-time-elapsed');
  const durationEl = content.querySelector('.listening-time-duration');
  const rangeEl = content.querySelector('.listening-progress-range');
  const volumeEl = content.querySelector('.listening-volume-range');
  if (!audioEl || !playerEl) return;

  // Stashed on runtime, not written straight into the DOM here, because the
  // transcript is now its own tab (merged with pronunciation - see
  // renderListeningTranscriptBodyHtml) - its container may not exist in the
  // DOM yet if that tab isn't the active one, so wireListeningModePanel
  // re-reads runtime.transcript when the student switches to it.
  runtime.transcript = meta.transcript || '';
  renderListeningTranscriptControls(content, lesson, runtime);

  const setState = (state, statusText) => {
    playerEl.dataset.state = state;
    if (statusText && statusEl) statusEl.textContent = statusText;
  };

  const enableControls = () => {
    [playBtn, restartBtn, back5Btn, fwd5Btn, repeatBtn, speedBtn, rangeEl].forEach((el) => {
      if (el) el.disabled = false;
    });
  };

  audioEl.addEventListener('loadstart', () => setState('loading', 'Cargando audio…'));
  audioEl.addEventListener('loadedmetadata', () => {
    if (Number.isFinite(audioEl.duration) && durationEl)
      durationEl.textContent = formatListeningTime(audioEl.duration);
    if (playerEl.dataset.state === 'preparing' || playerEl.dataset.state === 'loading')
      setState('ready', 'Listo para reproducir.');
    enableControls();
  });
  audioEl.addEventListener('timeupdate', () => {
    if (elapsedEl) elapsedEl.textContent = formatListeningTime(audioEl.currentTime);
    if (rangeEl && Number.isFinite(audioEl.duration) && audioEl.duration > 0) {
      rangeEl.value = String(Math.round((audioEl.currentTime / audioEl.duration) * 100));
    }
  });
  audioEl.addEventListener('play', () => {
    setState('playing', 'Reproduciendo…');
    if (playBtn) {
      playBtn.textContent = '⏸ Pausa';
      playBtn.setAttribute('aria-label', 'Pausar');
    }
    if (!runtime.hasPlayedOnce) {
      runtime.hasPlayedOnce = true;
      renderListeningTranscriptControls(content, lesson, runtime);
    }
  });
  audioEl.addEventListener('pause', () => {
    if (playerEl.dataset.state !== 'completed') setState('paused', 'En pausa.');
    if (playBtn) {
      playBtn.textContent = '▶ Reproducir';
      playBtn.setAttribute('aria-label', 'Reproducir');
    }
  });
  audioEl.addEventListener('ended', () => {
    setState('completed', 'Audio completado.');
    if (playBtn) {
      playBtn.textContent = '▶ Reproducir';
      playBtn.setAttribute('aria-label', 'Reproducir de nuevo');
    }
  });
  audioEl.addEventListener('error', () => {
    setState('error', 'No pudimos cargar este audio. Reintentar.');
    [playBtn, restartBtn, back5Btn, fwd5Btn, repeatBtn, speedBtn, rangeEl].forEach((el) => {
      if (el) el.disabled = true;
    });
  });

  playBtn?.addEventListener('click', () => {
    if (audioEl.paused || audioEl.ended)
      audioEl
        .play()
        .catch(() => setState('error', 'No pudimos reproducir este audio. Reintentar.'));
    else audioEl.pause();
  });
  restartBtn?.addEventListener('click', () => {
    audioEl.currentTime = 0;
    if (elapsedEl) elapsedEl.textContent = '0:00';
    if (rangeEl) rangeEl.value = '0';
  });
  back5Btn?.addEventListener('click', () => {
    audioEl.currentTime = Math.max(0, audioEl.currentTime - 5);
  });
  fwd5Btn?.addEventListener('click', () => {
    const max = Number.isFinite(audioEl.duration) ? audioEl.duration : audioEl.currentTime + 5;
    audioEl.currentTime = Math.min(max, audioEl.currentTime + 5);
  });
  repeatBtn?.addEventListener('click', () => {
    audioEl.loop = !audioEl.loop;
    repeatBtn.setAttribute('aria-pressed', String(audioEl.loop));
    repeatBtn.classList.toggle('is-active', audioEl.loop);
  });
  // Only switch between real recorded variants. There is deliberately no
  // playbackRate/TTS fallback when a slow recording does not exist.
  const recordedVariants = [
    { id: 'normal', label: 'Audio normal', url: meta.mainUrl },
    ...(meta.slowUrl ? [{ id: 'slow', label: 'Audio lento', url: meta.slowUrl }] : []),
    ...(meta.verySlowUrl
      ? [{ id: 'verySlow', label: 'Audio muy lento', url: meta.verySlowUrl }]
      : [])
  ];
  runtime.speedTier = recordedVariants.some((item) => item.id === runtime.speedTier)
    ? runtime.speedTier
    : 'normal';
  speedBtn?.addEventListener('click', () => {
    const wasPlaying = !audioEl.paused;
    const currentIndex = recordedVariants.findIndex((item) => item.id === runtime.speedTier);
    const next = recordedVariants[(currentIndex + 1) % recordedVariants.length];
    runtime.speedTier = next.id;
    audioEl.src = next.url;
    audioEl.playbackRate = 1;
    setState('loading', 'Cargando audio…');
    audioEl.load();
    if (wasPlaying)
      audioEl.addEventListener('loadedmetadata', () => audioEl.play().catch(() => {}), {
        once: true
      });
    speedBtn.textContent = `🔊 ${next.label}`;
    speedBtn.setAttribute('aria-label', `${next.label}. Cambiar grabación.`);
  });
  rangeEl?.addEventListener('input', () => {
    if (Number.isFinite(audioEl.duration) && audioEl.duration > 0) {
      audioEl.currentTime = (Number(rangeEl.value) / 100) * audioEl.duration;
    }
  });
  volumeEl?.addEventListener('input', () => {
    audioEl.volume = Number(volumeEl.value);
  });

  audioEl.src = meta.mainUrl;
  audioEl.load();
}

function listeningTutorButtonsHtml(lesson, ctx) {
  const { transcript = '', vocabulary = '', currentQuestion = '', selectedAnswer = '' } = ctx;
  const esc = (value) => escapeHtml(value || '');
  const firstWord = (lesson.vocabulary || [])[0]?.word || '';
  return `
    <button type="button" class="secondary-btn open-tutor-btn" data-support-mode="hint" data-tutor-prompt="Dame una pista para responder la pregunta actual, sin darme la respuesta." data-tutor-transcript="${esc(transcript)}" data-tutor-current-question="${esc(currentQuestion)}">Dame una pista</button>
    <button type="button" class="secondary-btn open-tutor-btn" data-support-mode="explain" data-tutor-prompt="Explícame esta palabra: ${esc(firstWord)}" data-tutor-transcript="${esc(transcript)}" data-tutor-vocabulary="${esc(vocabulary)}">Explícame esta palabra</button>
    <button type="button" class="secondary-btn open-tutor-btn" data-support-mode="explain" data-tutor-prompt="Repite la idea principal del audio en frases más simples." data-tutor-transcript="${esc(transcript)}">Repite la idea principal</button>
    <button type="button" class="secondary-btn open-tutor-btn" data-support-mode="practice" data-tutor-prompt="Crea otra pregunta de comprensión sobre este audio." data-tutor-transcript="${esc(transcript)}">Crea otra pregunta</button>
    <button type="button" class="secondary-btn open-tutor-btn" data-support-mode="practice" data-tutor-prompt="Ayúdame a practicar este vocabulario." data-tutor-vocabulary="${esc(vocabulary)}">Practicar vocabulario</button>
    <button type="button" class="secondary-btn open-tutor-btn" data-support-mode="explain" data-tutor-prompt="Explícame por qué mi respuesta está mal." data-tutor-transcript="${esc(transcript)}" data-tutor-current-question="${esc(currentQuestion)}" data-tutor-selected-answer="${esc(selectedAnswer)}">Explícame por qué mi respuesta está mal</button>
  `;
}

async function completeListeningLesson(lesson, content) {
  if (lesson.locked) {
    handleHomeAction('upgrade');
    return;
  }
  const btn = content.querySelector('.listening-complete-btn');
  const { allAttempted } = getExerciseProgress(lesson);
  if (!allAttempted) {
    content
      .querySelector('.listening-questions')
      ?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    showHomeToast('Responde las preguntas de comprensión para poder completar esta actividad.');
    return;
  }
  if (!authStatus.session?.access_token) {
    setAuthMessage('Crea tu cuenta gratis para guardar el progreso de Listening.');
    openModal('signup');
    return;
  }
  if (btn) {
    btn.disabled = true;
    btn.textContent = 'Guardando...';
  }

  const recordedResults = learningPathState.exerciseResults[lesson.slug] || {};
  const answers = Object.entries(recordedResults).map(([index, result]) => {
    const exerciseId = lesson.exercises?.[Number(index)]?.id;
    return exerciseId
      ? { exerciseId, selectedOptionId: result.selectedOption, practiced: result.practiced }
      : {
          index: Number(index),
          selectedOption: result.selectedOption,
          practiced: result.practiced
        };
  });

  try {
    const response = await fetch(`${backendBaseUrl}/api/lessons/${lesson.slug}/complete`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...authHeaders() },
      body: JSON.stringify({ answers })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok)
      throw new Error(data.error || 'No se pudo completar la actividad de Listening.');

    lesson.completed = true;
    updateProgressDisplay(data, true);
    renderSkillCards();

    const gamResult = window.AndergoGamification?.recordLessonCompletion({
      slug: lesson.slug,
      language: learningPathState.language,
      ...getLessonGamificationContext(lesson),
      score: data.score ?? 100,
      xpReward: lesson.xpReward || 20
    });
    window.AndergoGamification?.syncFromServer(data);
    if (data.newBadges?.length)
      data.newBadges.forEach((badge) =>
        showCelebration(`🏅 ¡Insignia desbloqueada! ${badge.label}`)
      );
    else if (gamResult?.newBadges?.length)
      gamResult.newBadges.forEach((badge) =>
        showCelebration(`🏅 ¡Insignia desbloqueada! ${badge.label}`)
      );
    if (data.leveledUp) showCelebration(`🎉 ¡Subiste a nivel ${data.level}!`);

    showHomeToast(
      `Actividad de Listening completada. +${data.earnedXp || lesson.xpReward || 20} XP`
    );
    celebrateActivityCompletion();
    if (btn) {
      btn.disabled = true;
      btn.textContent = 'Completada';
    }
  } catch (error) {
    console.error('Could not complete listening lesson', error);
    showHomeToast(error.message || 'No se pudo completar la actividad de Listening.');
    if (btn) {
      btn.disabled = false;
      btn.textContent = 'Completar';
    }
  }
}

function computeListeningTutorQuestionContext(lesson) {
  const results = learningPathState.exerciseResults[lesson.slug] || {};
  const exercises = (lesson.exercises || []).filter((item) => item.type === 'mcq');
  const nextUnanswered = exercises.find((_, idx) => !results[idx]);
  const answeredIndexes = Object.keys(results)
    .map(Number)
    .sort((a, b) => b - a);
  const lastIndex = answeredIndexes[0];
  const lastAnswered = lastIndex !== undefined ? exercises[lastIndex] : null;
  const lastResult = lastIndex !== undefined ? results[lastIndex] : null;
  return {
    currentQuestion: nextUnanswered?.prompt || lastAnswered?.prompt || '',
    selectedAnswer: lastResult ? String(lastResult.selectedOption) : ''
  };
}

// ---------------------------------------------------------------------
// Rich Listening extra modes (Dictado / Transcripción fonética /
// Diálogo-Role-play) - additive, only rendered when the lesson carries
// `extra`/`dictation` data (currently Español A1 only; see
// scripts/content/spanish-a1-units.js and
// supabase/migrations/202607220001_rich_listening_content.sql). English
// A1/French A1 lessons have no `extra`, so renderListeningExtraModesHtml
// returns '' for them and nothing else in this section runs - zero
// behavior change for existing languages.
// ---------------------------------------------------------------------

// Despite the name (kept to avoid a wider rename across every call site),
// this is no longer just "extra" content - Transcripción and Comprensión
// are always present, so every Listening lesson gets at least a 2-tab bar
// below the always-visible player; Diálogo/Dictado/Transcripción fonética
// join it only for lessons that actually have that content (today: the
// Spanish A1 catalog).
// "Transcripción" and "Transcripción fonética" are a single tab
// ("Transcripción y pronunciación") - see renderListeningTranscriptBodyHtml,
// which shows pronunciation support inline under each line instead of in a
// disconnected tab. Dictado and Comprensión stay separate on purpose: one is
// a write-what-you-hear exercise, the other is a scored comprehension check.
// Diálogos is Speaking's tab (renderSpeakingModeTabsHtml) only - Listening
// never shows it, even for lessons authored with listeningType: 'dialogue'.
function listeningExtraModeList(lesson) {
  const modes = [{ id: 'story', label: listeningUiText('Historia', 'Histoire') }];
  if (lesson.dictation?.segments?.length)
    modes.push({ id: 'dictation', label: listeningUiText('Dictado', 'Dictée') });
  modes.push({ id: 'transcript', label: listeningUiText('Transcripción', 'Transcription') });
  if (lesson.extra?.phoneticSupport)
    modes.push({ id: 'pronunciation', label: listeningUiText('Pronunciación', 'Prononciation') });
  modes.push({ id: 'comprehension', label: listeningUiText('Comprensión', 'Compréhension') });
  return modes;
}

// True when a lesson has at least one of the rich Dictado/Transcripción-y-
// pronunciación/Comprensión tabs worth showing, independent of whether
// official audio exists yet. Lets renderListeningUnavailable below show
// those tabs under the honest "no audio yet" status card instead of hiding
// the whole unit behind an audio file that hasn't been published - never
// fabricates a player, never auto-calls a TTS provider, just stops blocking
// read/write content that doesn't itself need audio to work (dictation
// grading, comprehension questions, the transcript). Diálogos is
// deliberately excluded - it's Speaking's tab only, never Listening's.
function listeningHasRichExtras(lesson) {
  return Boolean(
    lesson.extra?.mainTranscript ||
      lesson.dictation?.segments?.length ||
      lesson.extra?.phoneticSupport ||
      lesson.extra?.listeningComprehension?.questions?.length
  );
}

function renderListeningExtraModesHtml(lesson, runtime) {
  const modes = listeningExtraModeList(lesson);
  if (!modes.length) return '';
  if (!runtime.extraMode || !modes.some((m) => m.id === runtime.extraMode)) {
    runtime.extraMode = modes[0].id;
  }
  const tabsHtml = modes
    .map(
      (m) =>
        `<button type="button" class="listening-mode-tab${m.id === runtime.extraMode ? ' is-active' : ''}" data-mode="${m.id}" aria-pressed="${m.id === runtime.extraMode}">${escapeHtml(m.label)}</button>`
    )
    .join('');
  return `
    <div class="listening-extra-modes">
      <div class="listening-mode-tabs" role="tablist">${tabsHtml}</div>
      <div class="listening-mode-panel"></div>
    </div>
  `;
}

// A dictation segment is only real practice if it has its own audio
// fragment, or real start/end timestamps into the main official track -
// spec §8: never invent timestamps, never fall back to speechSynthesis.
function listeningDictationSegmentHasAudio(segment) {
  return Boolean(
    segment.normalAudioUrl || (Number.isFinite(segment.startTime) && Number.isFinite(segment.endTime))
  );
}

function renderListeningDictationPanel(lesson, runtime) {
  const segments = lesson.dictation?.segments || [];
  if (!segments.length || !runtime.hasOfficialAudio) {
    return `
      <div class="listening-dictation listening-dictation-pending">
        <p class="listening-dictation-pending-message">El dictado estará disponible cuando se publique el audio oficial de esta lección.</p>
      </div>
    `;
  }
  runtime.dictationAnswers = runtime.dictationAnswers || {};
  const rowsHtml = segments
    .map((segment, index) => {
      const value = escapeHtml(runtime.dictationAnswers[segment.id] || '');
      const result = runtime.dictationResults?.segments?.find((r) => String(r.segmentId) === String(segment.id));
      const feedback = result
        ? `<span class="dictation-segment-feedback">${result.correctWords}/${result.totalWords} palabras correctas</span>`
        : '';
      return `
        <div class="dictation-segment" data-segment-id="${escapeHtml(String(segment.id))}">
          <span class="dictation-segment-label">${listeningUiText('Frase', 'Phrase')} ${index + 1}</span>
          <textarea class="dictation-segment-input" rows="2" placeholder="${listeningUiText('Escribe lo que escuchas...', 'Écrivez ce que vous entendez...')}">${value}</textarea>
          ${feedback}
        </div>
      `;
    })
    .join('');
  const overall = runtime.dictationResults
    ? `<p class="dictation-overall-result">Resultado: ${runtime.dictationResults.correctWords}/${runtime.dictationResults.totalWords} palabras correctas (${runtime.dictationResults.percentage}%). Intento ${runtime.dictationResults.attemptNumber}.</p>`
    : '';
  return `
    <div class="listening-dictation">
      <p class="listening-dictation-intro">Escucha cada frase (usa los controles de velocidad si lo necesitas) y escribe exactamente lo que escuchas.</p>
      ${rowsHtml}
      ${overall}
      <button type="button" class="secondary-btn listening-dictation-check-btn">${listeningUiText('Revisar dictado', 'Vérifier la dictée')}</button>
    </div>
  `;
}

async function submitDictationCheck(lesson, runtime, content) {
  const segments = lesson.dictation?.segments || [];
  const attempts = segments.map((segment) => ({
    segmentId: segment.id,
    text: runtime.dictationAnswers?.[segment.id] || ''
  }));
  runtime.dictationAttemptNumber = (runtime.dictationAttemptNumber || 0) + 1;
  try {
    const response = await fetch(`${backendBaseUrl}/api/lessons/${lesson.slug}/dictation/check`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...authHeaders() },
      body: JSON.stringify({ attempts, attemptNumber: runtime.dictationAttemptNumber })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || 'No se pudo revisar el dictado.');
    runtime.dictationResults = data;
    wireListeningModePanel(content, lesson, runtime);
  } catch (error) {
    showHomeToast(error.message || 'No se pudo revisar el dictado.');
  }
}

function renderListeningStoryPanel(lesson, runtime) {
  const text = runtime.transcript || lesson.extra?.mainTranscript || lesson.transcript || '';
  return `
    <article class="listening-story">
      <div class="listening-story-heading">
        <div>
          <span class="listening-story-kicker">${listeningUiText('Apoyo de escucha', "Aide à l'écoute")}</span>
          <h4>${listeningUiText('Texto de la historia', "Texte de l'histoire")}</h4>
          <p>${listeningUiText('Intenta comprender el audio antes de desplegar el texto.', "Essayez de comprendre l'audio avant d'afficher le texte.")}</p>
        </div>
        <button type="button" class="secondary-btn listening-story-toggle" aria-expanded="${runtime.storyRevealed}">
          ${runtime.storyRevealed ? listeningUiText('Hide Text', 'Masquer le texte') : listeningUiText('Show Text', 'Afficher le texte')}
        </button>
      </div>
      <div class="listening-story-body" ${runtime.storyRevealed ? '' : 'hidden'}>
        <p>${escapeHtml(text)}</p>
      </div>
    </article>
  `;
}

function renderListeningConnectedToolsHtml(lesson, runtime) {
  const hasComprehension = Boolean(
    lesson.extra?.listeningComprehension?.questions?.length || lesson.exercises?.length
  );
  return `
    <div class="listening-connected-tools">
      ${renderListeningStoryPanel(lesson, runtime)}
      <button type="button" class="listening-vocabulary-link" data-listening-open-vocabulary>
        <span class="listening-vocabulary-link-icon" aria-hidden="true">🧠</span>
        <span>
          <strong>Vocabulary</strong>
          <small>Estudia las palabras de esta unidad en su actividad completa.</small>
        </span>
        <span aria-hidden="true">→</span>
      </button>
    </div>
    ${
      hasComprehension
        ? `<section class="listening-comprehension-direct">
            <div class="listening-section-heading">
              <span>Comprueba lo que entendiste</span>
              <h3>Comprensión auditiva</h3>
            </div>
            <div class="listening-mode-panel">${renderListeningComprehensionPanel(lesson)}</div>
          </section>`
        : ''
    }
  `;
}

function wireListeningConnectedTools(content, lesson, runtime) {
  const storyButton = content.querySelector('.listening-story-toggle');
  const storyBody = content.querySelector('.listening-story-body');
  storyButton?.addEventListener('click', () => {
    runtime.storyRevealed = !runtime.storyRevealed;
    if (storyBody) storyBody.hidden = !runtime.storyRevealed;
    storyButton.setAttribute('aria-expanded', String(runtime.storyRevealed));
    storyButton.textContent = runtime.storyRevealed
      ? listeningUiText('Hide Text', 'Masquer le texte')
      : listeningUiText('Show Text', 'Afficher le texte');
  });

  content.querySelector('[data-listening-open-vocabulary]')?.addEventListener('click', () => {
    const vocabularyLesson = getUnitActivities(lesson.unitId).find((item) => item.skill === 'vocabulary');
    if (vocabularyLesson) {
      openUnitSequenceStep('vocabulary', vocabularyLesson.slug);
      return;
    }
    showHomeToast('La actividad de Vocabulary de esta unidad estará disponible próximamente.');
  });
}

function wireListeningModePanel(content, lesson, runtime) {
  const panel = content.querySelector('.listening-mode-panel');
  if (!panel) return;
  if (runtime.extraMode === 'story')
    panel.innerHTML = renderListeningStoryPanel(lesson, runtime);
  else if (runtime.extraMode === 'dictation') panel.innerHTML = renderListeningDictationPanel(lesson, runtime);
  else if (runtime.extraMode === 'transcript') panel.innerHTML = renderListeningTranscriptPanel();
  else if (runtime.extraMode === 'pronunciation') panel.innerHTML = renderListeningPronunciationPanel(lesson);
  else if (runtime.extraMode === 'comprehension') panel.innerHTML = renderListeningComprehensionPanel(lesson);

  if (runtime.extraMode === 'transcript') {
    const bodyEl = panel.querySelector('.listening-transcript-body');
    if (bodyEl) bodyEl.innerHTML = renderListeningTranscriptBodyHtml(lesson, runtime);
    renderListeningTranscriptControls(content, lesson, runtime);
    wireListeningTranscriptToggles(panel);
  }

  panel.querySelector('.listening-story-toggle')?.addEventListener('click', () => {
    runtime.storyRevealed = !runtime.storyRevealed;
    wireListeningModePanel(content, lesson, runtime);
  });

  panel.querySelectorAll('.dictation-segment-input').forEach((el) => {
    el.addEventListener('input', () => {
      const segmentId = el.closest('.dictation-segment')?.dataset.segmentId;
      if (segmentId) {
        runtime.dictationAnswers = runtime.dictationAnswers || {};
        runtime.dictationAnswers[segmentId] = el.value;
      }
    });
  });
  panel.querySelector('.listening-dictation-check-btn')?.addEventListener('click', () => {
    submitDictationCheck(lesson, runtime, content);
  });
}

function wireListeningExtraModes(content, lesson, runtime) {
  const tabsWrap = content.querySelector('.listening-mode-tabs');
  if (!tabsWrap) return;
  tabsWrap.querySelectorAll('.listening-mode-tab').forEach((btn) => {
    btn.addEventListener('click', () => {
      runtime.extraMode = btn.dataset.mode;
      tabsWrap.querySelectorAll('.listening-mode-tab').forEach((b) => {
        b.classList.toggle('is-active', b === btn);
        b.setAttribute('aria-pressed', String(b === btn));
      });
      wireListeningModePanel(content, lesson, runtime);
    });
  });
  wireListeningModePanel(content, lesson, runtime);
}

function renderListeningOfficial(content, lesson, runtime, audio, status = 'official') {
  runtime.hasOfficialAudio = true;
  // Scored Comprehension (extra.listeningComprehension) replaces the old
  // "Completar" button the same way Grammar's scored test replaced its
  // old completion flow - submitting the test inside the Comprensión tab
  // already calls the shared /complete endpoint, so the nav-row button
  // would just be a confusing second path to the same action. Lessons
  // without that question bank keep today's button/gating unchanged.
  const hasScoredComprehension = Boolean(lesson.extra?.listeningComprehension?.questions?.length);
  const { allAttempted } = getExerciseProgress(lesson);
  const objective = lesson.mission || lesson.intro || lesson.description || '';
  const durationLabel = audio.duration ? `${Math.round(audio.duration)}s` : 'No especificada';
  const tutorCtx = computeListeningTutorQuestionContext(lesson);

  content.innerHTML = `
    <div class="listening-meta-row">
      <span class="listening-meta-item">Objetivo: ${escapeHtml(objective)}</span>
      <span class="listening-meta-item">Duración: ${escapeHtml(durationLabel)}</span>
    </div>
    ${buildListeningPlayerMarkup({
      sourceLabel: 'Audio oficial',
      title: lesson.title,
      hasSlowVariant: Boolean(audio.slowAudioUrl || audio.verySlowAudioUrl)
    })}
    ${renderListeningConnectedToolsHtml(lesson, runtime)}
    <div class="skill-view-tutor-cta">
      ${listeningTutorButtonsHtml(lesson, { transcript: audio.transcript, vocabulary: (lesson.vocabulary || []).map((v) => v.word).join(', '), ...tutorCtx })}
    </div>
    ${
      hasScoredComprehension
        ? ''
        : `<div class="listening-nav-row">
            <button type="button" class="primary-btn listening-complete-btn" ${!allAttempted || lesson.completed ? 'disabled' : ''}>${lesson.completed ? 'Completada' : 'Completar'}</button>
          </div>`
    }
  `;

  wireListeningPlayerControls(content, lesson, runtime, {
    mainUrl: audio.audioUrl,
    slowUrl: audio.slowAudioUrl,
    verySlowUrl: audio.verySlowAudioUrl,
    transcript: audio.transcript || lesson.extra?.mainTranscript
  });
  wireListeningConnectedTools(content, lesson, runtime);
  content
    .querySelector('.listening-complete-btn')
    ?.addEventListener('click', () => completeListeningLesson(lesson, content));
}

function updateListeningOfficialQuestions(content, lesson, runtime) {
  const questionsWrap = content.querySelector('.listening-questions');
  const progressBar = content.querySelector('.listening-progress-bar div');
  const progressWrap = content.querySelector('.listening-progress-bar');
  if (!questionsWrap) return;
  const { total, attempted, allAttempted } = getExerciseProgress(lesson);
  const exercises = (lesson.exercises || []).filter((item) => item.type === 'mcq');
  questionsWrap.innerHTML =
    exercises.map((item, index) => renderLessonExercise(item, index, lesson)).join('') ||
    '<p class="skill-graph-empty">No hay preguntas de comprensión para esta lección.</p>';
  const pct = total ? Math.round((attempted / total) * 100) : 0;
  if (progressBar) progressBar.style.width = `${pct}%`;
  if (progressWrap) progressWrap.setAttribute('aria-valuenow', String(pct));
  const completeBtn = content.querySelector('.listening-complete-btn');
  if (completeBtn && !lesson.completed) completeBtn.disabled = !allAttempted;
  renderListeningTranscriptControls(content, lesson, runtime);
}

// Compact, non-blocking notice used instead of the full-size
// .listening-status-card whenever the lesson already has real content to
// show (Diálogo/Dictado/Transcripción y pronunciación/Comprensión) - see
// listeningHasRichExtras. The big centered card is accurate and fine when
// there's truly nothing else on the page (hasExtras === false); once a
// lesson has real work in it, a giant "no disponible" card misrepresents
// how much of the lesson is actually ready, so this shrinks it to a single
// inline banner that reads as "the recording is still coming" rather than
// "this lesson isn't ready" - the recorded audio is the only missing piece.
function renderListeningAudioPendingBannerHtml({ icon, title, detail, actionsHtml }) {
  return `
    <div class="listening-audio-pending-banner">
      <span class="listening-audio-pending-icon" aria-hidden="true">${icon}</span>
      <div class="listening-audio-pending-body">
        <p class="listening-audio-pending-title">${title}</p>
        <p class="listening-audio-pending-detail">${detail}</p>
        ${actionsHtml || ''}
        <p class="listening-status-error" hidden></p>
      </div>
    </div>
  `;
}

// Listening's only "no audio yet" state - no device voice, no AI-generated
// practice, no auto-play, no unnecessary retry button (nothing changes here
// without a real upload + lesson_audio row, so "reintentar" would just be
// misleading). Other tabs (Dictado/Transcripción y pronunciación/
// Comprensión) stay available below when the lesson already has that content.
function renderListeningUnavailable(content, lesson, runtime) {
  runtime.hasOfficialAudio = false;
  const hasExtras = listeningHasRichExtras(lesson);

  content.innerHTML = hasExtras
    ? renderListeningAudioPendingBannerHtml({
        icon: '🎧',
        title:
          learningPathState.language === 'french'
            ? 'Audio officiel bientôt disponible'
            : 'Audio oficial no disponible todavía.',
        detail:
          'El audio todavía no está publicado. Puedes revisar el texto o continuar con Vocabulary y comprensión.',
        actionsHtml: ''
      }) + renderListeningConnectedToolsHtml(lesson, runtime)
    : `
      <div class="listening-status-card">
        <div class="listening-status-icon" aria-hidden="true">🎧</div>
        <p class="listening-status-title">Audio oficial no disponible todavía.</p>
      </div>
    `;

  if (hasExtras) wireListeningConnectedTools(content, lesson, runtime);
}

function renderListeningError(content, lesson, section, message) {
  content.innerHTML = `
    <div class="listening-status-card">
      <div class="listening-status-icon" aria-hidden="true">⚠️</div>
      <p class="listening-status-title">No pudimos cargar este audio. Reintentar.</p>
      <p class="listening-status-detail">${escapeHtml(message || '')}</p>
      <button type="button" class="secondary-btn listening-retry-btn">Reintentar</button>
    </div>
  `;
  content.querySelector('.listening-retry-btn')?.addEventListener('click', () => {
    listeningAudioStatusCache.delete(listeningStatusCacheKey(lesson));
    content.dataset.listeningReady = 'false';
    renderListeningView(section, lesson);
  });
}

function renderListeningResolved(content, lesson, runtime, statusData, section) {
  if ((statusData.status === 'official' || statusData.status === 'partial') && statusData.audio) {
    renderListeningOfficial(content, lesson, runtime, statusData.audio, statusData.status);
    return;
  }
  if (statusData.status === 'error') {
    renderListeningError(content, lesson, section, statusData.error);
    return;
  }
  renderListeningUnavailable(content, lesson, runtime);
}

function renderListeningView(section, lesson) {
  const content = section.querySelector('.skill-view-content');
  if (!content) return;
  const runtime = getListeningRuntime(lesson);
  const key = listeningStatusCacheKey(lesson);

  // Only tear down/rebuild the whole subtree (which recreates the <audio>
  // element) the first time this lesson+language+level combination is
  // shown - later re-renders triggered by answering an official
  // comprehension question just refresh the questions/progress area in
  // place (updateListeningOfficialQuestions), so playback position survives.
  if (content.dataset.listeningKey === key && content.dataset.listeningReady === 'true') {
    updateListeningOfficialQuestions(content, lesson, runtime);
    return;
  }

  content.dataset.listeningKey = key;
  content.dataset.listeningReady = 'false';
  content.innerHTML = '<p class="skill-graph-empty">Buscando audio de Listening…</p>';

  fetchListeningAudioStatus(lesson).then((statusData) => {
    if (content.dataset.listeningKey !== key) return; // navigated away meanwhile
    content.dataset.listeningReady = 'true';
    renderListeningResolved(content, lesson, runtime, statusData, section);
  });
}

// ---------------------------------------------------------------------
// Global Tutor IA: floating button + slide-in drawer, reachable from every
// view without losing whatever skill/lesson was active. Shares the same
// /api/ai/tutor call and connection-status rules as the full #tutor view
// via sendTutorMessage() below (extracted from the .tutor-chat-btn handler).
// ---------------------------------------------------------------------

let tutorDrawerReturnFocus = null;
let tutorDrawerContext = {
  skill: 'speaking',
  lessonTitle: '',
  lessonIntro: '',
  lessonSlug: '',
  supportMode: 'practice',
  currentActivity: '',
  transcript: '',
  vocabulary: '',
  currentQuestion: '',
  selectedAnswer: ''
};

// Minimal Tab-cycling focus trap for the drawer's open state - keeps
// keyboard navigation inside .tutor-drawer-panel while it's open, without
// needing a focus-trap library. Attached in openTutorDrawer, removed in
// closeTutorDrawer so it never runs against a closed/inert drawer.
function tutorDrawerFocusTrapHandler(event) {
  if (event.key !== 'Tab') return;
  const panel = document.querySelector('#tutorDrawer .tutor-drawer-panel');
  if (!panel) return;
  const focusable = panel.querySelectorAll(
    'button:not([disabled]), [href], input:not([disabled]), textarea:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])'
  );
  if (!focusable.length) return;
  const first = focusable[0];
  const last = focusable[focusable.length - 1];
  if (event.shiftKey && document.activeElement === first) {
    event.preventDefault();
    last.focus();
  } else if (!event.shiftKey && document.activeElement === last) {
    event.preventDefault();
    first.focus();
  }
}

// ---------------------------------------------------------------------
// Tutor hands-free voice conversation mode (Premium-only): arms the
// drawer's mic button to listen continuously, auto-sends after a short
// natural pause (see startTutorDictation's continuous/silenceMs
// options below), and automatically resume listening once the tutor's
// spoken reply finishes (see resumeTutorConversationListening, wired from
// sendTutorMessage/requestTutorSpeech). Off by default every time the
// drawer opens - never persisted, so a shared/public device never keeps a
// mic "armed" across sessions.
// ---------------------------------------------------------------------
let tutorConversationMode = false;
const TUTOR_CONVERSATION_SILENCE_MS = 700;

function tutorReplyEndsWithQuestion(text) {
  return /[?？]\s*["'»”’)\]]*\s*$/.test(String(text || '').trim());
}

// When a spoken drawer reply ends with a question, the next student turn is
// ready immediately: the Hablar button enters its active/listening state and
// the microphone starts. This also works outside Premium conversation mode
// after an explicitly played question; only the continuous hands-free loop
// itself remains Premium.
function activateTutorMicAfterQuestion(messageEl) {
  if (!messageEl?.closest?.('#tutorDrawer')) return;
  const drawer = document.getElementById('tutorDrawer');
  if (!drawer?.classList.contains('open') || tutorDictation.status === 'listening') return;
  startTutorDictation('tutorDrawerPrompt', {
    continuous: true,
    silenceMs: TUTOR_CONVERSATION_SILENCE_MS,
    autoSend: true
  });
}

function updateTutorConversationToggleUI() {
  const toggle = document.getElementById('tutorConversationToggle');
  if (!toggle) return;
  const premium = isPremiumUser();
  toggle.classList.toggle('is-active', premium && tutorConversationMode);
  toggle.setAttribute('aria-pressed', String(premium && tutorConversationMode));
  toggle.title = premium
    ? 'Conversar por voz: hablas y el Tutor responde automáticamente.'
    : 'Conversar por voz es una función Premium.';
  const badge = toggle.querySelector('.tutor-conversation-toggle-badge');
  if (badge) badge.hidden = premium;
}

function setTutorConversationMode(enabled) {
  tutorConversationMode = enabled;
  if (!enabled) stopTutorDictation();
  updateTutorConversationToggleUI();
  const note = document.getElementById('tutorDrawerDictateNote');
  if (note) {
    note.textContent = enabled
      ? 'Modo conversación activo: habla y el Tutor te responderá en voz automáticamente. Pulsa "Hablar" para empezar.'
      : 'Tu voz se convierte en texto y no se conserva.';
  }
}

function handleTutorConversationToggleClick() {
  if (!isPremiumUser()) {
    openPaywallModal({
      title: 'Conversar por voz es Premium',
      message:
        'Habla con el Tutor IA y escucha sus respuestas automáticamente, sin escribir. Desbloquea ANDERGO Premium para conversar sin límites.',
      featureLabel: 'modo conversación'
    });
    return;
  }
  setTutorConversationMode(!tutorConversationMode);
}

// Restarts listening once the tutor's spoken reply has finished playing (or
// immediately if there was nothing to play) - only while conversation mode
// is still armed and the drawer is still open, so closing the drawer or
// turning the mode off mid-reply never leaves a stray recognizer running.
function resumeTutorConversationListening() {
  if (!tutorConversationMode) return;
  const drawer = document.getElementById('tutorDrawer');
  if (!drawer || !drawer.classList.contains('open')) return;
  startTutorDictation('tutorDrawerPrompt', {
    continuous: true,
    silenceMs: TUTOR_CONVERSATION_SILENCE_MS,
    autoSend: true
  });
}

function openTutorDrawer(overrides = {}) {
  const drawer = document.getElementById('tutorDrawer');
  if (!drawer) return;
  stopTutorDictation();
  setTutorConversationMode(false);
  tutorDrawerContext = { ...tutorDrawerContext, ...overrides };
  tutorDrawerReturnFocus = document.activeElement;

  drawer.classList.add('open');
  drawer.setAttribute('aria-hidden', 'false');
  drawer.removeAttribute('inert');
  document.body.classList.add('modal-open');
  document.addEventListener('keydown', tutorDrawerFocusTrapHandler);
  refreshLanguagePairChrome();

  const skillEl = drawer.querySelector('[data-drawer-context="skill"]');
  const levelEl = drawer.querySelector('[data-drawer-context="level"]');
  if (skillEl)
    skillEl.textContent = getSkillLabel(tutorDrawerContext.skill);
  if (levelEl) levelEl.textContent = learningPathState.level;

  const autoplayToggle = document.getElementById('tutorAutoplayToggle');
  if (autoplayToggle) autoplayToggle.checked = getTutorAutoplayPref();
  updateTutorConversationToggleUI();

  const prompt = document.getElementById('tutorDrawerPrompt');
  if (prompt) prompt.value = overrides.prefill || '';
  checkTutorConnection('tutorDrawerConnectionStatus');
  (prompt || drawer.querySelector('.close-modal'))?.focus();
}

function closeTutorDrawer() {
  const drawer = document.getElementById('tutorDrawer');
  if (!drawer || !drawer.classList.contains('open')) return;
  setTutorConversationMode(false);
  stopTutorDictation();
  stopAllTutorAudio();
  drawer.classList.remove('open');
  drawer.setAttribute('aria-hidden', 'true');
  drawer.setAttribute('inert', '');
  document.body.classList.remove('modal-open');
  document.removeEventListener('keydown', tutorDrawerFocusTrapHandler);
  (tutorDrawerReturnFocus || document.getElementById('tutorFab'))?.focus();
  tutorDrawerReturnFocus = null;
}

// Shared core behind both the full #tutor view's chat and the drawer's chat -
// same request contract (§5: bridgeLanguage/targetLanguage/level/skill/
// lessonSlug/lessonTitle/currentActivity/userMessage/supportMode), same
// "never claim Conectado without a real response" rule. conversationEl/
// thinkingEl/connectionStatusEl/promptEl/sendBtn may be null (appendTutorMessage
// and friends are already null-safe) for inline callers that don't have a
// chat log of their own (e.g. the Writing view's review buttons).
async function sendTutorMessage({
  conversationEl,
  thinkingEl,
  connectionStatusEl,
  promptEl,
  sendBtn,
  skill,
  level,
  language,
  bridgeLanguage,
  lessonTitle,
  lessonIntro,
  lessonSlug,
  currentActivity,
  supportMode,
  selectedSuggestion,
  fallbackPrompt,
  transcript,
  vocabulary,
  currentQuestion,
  selectedAnswer
}) {
  // Guards against a second click/Enter firing before the first request's
  // `sendBtn.disabled = true` (set a few lines below) has taken effect, and
  // against any caller triggering this twice in a row for the same button -
  // the isSubmitting state (spec §6).
  if (sendBtn?.disabled) return null;

  // Manual send while the mic is still listening for this same textarea
  // (spec: "el usuario debe poder enviar manualmente antes de que terminen
  // los dos segundos") - grabs whatever's in the textarea right now (already
  // live-updated with interim results) and stops the recognizer, marking
  // its 'end' handler to skip both the textarea-overwrite and its own
  // auto-send click, so this manual send is never duplicated.
  if (promptEl && tutorDictation.status === 'listening' && tutorDictation.textareaId === promptEl.id) {
    tutorDictationManualSendSuppressed = true;
    stopDictationRecognizer();
  }
  // Also covers a manual click landing during the post-dictation "se
  // enviará automáticamente" editable window (dictation already ended, so
  // the branch above doesn't apply) - cancels the pending auto-send so it
  // can never fire a second time after this manual send.
  clearTutorAutoSendTimer();

  const customPrompt = promptEl?.value.trim() || '';
  const finalPrompt =
    customPrompt || selectedSuggestion || fallbackPrompt || 'Quiero practicar esta habilidad.';
  if (!finalPrompt) return null;
  tutorLastAutoSentTranscript = customPrompt;

  if (conversationEl) appendTutorMessage(conversationEl, 'user', finalPrompt);
  if (promptEl) promptEl.value = '';
  if (thinkingEl) thinkingEl.hidden = false;
  if (connectionStatusEl) connectionStatusEl.textContent = 'Comprobando conexión…';
  if (sendBtn) sendBtn.disabled = true;

  // Set when the Tutor's monthly free-query cap has been hit (see
  // lib/usageLimitService.js) - keeps the send button disabled past this
  // call's `finally`, since retrying won't help until next month/Premium.
  let lockedOut = false;

  try {
    const response = await fetch(`${backendBaseUrl}/api/ai/tutor`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...authHeaders() },
      body: JSON.stringify({
        language,
        targetLanguage: language,
        skill,
        level,
        nativeLanguage: bridgeLanguage,
        bridgeLanguage,
        // 'bilingual' | 'direct' - kept for other backend consumers; no
        // longer affects the Tutor's own reply, which is always L2-only
        // regardless of this value (see lib/aiTutorService.js#buildTutorInput).
        learningMode: learningPathState.learningMode,
        prompt: finalPrompt,
        userMessage: finalPrompt,
        lessonTitle: lessonTitle || '',
        lessonIntro: lessonIntro || '',
        lessonSlug: lessonSlug || '',
        currentActivity: currentActivity || '',
        supportMode: supportMode || 'practice',
        selectedSuggestion: selectedSuggestion || '',
        transcript: transcript || '',
        vocabulary: vocabulary || '',
        currentQuestion: currentQuestion || '',
        selectedAnswer: selectedAnswer || ''
      })
    });
    if (!response.ok) {
      const data = await response.json().catch(() => ({}));
      if (data.limited) {
        lockedOut = true;
        if (conversationEl) appendTutorUsageNotice(conversationEl, data.error, { locked: true });
        if (connectionStatusEl) connectionStatusEl.textContent = 'Límite mensual alcanzado';
        openPaywallModal({
          featureLabel: 'consultas al Tutor IA',
          used: data.limit != null ? data.limit - (data.remaining || 0) : null,
          limit: data.limit
        });
        return null;
      }
      throw new Error(data.error || 'No se pudo conectar con el tutor IA.');
    }

    // Streams the SSE body (`data: {"delta"|"done"|"error", ...}\n\n` frames
    // - see server.js's /api/ai/tutor) and appends each delta into the tutor
    // message bubble as it arrives, so the student sees words as soon as
    // they're generated instead of waiting for the full reply.
    const reader = response.body?.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    let fullText = '';
    let messageEl = null;
    let streamError = null;
    let tutorQueryUsage = null;

    if (reader) {
      let done = false;
      while (!done) {
        const chunk = await reader.read();
        done = chunk.done;
        if (chunk.value) buffer += decoder.decode(chunk.value, { stream: true });

        let frameEnd;
        while ((frameEnd = buffer.indexOf('\n\n')) !== -1) {
          const frame = buffer.slice(0, frameEnd);
          buffer = buffer.slice(frameEnd + 2);
          const line = frame.split('\n').find((l) => l.startsWith('data: '));
          if (!line) continue;

          let payload;
          try {
            payload = JSON.parse(line.slice(6));
          } catch {
            continue;
          }

          if (payload.error) {
            streamError = payload.message || 'No se pudo conectar con el tutor IA.';
          } else if (payload.done) {
            if (payload.usage) tutorQueryUsage = payload.usage;
          } else if (payload.delta) {
            fullText += payload.delta;
            if (thinkingEl) thinkingEl.hidden = true;
            if (conversationEl) {
              if (!messageEl) {
                messageEl = appendTutorMessage(conversationEl, 'tutor', fullText);
                if (messageEl) {
                  messageEl.dataset.ttsLocale = getPronunciationLocale(language);
                  // Position among this conversation's tutor replies so far -
                  // sent to /api/speech/synthesize for logging/context only;
                  // the free-tier voice cap itself is a monthly total now
                  // (lib/usageLimitService.js), not turn-scoped.
                  messageEl.dataset.turnIndex = String(
                    conversationEl.querySelectorAll('.tutor-message--tutor').length
                  );
                }
              } else {
                updateTutorMessageBody(messageEl, conversationEl, fullText);
              }
              if (messageEl) {
                // Cleaned, not raw, and L2-only (the optional L1 support
                // block is never read aloud) - speechSynthesis/the neural
                // TTS provider must never read Markdown syntax (**/#/- ) or
                // native-language support text aloud.
                messageEl.dataset.ttsText = cleanTutorTextForSpeech(sanitizeTutorReplyText(fullText));
              }
            }
          }
        }
      }
    }

    // Voice controls (the "Escuchar" button) only appear once the full
    // reply has finished streaming - never mid-stream, so a click can never
    // read a partial/incomplete sentence aloud (spec: "no reproducir
    // fragmentos mientras llega el streaming").
    if (conversationEl && messageEl) renderTutorVoiceControls(messageEl);

    // Keeps the persistent "Te quedan N de 30 consultas" counter in sync
    // with the count this reply just consumed, instead of waiting for the
    // next view-open refetch. The full "has utilizado tus 30 consultas" +
    // Premium lock is shown separately, on the *next* request that actually
    // gets rejected (see the `data.limited` branch above), not here.
    if (tutorQueryUsage) renderTutorUsageCounter(tutorQueryUsage);

    if (streamError && !fullText) throw new Error(streamError);

    if (connectionStatusEl) connectionStatusEl.textContent = 'Conectado';

    // Fire-and-forget: starts the reply's audio as soon as it's ready
    // (§3 of the Tutor voice spec) without delaying sendTutorMessage's own
    // return or re-enabling of sendBtn below. requestTutorSpeech's own
    // NotAllowedError handling covers a browser blocking this autoplay.
    // The Premium hands-free conversation mode (drawer only) always speaks
    // the reply regardless of the general autoplay preference - "conversar"
    // wouldn't be hands-free otherwise - and resumes listening once that
    // reply finishes playing (resumeTutorConversationListening).
    const isDrawerConversation = conversationEl?.id === 'tutorDrawerConversation';
    const shouldForceSpeech = isDrawerConversation && tutorConversationMode;
    if (messageEl && (getTutorAutoplayPref() || shouldForceSpeech) && messageEl.querySelector('.tutor-voice-controls')) {
      requestTutorSpeech(messageEl, {
        auto: true,
        onPlaybackEnd: shouldForceSpeech ? resumeTutorConversationListening : undefined
      });
    } else if (shouldForceSpeech) {
      // No voice controls on this browser (speechSynthesis unsupported) or
      // no messageEl at all - nothing will ever call onPlaybackEnd, so
      // resume listening directly instead of leaving the loop stuck
      // waiting on audio that will never play.
      resumeTutorConversationListening();
    }

    return { reply: fullText };
  } catch (error) {
    if (conversationEl)
      appendTutorMessage(
        conversationEl,
        'tutor',
        error.message || 'No se pudo conectar con el tutor IA.',
        { isError: true }
      );
    if (connectionStatusEl) connectionStatusEl.textContent = 'No disponible';
    return null;
  } finally {
    if (thinkingEl) thinkingEl.hidden = true;
    // Stays disabled once the monthly free-query cap is hit - re-enabling
    // it would just let the student hit the same 403 again next click.
    if (sendBtn && !lockedOut) sendBtn.disabled = false;
  }
}

function getLocalFallbackLessons(language, level) {
  const lessons = window.ANDERGO_LANGUAGE_WORLDS?.lessons?.[language] || [];
  return lessons
    .filter((lesson) => lesson.level === level)
    .map((lesson) => ({
      ...lesson,
      isFree: lesson.accessTier ? lesson.accessTier !== 'premium' : lesson.isFree !== false,
      locked: (lesson.accessTier === 'premium' || lesson.isFree === false) && !lesson.completed,
      completed: Boolean(lesson.completed)
    }));
}

// Unit metadata (id/slug/title/order) is invariant per language+level, so
// it always ships in the static bundle (window.ANDERGO_LANGUAGE_WORLDS.units,
// generated by scripts/sync-worlds-from-seed.js) regardless of whether the
// lessons themselves came from the backend or the local fallback below -
// this is what makes hasUnits() true for English A1 either way.
function getUnitsForLanguageLevel(language, level) {
  const units = window.ANDERGO_LANGUAGE_WORLDS?.units?.[language] || [];
  return units.filter((unit) => unit.level === level).sort((a, b) => a.order - b.order);
}

async function loadUnitVerbProgress() {
  learningPathState.verbProgressByUnit = {};
  if (!authStatus.session?.access_token || !learningPathState.units.length) return;
  try {
    const params = new URLSearchParams({
      language: learningPathState.language,
      level: learningPathState.level
    });
    const response = await authFetch(`${backendBaseUrl}/api/verbs/unit-progress?${params}`);
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || 'Could not load verb progress');
    learningPathState.verbProgressByUnit = (data.progress || []).reduce((map, row) => {
      if (row.unitSlug) map[row.unitSlug] = row;
      return map;
    }, {});
  } catch (error) {
    console.warn('Could not load unit Verb progress', error);
  }
}

window.recordUnitVerbScore = async function recordUnitVerbScore(score) {
  if (!authStatus.session?.access_token || !learningPathState.unitId) return null;
  const response = await authFetch(`${backendBaseUrl}/api/verbs/unit-progress`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      language: learningPathState.language,
      level: learningPathState.level,
      unitSlug: learningPathState.unitId,
      score
    })
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || 'No se pudo guardar el score de Verbos.');
  learningPathState.verbProgressByUnit[learningPathState.unitId] = {
    unitSlug: learningPathState.unitId,
    status: 'completed',
    bestScore: data.bestScore,
    lastScore: data.score,
    attemptsCount: data.attemptsCount
  };
  const unitMetrics = getUnitProgressMetrics(learningPathState.unitId);
  if (unitMetrics.total > 0 && unitMetrics.completedCount === unitMetrics.total) {
    window.AndergoGamification?.recordUnitCompletion(learningPathState.unitId);
  }
  renderLearningPath();
  loadDashboard();
  return data;
};

async function loadLearningPath(options = {}) {
  // Changing language or level always invalidates whatever reading is
  // currently attached to the audio player, even if the user isn't on
  // the Reading view right now - no reading audio should keep playing
  // in the background across a language/level switch.
  readingSpeechPlayer.teardown();
  learningPathState.language = options.language || learningPathState.language;
  learningPathState.level = options.level || learningPathState.level;
  syncLearningMode();
  applyInterfaceLanguage(learningPathState.bridgeLanguage);
  updatePathPairPreview();
  learningPathState.units = getUnitsForLanguageLevel(
    learningPathState.language,
    learningPathState.level
  );

  const graphContainer = document.getElementById('skillGraph');
  if (graphContainer) {
    graphContainer.innerHTML = '<p class="skill-graph-empty">Preparando tu ruta…</p>';
  }

  // Applies options.restoreSlug/options.restoreUnitId (from a hash restored
  // on load, or Back/Forward through history) now that lessons/units for
  // this language+level have actually loaded. Falls back to the original
  // "no auto-selection" behavior - an empty activeSlug is what makes
  // renderLessonWorkspace() show the "continue" card (next recommended
  // lesson) instead of always jumping straight to lessons[0]'s full detail.
  const applyLoadedSelection = () => {
    if (
      options.restoreSlug &&
      learningPathState.lessons.some((item) => item.slug === options.restoreSlug)
    ) {
      setActiveLesson(options.restoreSlug);
      return;
    }
    learningPathState.activeSlug = '';
    learningPathState.unitId =
      options.restoreUnitId &&
      learningPathState.units.some((unit) => unit.id === options.restoreUnitId)
        ? options.restoreUnitId
        : null;
  };

  try {
    const params = new URLSearchParams({
      level: learningPathState.level,
      language: learningPathState.language
    });
    const response = await fetch(`${backendBaseUrl}/api/lessons?${params.toString()}`, {
      headers: authHeaders()
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || 'Could not load lessons');

    learningPathState.lessons = data.lessons?.length
      ? data.lessons
      : getLocalFallbackLessons(learningPathState.language, learningPathState.level);
    await loadUnitVerbProgress();
    applyLoadedSelection();
    renderLearningPath();
  } catch (error) {
    console.warn('Could not load learning path from backend, using local content', error);
    learningPathState.lessons = getLocalFallbackLessons(
      learningPathState.language,
      learningPathState.level
    );
    await loadUnitVerbProgress();
    applyLoadedSelection();
    renderLearningPath();
  }

  // Single choke point for every caller (language/level selects,
  // setTargetLanguage, the hash-restore paths in showView/renderSkillView/
  // bootstrapLearningPath) - updates the hash to the language+level+unit+
  // lesson that actually finished loading, rather than each caller having to
  // remember to do it (and risk using the pre-fetch, stale unitId/activeSlug -
  // see applyLoadedSelection above). No-ops when the current view isn't
  // 'learn' or a skill view (see updateLearnHash's own guard).
  updateLearnHash(getViewFromHash());
}

async function completeActiveLesson() {
  const activeLesson = learningPathState.lessons.find(
    (item) => item.slug === learningPathState.activeSlug
  );
  if (!activeLesson) return;

  if (activeLesson.locked) {
    handleHomeAction('upgrade');
    return;
  }

  const completeButton = document.querySelector('.lesson-complete-btn');

  // "Iniciar práctica" mode: nothing to submit yet - just point the student
  // at the exercises. The button only switches to "Completar" once every
  // exercise has been attempted (see getExerciseProgress / renderLessonWorkspace).
  if (completeButton?.dataset.mode === 'practice') {
    document
      .querySelector('.lesson-exercises')
      ?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    showHomeToast('Responde los ejercicios de la lección para poder completarla.');
    return;
  }

  if (!authStatus.session?.access_token) {
    setAuthMessage('Crea tu cuenta gratis para guardar el progreso de la lección.');
    openModal('signup');
    return;
  }

  if (completeButton) {
    completeButton.disabled = true;
    completeButton.textContent = 'Guardando...';
  }

  const recordedResults = learningPathState.exerciseResults[activeLesson.slug] || {};
  const answers = Object.entries(recordedResults).map(([index, result]) => {
    const exerciseId = activeLesson.exercises?.[Number(index)]?.id;
    return exerciseId
      ? { exerciseId, selectedOptionId: result.selectedOption, practiced: result.practiced }
      : {
          index: Number(index),
          selectedOption: result.selectedOption,
          practiced: result.practiced
        };
  });

  try {
    const response = await fetch(`${backendBaseUrl}/api/lessons/${activeLesson.slug}/complete`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...authHeaders()
      },
      body: JSON.stringify({ answers })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      throw new Error(data.error || 'No se pudo completar la lección.');
    }

    activeLesson.completed = true;
    if (data.bestScore != null) activeLesson.bestScore = data.bestScore;
    else if (data.score != null)
      activeLesson.bestScore = Math.max(Number(activeLesson.bestScore || 0), Number(data.score));
    updateProgressDisplay(data, true);
    renderLearningPath();

    const gamResult = window.AndergoGamification?.recordLessonCompletion({
      slug: activeLesson.slug,
      language: learningPathState.language,
      ...getLessonGamificationContext(activeLesson),
      score: data.score ?? 100,
      xpReward: activeLesson.xpReward || 20
    });
    window.AndergoGamification?.syncFromServer(data);

    if (data.newBadges?.length) {
      data.newBadges.forEach((badge) =>
        showCelebration(`🏅 ¡Insignia desbloqueada! ${badge.label}`)
      );
    } else if (gamResult?.newBadges?.length) {
      gamResult.newBadges.forEach((badge) =>
        showCelebration(`🏅 ¡Insignia desbloqueada! ${badge.label}`)
      );
    }
    if (data.leveledUp) {
      showCelebration(`🎉 ¡Subiste a nivel ${data.level}!`);
    }

    showHomeToast(`Lección completada. +${data.earnedXp || activeLesson.xpReward || 20} XP`);
    celebrateActivityCompletion();
  } catch (error) {
    console.error('Could not complete lesson', error);
    showHomeToast(error.message || 'No se pudo completar la lección.');
    renderLessonWorkspace();
  }
}

refreshLanguagePairChrome();
attachAuthHandlers();
restoreSession();

authTriggers.forEach((trigger) => {
  trigger.addEventListener('click', (event) => {
    event.preventDefault();
    setAuthMessage('');
    openModal(trigger.dataset.panel);
  });
});

authTabs.forEach((tab) => {
  tab.addEventListener('click', () => openModal(tab.dataset.form));
});

logoutButton?.addEventListener('click', openLogoutConfirm);

// The 3 preset cards are quick-start shortcuts into the same real /api/goals
// CRUD system goalsCrudBody uses below - not a separate goal-tracking system.
document.querySelectorAll('#goalsQuickStart .goal-card').forEach((card) => {
  card.querySelector('.goal-select')?.addEventListener('click', async () => {
    if (!authStatus.session?.access_token) {
      setAuthMessage('Crea tu cuenta gratis para guardar tu objetivo.');
      openModal('signup');
      return;
    }
    try {
      await fetch(`${backendBaseUrl}/api/goals`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...authHeaders() },
        body: JSON.stringify({ goalKey: card.dataset.goal || 'daily' })
      });
      showHomeToast('Objetivo creado.');
      await loadDashboard();
    } catch (error) {
      console.warn('Could not create goal', error);
      showHomeToast('No se pudo crear el objetivo. Intenta de nuevo.');
    }
  });
});

document.querySelector('.learn-route-toggle')?.addEventListener('click', () => {
  const graph = document.getElementById('skillGraph');
  showLearnState(graph?.classList.contains('is-drawer-open') ? 'lesson' : 'route');
});

document.addEventListener('click', async (event) => {
  if (event.target.closest('.learn-back-to-route')) {
    learningPathState.activeSlug = '';
    renderLearningPath();
    showLearnState('route');
    return;
  }

  const continueBtn = event.target.closest('.lesson-continue-btn');
  if (continueBtn) {
    openUnitSequenceStep(continueBtn.dataset.lessonSkill, continueBtn.dataset.lessonSlug);
    return;
  }

  const unitActionBtn = event.target.closest('.unit-action-btn');
  if (unitActionBtn) {
    openLesson(unitActionBtn.dataset.lessonSlug);
    return;
  }

  const button = event.target.closest('.skill-tab-button');
  if (!button) return;
  activateSkillTab(button);
});

// Single place that actually switches tabs (.active class + ARIA state) -
// both the click handler above and the arrow-key navigation below call this,
// so the two ways of activating a tab (mouse and keyboard) can never drift
// out of sync with each other.
function activateSkillTab(button, { scroll = true } = {}) {
  const skill = button.dataset.skill;
  const parent = button.closest('.skill-tabs');
  const buttons = parent?.querySelectorAll('.skill-tab-button') || [];
  const panels = parent?.querySelectorAll('.skill-panel') || [];

  buttons.forEach((btn) => {
    const isActive = btn === button;
    btn.classList.toggle('active', isActive);
    btn.setAttribute('aria-selected', String(isActive));
    btn.tabIndex = isActive ? 0 : -1;
  });
  panels.forEach((panel) => {
    panel.classList.toggle('active', panel.dataset.skill === skill);
  });

  if (scroll) parent?.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

// ARIA roles/relationships for every .skill-tabs block on the page (Tutor,
// Verbos - any future one for free) - ids/aria-controls/aria-labelledby are
// generated here rather than hardcoded per instance in index.html, so a new
// .skill-tabs block never needs to remember to wire this up by hand. Runs
// once at load; .active in the markup decides the initial selected tab, same
// source of truth activateSkillTab() uses afterward.
function initSkillTabsAccessibility() {
  document.querySelectorAll('.skill-tabs').forEach((tabs, tabsIndex) => {
    const list = tabs.querySelector('.skill-tab-list');
    if (list) list.setAttribute('role', 'tablist');

    const buttons = tabs.querySelectorAll('.skill-tab-button');
    buttons.forEach((btn, index) => {
      const skill = btn.dataset.skill || String(index);
      const tabId = btn.id || `skill-tab-${tabsIndex}-${skill}`;
      const panel = tabs.querySelector(`.skill-panel[data-skill="${skill}"]`);
      const panelId = panel && (panel.id || `skill-panel-${tabsIndex}-${skill}`);
      btn.id = tabId;
      btn.setAttribute('role', 'tab');
      const isActive = btn.classList.contains('active');
      btn.setAttribute('aria-selected', String(isActive));
      btn.tabIndex = isActive ? 0 : -1;
      if (panel && panelId) {
        panel.id = panelId;
        panel.setAttribute('role', 'tabpanel');
        panel.setAttribute('aria-labelledby', tabId);
        btn.setAttribute('aria-controls', panelId);
      }
    });
  });
}
initSkillTabsAccessibility();

// Left/Right/Home/End on a focused tab moves focus AND activates the target
// tab (standard ARIA tabs pattern) - matches how activateSkillTab() already
// switches on click, so keyboard and mouse users land on the exact same
// state. Delegated on the document (one listener for every .skill-tabs
// block, present or future) rather than one per tablist.
document.addEventListener('keydown', (event) => {
  if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
  const currentTab = event.target.closest('.skill-tab-button');
  if (!currentTab) return;
  const list = currentTab.closest('.skill-tab-list');
  const buttons = Array.from(list?.querySelectorAll('.skill-tab-button') || []);
  if (!buttons.length) return;
  event.preventDefault();

  const currentIndex = buttons.indexOf(currentTab);
  let nextIndex = currentIndex;
  if (event.key === 'ArrowRight') nextIndex = (currentIndex + 1) % buttons.length;
  else if (event.key === 'ArrowLeft') nextIndex = (currentIndex - 1 + buttons.length) % buttons.length;
  else if (event.key === 'Home') nextIndex = 0;
  else if (event.key === 'End') nextIndex = buttons.length - 1;

  const nextButton = buttons[nextIndex];
  activateSkillTab(nextButton, { scroll: false });
  nextButton.focus();
});

const brandLink = document.querySelector('.brand');
brandLink?.addEventListener('click', (event) => {
  if (window.location.pathname === '/' || window.location.pathname === '/index.html') {
    event.preventDefault();
    history.pushState(null, '', '/');
    showView('home');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
});

if (menuToggle && siteMenu) {
  menuToggle.addEventListener('click', () => {
    const isOpen = siteMenu.classList.toggle('is-open');
    menuToggle.setAttribute('aria-expanded', String(isOpen));
  });

  siteMenu.querySelectorAll('a').forEach((link) => {
    link.addEventListener('click', () => {
      siteMenu.classList.remove('is-open');
      menuToggle.setAttribute('aria-expanded', 'false');
    });
  });

  window.addEventListener('resize', () => {
    if (window.innerWidth > 1100) {
      siteMenu.classList.remove('is-open');
      menuToggle.setAttribute('aria-expanded', 'false');
    }
  });
}

// Single-view router: exactly one of these is visible at a time (everything
// else keeps its .compact-hidden-section class). Header, footer and the auth
// modals sit outside this map and are always visible/available.
// The 6 skills each get their own dedicated view (instead of swapping
// content inside #learning-path's small lesson-workspace card) - listed
// once here since several places (router, card click handler, header
// renderer) all need to agree on the same set.
const SKILL_VIEWS = ['listening', 'speaking', 'reading', 'writing', 'grammar', 'vocabulary'];

const VIEW_SECTIONS = {
  // #premium (the Free/Premium plans section) lives at the end of the home
  // view now, not as its own nav destination - see handleHomeAction's
  // 'upgrade' case, which stays on/goes to 'home' and scrolls to it instead
  // of routing to a dedicated 'premium' view.
  home: ['.hero', '#language-picker'],
  learn: ['#language-picker', '#learning-path'],
  progress: ['#progress'],
  achievements: ['#achievements'],
  security: ['#security'],
  goals: ['#goals'],
  tutor: ['#tutor'],
  translator: ['#translator'],
  about: ['#about'],
  verbs: ['#verbs'],
  listening: ['#listening'],
  speaking: ['#speaking'],
  reading: ['#reading'],
  writing: ['#writing'],
  grammar: ['#grammar'],
  vocabulary: ['#vocabulary'],
  'reset-password': ['#resetPasswordSection'],
  'email-confirmed': ['#emailConfirmedSection']
};

// Focus target per view: the one heading a screen reader / keyboard user
// should land on after a hash change, per view. tabindex="-1" on these in
// index.html makes them programmatically focusable without joining the
// normal Tab order.
const VIEW_TITLE_SELECTORS = {
  home: '.hero-content h2',
  learn: '#language-picker h2',
  progress: '#progress h2',
  achievements: '#achievements h2',
  security: '#security h2',
  goals: '#goals h2',
  tutor: '#tutor h2',
  translator: '#translator h2',
  about: '#about h2',
  verbs: '#verbs h2',
  listening: '#listening .level-tab[data-tab="listening"]',
  speaking: '#speaking .level-tab[data-tab="speaking"]',
  reading: '#reading .level-tab[data-tab="reading"]',
  writing: '#writing .level-tab[data-tab="writing"]',
  grammar: '#grammar .level-tab[data-tab="grammar"]',
  vocabulary: '#vocabulary .level-tab[data-tab="vocabulary"]'
};

function getViewFromHash() {
  // Only the first /-separated segment is the view id - 'learn' and skill
  // views can carry /<language>/<level>/<unitId>/<lessonSlug> after it (see
  // updateLearnHash/parseLearnHashState below), which used to make this
  // whole lookup miss (VIEW_SECTIONS['reading/french/A1/...'] is undefined)
  // and silently fall back to 'home'.
  const raw = window.location.hash.replace('#', '').split('/')[0];
  if (!raw) return 'home';
  if (raw.startsWith('language-') || targetLanguageMap[raw]) return 'learn';
  return VIEW_SECTIONS[raw] ? raw : 'home';
}

// Parses the optional /<language>/<level>/<unitId>/<lessonSlug> segments a
// 'learn' or skill-view hash can carry after the view id - e.g.
// #reading/french/A1/french-a1-unit-02/french-a1-unit-02-reading-01, written
// by updateLearnHash() below. Any/all of these can be absent (plain
// #reading, or the legacy #language-french marketing links keep working
// unchanged since they never match VIEW_SECTIONS as a view id here).
function parseLearnHashState() {
  const [, language, level, unitId, lessonSlug] = window.location.hash
    .replace('#', '')
    .split('/');
  return {
    language: language && languageDisplayNames[language] ? language : null,
    level: level || null,
    unitId: unitId || null,
    lessonSlug: lessonSlug || null
  };
}

// Keeps the hash in sync with language/level/unit/lesson for 'learn' and
// skill views, so reload, Back/Forward (via the popstate listener below),
// and sharing the link restore the exact same content instead of always
// landing on whichever unit/lesson happens to load first. Every other view
// keeps its plain #viewId hash untouched.
function updateLearnHash(viewOverride) {
  const view = viewOverride || getViewFromHash();
  if (view !== 'learn' && !SKILL_VIEWS.includes(view)) return;
  const parts = [view, learningPathState.language, learningPathState.level];
  if (learningPathState.unitId) {
    parts.push(learningPathState.unitId);
    if (learningPathState.activeSlug) parts.push(learningPathState.activeSlug);
  }
  const next = `#${parts.join('/')}`;
  if (window.location.hash !== next) history.pushState(null, '', next);
}

function showView(viewId) {
  const resolved = VIEW_SECTIONS[viewId] ? viewId : 'home';
  if (resolved !== 'home') setPricingExpanded(false);

  // Any navigation away from the current view must release the mic and
  // drop any in-progress Speaking recording - a no-op when nothing is active.
  resetSpeakingRecorder();
  stopTutorDictation();
  stopTranslatorDictation();
  // Same rule for reading audio - no view change should leave a reading
  // playing in the background (also a no-op when nothing is attached).
  readingSpeechPlayer.teardown();

  const allViewElements = new Set();
  Object.values(VIEW_SECTIONS)
    .flat()
    .forEach((selector) =>
      document.querySelectorAll(selector).forEach((element) => allViewElements.add(element))
    );
  const activeViewElements = new Set();
  VIEW_SECTIONS[resolved].forEach((selector) =>
    document.querySelectorAll(selector).forEach((element) => activeViewElements.add(element))
  );
  allViewElements.forEach((element) => {
    const active = activeViewElements.has(element);
    element.classList.toggle('compact-hidden-section', !active);
    element.hidden = !active;
    element.setAttribute('aria-hidden', String(!active));
  });

  document.querySelectorAll('.nav-group a[href^="#"]').forEach((link) => {
    const isActive = link.getAttribute('href') === `#${resolved}`;
    link.classList.toggle('active', isActive);
    if (isActive) {
      link.setAttribute('aria-current', 'page');
    } else {
      link.removeAttribute('aria-current');
    }
  });

  // Ruta/Reading/Listening/.../Vocabulary tab strip repeated at the top of
  // #learning-path and each of the 6 skill sections (index.html's
  // .level-tabs) - same active/aria-current toggling as the main nav above.
  document.querySelectorAll('.level-tab[href^="#"]').forEach((link) => {
    const linkView = link.dataset.tab === 'learn' ? 'learn' : link.dataset.tab;
    const isActive = linkView === resolved;
    link.classList.toggle('active', isActive);
    if (isActive) {
      link.setAttribute('aria-current', 'page');
    } else {
      link.removeAttribute('aria-current');
    }
  });
  updateLevelTabLabels();

  // Restores language/level/unit/lesson from the hash for 'learn' and skill
  // views (see updateLearnHash/parseLearnHashState) - only once lessons are
  // already loaded (cold-boot restore is handled separately by
  // renderSkillView's own loading guard and bootstrapLearningPath, since
  // learningPathState.lessons is still empty at that point).
  if ((resolved === 'learn' || SKILL_VIEWS.includes(resolved)) && learningPathState.lessons.length) {
    const hashState = parseLearnHashState();
    const languageChanged = hashState.language && hashState.language !== learningPathState.language;
    const levelChanged = hashState.level && hashState.level !== learningPathState.level;
    if (languageChanged || levelChanged) {
      const nextLanguage = hashState.language || learningPathState.language;
      const pathLanguageSelect = document.getElementById('pathLanguageSelect');
      if (pathLanguageSelect) pathLanguageSelect.value = nextLanguage;
      loadLearningPath({
        language: nextLanguage,
        level: hashState.level || learningPathState.level,
        restoreUnitId: hashState.unitId,
        restoreSlug: hashState.lessonSlug
      }).then(() => {
        if (SKILL_VIEWS.includes(resolved)) renderSkillView(resolved);
        updateLearnHash(resolved);
      });
    } else {
      let changed = false;
      if (
        hashState.lessonSlug &&
        hashState.lessonSlug !== learningPathState.activeSlug &&
        learningPathState.lessons.some((item) => item.slug === hashState.lessonSlug)
      ) {
        setActiveLesson(hashState.lessonSlug);
        changed = true;
      } else if (
        hashState.unitId &&
        hashState.unitId !== learningPathState.unitId &&
        learningPathState.units.some((unit) => unit.id === hashState.unitId)
      ) {
        selectUnit(hashState.unitId, { render: false });
        changed = true;
      }
      if (changed && resolved === 'learn') renderLearningPath();
    }
  }

  if (resolved === 'learn') {
    // Mobile's route drawer is user-driven ("Ver ruta"/"Volver a la ruta") -
    // entering #learn should land on the lesson panel (continue card or the
    // last-opened lesson), not force the drawer open every time.
    showLearnState('lesson');
    const langToken = getLanguageTabFromHash();
    if (langToken) setTargetLanguage(langToken);
  }
  if (resolved === 'tutor') {
    updateAiTutorContext();
    checkTutorConnection();
    refreshTutorUsageCounter();
  }
  if (resolved === 'translator') syncTranslatorLanguagesFromState();
  if (resolved === 'progress' || resolved === 'goals') loadDashboard();
  if (resolved === 'security') loadSecurityStatus();
  if (resolved === 'verbs') {
    window.renderVerbsView?.();
    renderUnitVerbContext();
  }
  if (SKILL_VIEWS.includes(resolved)) renderSkillView(resolved);

  // Normalizes the hash to reflect the state that actually just rendered -
  // covers plain nav-tab clicks (<a href="#reading">, no unit/lesson
  // suffix), which would otherwise "forget" the previously selected
  // unit/lesson in the address bar even though the content itself is still
  // correct. A no-op when nothing changed (updateLearnHash only pushes when
  // the computed hash differs from the current one).
  // Guarded on lessons.length: on a cold load this fires before
  // bootstrapLearningPath has fetched anything, with learningPathState still
  // at its english/A1 defaults - without this guard it would overwrite a
  // deep-linked hash (e.g. #reading/french/A1/...) with those defaults
  // before bootstrapLearningPath's own parseLearnHashState() ever reads it.
  if ((resolved === 'learn' || SKILL_VIEWS.includes(resolved)) && learningPathState.lessons.length) {
    updateLearnHash(resolved);
  }

  // The floating Tutor IA button is redundant on the dedicated Tutor view,
  // and the drawer shouldn't stay open across a navigation - it loses
  // whatever context it had anyway.
  document.getElementById('tutorFab')?.toggleAttribute('hidden', resolved === 'tutor');
  closeTutorDrawer();

  window.scrollTo({ top: 0, behavior: 'auto' });
  document.querySelector(VIEW_TITLE_SELECTORS[resolved])?.focus({ preventScroll: true });
}

window.addEventListener('hashchange', () => {
  showView(getViewFromHash());
  // A plain <a href="#premium"> (nav/footer) fires a real hashchange, unlike
  // handleHomeAction's 'upgrade' case above - #premium resolves to the home
  // view (it's no longer its own VIEW_SECTIONS entry), so land on it too.
  if (window.location.hash === '#premium') {
    window.setTimeout(() => {
      document.getElementById('premium')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 50);
  }
});

// goTo() (handleHomeAction) navigates via history.pushState, which never
// fires 'hashchange' - only a real link click or address-bar edit does.
// Without this, the browser's Back/Forward buttons moved the URL bar but
// left the previous view rendered on screen.
window.addEventListener('popstate', () => showView(getViewFromHash()));

closeModal?.addEventListener('click', closeAuth);
authModal?.addEventListener('click', (event) => {
  if (event.target === authModal) closeAuth();
});

function showHomeToast(message = '') {
  let toast = document.querySelector('.home-toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.className = 'home-toast';
    toast.setAttribute('role', 'status');
    toast.setAttribute('aria-live', 'polite');
    document.body.appendChild(toast);
  }
  toast.textContent = message;
  toast.classList.add('is-visible');
  window.clearTimeout(showHomeToast.timeoutId);
  showHomeToast.timeoutId = window.setTimeout(() => {
    toast.classList.remove('is-visible');
  }, 2600);
}

function showCelebration(message = '') {
  const celebration = document.createElement('div');
  celebration.className = 'celebration-toast';
  celebration.setAttribute('role', 'status');
  celebration.setAttribute('aria-live', 'assertive');
  celebration.textContent = message;
  document.body.appendChild(celebration);

  window.requestAnimationFrame(() => celebration.classList.add('is-visible'));
  window.setTimeout(() => {
    celebration.classList.remove('is-visible');
    window.setTimeout(() => celebration.remove(), 400);
  }, 3200);
}

function showUnitCompletionPanel({ unitId, xpReward = 30 } = {}) {
  const unit = learningPathState.units.find((item) => item.id === unitId);
  if (!unit) return;
  document.querySelector('.unit-completion-overlay')?.remove();
  const nextUnit = learningPathState.units.find((item) => item.order === unit.order + 1);
  const metrics = getUnitProgressMetrics(unitId);
  const overlay = document.createElement('div');
  overlay.className = 'unit-completion-overlay';
  overlay.innerHTML = `
    <section class="unit-completion-card" role="dialog" aria-modal="true" aria-labelledby="unitCompletionTitle">
      <button type="button" class="unit-completion-close" aria-label="Cerrar">×</button>
      <span class="unit-completion-icon" aria-hidden="true">🏁</span>
      <span class="unit-completion-kicker">Unidad completada</span>
      <h2 id="unitCompletionTitle">${escapeHtml(unit.title)}</h2>
      <p>Completaste el recorrido de comprensión, vocabulario, gramática y producción.</p>
      <div class="unit-completion-results">
        <span><strong>${metrics.completedCount}/${metrics.total}</strong> actividades</span>
        <span><strong>${metrics.progressPercent}/100</strong> score</span>
        <span><strong>+${escapeHtml(String(xpReward))}</strong> XP</span>
      </div>
      <div class="unit-completion-actions">
        ${
          nextUnit
            ? `<button type="button" class="primary-btn unit-completion-next" data-unit-id="${escapeHtml(nextUnit.id)}">Continuar a la siguiente unidad →</button>`
            : '<button type="button" class="primary-btn unit-completion-progress">Ver mi progreso</button>'
        }
        ${nextUnit ? '<button type="button" class="secondary-btn unit-completion-progress">Ver mi progreso</button>' : ''}
      </div>
    </section>
  `;
  document.body.appendChild(overlay);
  overlay.querySelector('.unit-completion-close')?.focus();
  const close = () => overlay.remove();
  overlay.querySelector('.unit-completion-close')?.addEventListener('click', close);
  overlay.addEventListener('click', (event) => {
    if (event.target === overlay) close();
  });
  overlay.querySelector('.unit-completion-progress')?.addEventListener('click', () => {
    close();
    history.pushState(null, '', '#progress');
    showView('progress');
  });
  overlay.querySelector('.unit-completion-next')?.addEventListener('click', () => {
    const selected = learningPathState.units.find(
      (item) => item.id === overlay.querySelector('.unit-completion-next')?.dataset.unitId
    );
    if (!selected) return;
    close();
    selectUnit(selected.id, { render: false });
    const action = getUnitActionState(selected);
    const lesson = learningPathState.lessons.find((item) => item.slug === action.targetSlug);
    if (lesson) openUnitSequenceStep(lesson.skill, lesson.slug);
    else {
      showView('learn');
      renderLearningPath();
    }
  });
}

window.AndergoGamification?.onEvent((type, payload) => {
  if (type === 'unit-complete') showUnitCompletionPanel(payload);
});

// Purely visual reaction to an activity being completed - called right
// after showHomeToast()'s "+X XP" toast at each completion call site
// (Speaking/Listening/lesson workspace). Never reads or writes
// scoring/progress data, only reacts to it once the server has already
// confirmed completion. Confetti node creation is skipped under
// prefers-reduced-motion since CSS alone can animate a burst away
// instantly but can't prevent the DOM churn of creating it.
function celebrateActivityCompletion() {
  const toast = document.querySelector('.home-toast');
  toast?.classList.add('xp-celebrate');
  window.setTimeout(() => toast?.classList.remove('xp-celebrate'), 700);

  if (window.matchMedia?.('(prefers-reduced-motion: reduce)').matches) return;

  const burst = document.createElement('div');
  burst.className = 'confetti-burst';
  const pieceCount = 18;
  for (let i = 0; i < pieceCount; i += 1) {
    const piece = document.createElement('span');
    piece.className = 'confetti-piece';
    piece.style.left = `${Math.random() * 100}vw`;
    piece.style.background = `var(--confetti-${(i % 4) + 1})`;
    piece.style.animationDelay = `${Math.random() * 200}ms`;
    burst.appendChild(piece);
  }
  document.body.appendChild(burst);
  window.setTimeout(() => burst.remove(), 1500);
}

function handleHomeAction(action) {
  const goTo = (view, toast) => {
    if (window.location.hash !== `#${view}`) history.pushState(null, '', `#${view}`);
    showView(view);
    if (toast) showHomeToast(toast);
  };
  const openLanguageSelector = (language = '') => {
    goTo('home');
    if (language) {
      if (
        language === learningPathState.bridgeLanguage &&
        learningPathState.language !== learningPathState.bridgeLanguage
      ) {
        swapLearningPathLanguages();
      } else {
        setTargetLanguage(language);
      }
    }
    window.setTimeout(() => {
      document
        .querySelector('.global-language-controls')
        ?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      document.getElementById(language ? 'pathLevelSelect' : 'pathLanguageSelect')?.focus({
        preventScroll: true
      });
    }, 50);
  };

  switch (action) {
    case 'continue-lesson':
      goTo('learn', 'Ruta de lecciones abierta. Elige una lección y completa el reto.');
      break;
    case 'start-free':
      openLanguageSelector();
      showHomeToast('Elige idioma y nivel para comenzar.');
      break;
    case 'goals':
      goTo('goals', 'Elige o gestiona tu objetivo.');
      break;
    case 'view-progress':
      goTo('progress', 'Aquí puedes ver tu progreso y actividad reciente.');
      break;
    case 'upgrade':
      // #premium now lives at the end of the home view (see VIEW_SECTIONS)
      // instead of being its own destination - go home, then scroll to it,
      // same pattern as 'explore-languages' below.
      goTo('home');
      setPricingExpanded(true);
      window.setTimeout(() => {
        document.getElementById('premium')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 50);
      showHomeToast(`Plan premium único: USD ${premiumPriceUsd}.`);
      break;
    case 'view-plans': {
      const details = document.querySelector('.pricing-details');
      const expand = Boolean(details?.hidden);
      setPricingExpanded(expand);
      if (expand) {
        window.setTimeout(() => {
          details?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }, 50);
      }
      break;
    }
    case 'ai-tutor':
      goTo('tutor', 'Tutor IA abierto. Practica listening, speaking o writing.');
      break;
    case 'explore-languages':
      openLanguageSelector();
      showHomeToast('Elige un idioma para ver su ruta completa.');
      break;
    case 'explore-english':
      openLanguageSelector('english');
      showHomeToast('English seleccionado. Elige tu nivel.');
      break;
    case 'explore-frances':
      openLanguageSelector('french');
      showHomeToast('Français seleccionado. Elige tu nivel.');
      break;
    case 'explore-espanol':
      openLanguageSelector('spanish');
      showHomeToast('Español seleccionado. Elige tu nivel.');
      break;
    default:
      break;
  }
}

function enableHomepageActions() {
  document.querySelectorAll('[data-home-action]').forEach((element) => {
    element.addEventListener('click', (event) => {
      const action = element.dataset.homeAction;
      if (action) {
        event.preventDefault();
        handleHomeAction(action);
      }
    });
  });

  document.querySelectorAll('.skill-competency-card').forEach((card) => {
    card.addEventListener('keydown', (event) => {
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        card.click();
      }
    });
  });

  document.addEventListener('click', async (event) => {
    // Delegated (rather than a one-time listener on a single element) because
    // renderLessonWorkspace() now fully replaces #lessonWorkspace's innerHTML
    // when it switches between the "continue" card and full lesson detail,
    // which would otherwise orphan a listener bound to the old button node.
    if (event.target.closest('.lesson-complete-btn')) {
      completeActiveLesson();
      return;
    }

    const dictateBtn = event.target.closest('.tutor-dictate-btn');
    if (dictateBtn) {
      const target = dictateBtn.dataset.dictateTarget;
      // Every mic use on the Tutor (drawer or in-page) detects a short
      // natural pause and then sends automatically - not
      // only the Premium hands-free "Conversar" mode. What's still
      // Premium-only is resumeTutorConversationListening auto-re-arming the
      // mic after the tutor's reply finishes (see sendTutorMessage's
      // shouldForceSpeech) - a single recording auto-sending on silence is
      // not that.
      startTutorDictation(target, {
        continuous: true,
        silenceMs: TUTOR_CONVERSATION_SILENCE_MS,
        autoSend: true
      });
      return;
    }
    const dictateStopBtn = event.target.closest('.tutor-dictate-stop-btn');
    if (dictateStopBtn) {
      stopTutorDictation();
      return;
    }

    if (event.target.closest('.translator-dictate-btn')) {
      startTranslatorDictation();
      return;
    }
    if (event.target.closest('.translator-dictate-stop-btn')) {
      stopTranslatorDictation();
      return;
    }

    if (event.target.closest('[data-action="open-forgot-password"]')) {
      setAuthMessage('');
      resetForgotPasswordForm();
      openModal('forgotPassword');
      return;
    }
    if (event.target.closest('[data-action="back-to-login"]')) {
      setAuthMessage('');
      resetForgotPasswordForm();
      clearPendingMfa();
      openModal('login');
      return;
    }
    if (event.target.closest('[data-action="dismiss-username-onboarding"]')) {
      closeUsernameOnboarding();
      // Session-only, not a source of truth for "has a username" (that's
      // always profiles.username_normalized/username) - just stops this
      // same tab from reopening the modal on every nav change for the rest
      // of the session. A brand new session (new login) re-evaluates fresh.
      sessionStorage.setItem(USERNAME_ONBOARDING_DISMISSED_KEY, 'true');
      return;
    }

    // A locked lesson's "Desbloquear" button (see renderLessonWorkspace's
    // premium-lock-box) opens the same paywall modal used for usage-limit
    // lockouts instead of navigating away to the plans section - the
    // student is already looking at exactly what they'd unlock.
    if (event.target.closest('[data-action="open-lesson-paywall"]')) {
      openPaywallModal({
        title: 'Esta lección es Premium.',
        message: `Desbloquea esta lección y toda la ruta por USD ${premiumPriceUsd}.`
      });
      return;
    }

    const upgradeButton = event.target.closest('.upgrade-btn');
    if (upgradeButton) {
      handleHomeAction('upgrade');
      if (!authStatus.session?.access_token) {
        setAuthMessage(
          `Crea tu cuenta para desbloquear la ruta premium por USD ${premiumPriceUsd}.`
        );
        openModal('signup');
      }
      return;
    }

    const skillCompetencyCard = event.target.closest('.skill-competency-card');
    if (skillCompetencyCard) {
      const skill = skillCompetencyCard.dataset.skill;
      if (!SKILL_VIEWS.includes(skill)) return;
      if (window.location.hash !== `#${skill}`) history.pushState(null, '', `#${skill}`);
      showView(skill);
      return;
    }

    const suggestion = event.target.closest('.predictive-suggestion');
    if (suggestion) {
      const group = suggestion.closest('.predictive-suggestions');
      group
        ?.querySelectorAll('.predictive-suggestion')
        .forEach((item) => item.classList.remove('selected'));
      suggestion.classList.add('selected');
      const tutorPrompt = document.getElementById('aiTutorPrompt');
      if (tutorPrompt && suggestion.closest('#tutor')) {
        tutorPrompt.value = suggestion.textContent.trim();
        tutorPrompt.focus();
      }
      showHomeToast(`Seleccionado: ${suggestion.textContent.trim()}`);
      const skillPanel = suggestion.closest('.skill-panel');
      window.AndergoGamification?.recordSkillTouched(
        skillPanel?.dataset.skill,
        learningPathState.language
      );
      return;
    }

    const mcqOption = event.target.closest('.mcq-option');
    if (mcqOption) {
      const questionItem = mcqOption.closest('.mcq-question');
      const slug = questionItem?.dataset.lessonSlug;
      if (
        !questionItem ||
        questionItem.classList.contains('answered') ||
        mcqOption.disabled ||
        !slug
      )
        return;

      const exerciseIndex = Number(questionItem.dataset.exerciseIndex);
      const exerciseId = questionItem.dataset.exerciseId || '';
      const chosenKey = mcqOption.dataset.optionKey;
      const feedback = questionItem.querySelector('.mcq-feedback');

      questionItem.querySelectorAll('.mcq-option').forEach((option) => {
        option.disabled = true;
      });
      if (feedback) feedback.textContent = 'Comprobando...';

      try {
        const payload = exerciseId
          ? { exerciseId, selectedOptionId: chosenKey }
          : { index: exerciseIndex, selectedOption: Number(chosenKey) };
        const response = await fetch(`${backendBaseUrl}/api/lessons/${slug}/check-answer`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
        const data = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(data.error || 'No se pudo verificar la respuesta.');

        learningPathState.exerciseResults[slug] = learningPathState.exerciseResults[slug] || {};
        learningPathState.exerciseResults[slug][exerciseIndex] = {
          selectedOption: chosenKey,
          correct: Boolean(data.correct)
        };

        if (data.correct) {
          window.AndergoGamification?.recordCorrectAnswer();
          window.AndergoGamification?.recordSkillTouched(
            questionItem.dataset.skill,
            questionItem.dataset.language || learningPathState.language
          );
        }
      } catch (error) {
        if (feedback) feedback.textContent = error.message || 'No se pudo verificar la respuesta.';
        questionItem.querySelectorAll('.mcq-option').forEach((option) => {
          option.disabled = false;
        });
        return;
      }

      // Re-render whichever dedicated skill view is actually on screen
      // (Reading/Grammar/Listening each keep their own progress bar) rather
      // than always refreshing the legacy #lessonWorkspace, which otherwise
      // goes stale until the student navigates away and back.
      const currentView = getViewFromHash();
      if (SKILL_VIEWS.includes(currentView)) {
        renderSkillView(currentView);
      } else {
        renderLessonWorkspace();
      }
      return;
    }

    // Reading comprehension quiz (see renderReadingComprehensionQuiz above):
    // every selection is checked immediately, while "Evaluar" remains the
    // final score/summary action after all items have individual feedback.
    const readingCompOption = event.target.closest('.reading-comp-option');
    if (readingCompOption) {
      if (readingCompOption.disabled) return;
      const questionItem = readingCompOption.closest('.reading-comp-question');
      const slug = questionItem?.dataset.lessonSlug;
      if (!questionItem || !slug) return;

      const runtime = getReadingComprehensionRuntime(slug);
      if (runtime.graded || runtime.grading) return;

      const exerciseIndex = Number(questionItem.dataset.exerciseIndex);
      const lesson = learningPathState.lessons.find((item) => item.slug === slug);
      const exercise = lesson?.exercises?.[exerciseIndex];
      if (!lesson || !exercise || runtime.results[exerciseIndex]) return;

      runtime.selections[exerciseIndex] = readingCompOption.dataset.optionKey;
      runtime.gradingItems[exerciseIndex] = true;
      runtime.error = '';

      const currentView = getViewFromHash();
      if (SKILL_VIEWS.includes(currentView)) {
        renderSkillView(currentView);
      } else {
        renderLessonWorkspace();
      }

      try {
        const selected = runtime.selections[exerciseIndex];
        const payload = exercise.id
          ? { exerciseId: exercise.id, selectedOptionId: selected }
          : { index: exerciseIndex, selectedOption: Number(selected) };
        const response = await fetch(`${backendBaseUrl}/api/lessons/${slug}/check-answer`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
        const data = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(data.error || 'No se pudo comprobar la respuesta.');

        const correctKey = data.correctOption ?? data.correctOptionId ?? null;
        const correctOptionIndex = (exercise.options || []).findIndex(
          (option, optionIndex) =>
            String(optionKey(option, optionIndex)) === String(correctKey)
        );
        runtime.results[exerciseIndex] = {
          correct: Boolean(data.correct),
          correctOption: correctKey,
          correctLabel:
            correctOptionIndex >= 0
              ? `${String.fromCharCode(65 + correctOptionIndex)}. ${optionLabel(exercise.options[correctOptionIndex])}`
              : '',
          selectedOption: selected
        };
        learningPathState.exerciseResults[slug] =
          learningPathState.exerciseResults[slug] || {};
        learningPathState.exerciseResults[slug][exerciseIndex] = {
          selectedOption: selected,
          correct: Boolean(data.correct)
        };
        if (data.correct) {
          window.AndergoGamification?.recordSkillTouched(
            'reading',
            learningPathState.language
          );
          window.AndergoGamification?.recordCorrectAnswer();
        }
      } catch (error) {
        delete runtime.selections[exerciseIndex];
        runtime.error = error.message || 'No se pudo comprobar la respuesta.';
      } finally {
        delete runtime.gradingItems[exerciseIndex];
      }

      if (SKILL_VIEWS.includes(getViewFromHash())) {
        renderSkillView(getViewFromHash());
      } else {
        renderLessonWorkspace();
      }
      return;
    }

    // "Calificar": grades every comprehension question at once against the
    // real (server-side-only) answer key, then shows the 0-100 score.
    const readingCompSubmitBtn = event.target.closest('.reading-comp-submit-btn');
    if (readingCompSubmitBtn) {
      if (readingCompSubmitBtn.disabled) return;
      const slug = readingCompSubmitBtn.dataset.lessonSlug;
      const lesson = learningPathState.lessons.find((item) => item.slug === slug);
      if (!lesson) return;

      const runtime = getReadingComprehensionRuntime(slug);
      const comprehensionEntries = (lesson.exercises || [])
        .map((item, exerciseIndex) => ({ item, exerciseIndex }))
        .filter(({ item }) => item.type === 'mcq' && !isTrueFalseExercise(item));
      const unanswered = comprehensionEntries.some(
        ({ exerciseIndex }) =>
          runtime.selections[exerciseIndex] == null ||
          runtime.results[exerciseIndex] == null
      );
      if (unanswered || runtime.grading) return;

      runtime.graded = true;
      runtime.error = '';
      if (authStatus.session?.access_token) {
        runtime.grading = true;
        try {
          const answers = (lesson.exercises || []).map((item, exerciseIndex) => ({
            exerciseId: item.id,
            selectedOptionId: item.type === 'mcq' ? runtime.selections[exerciseIndex] : undefined,
            practiced: item.type !== 'mcq'
          }));
          const response = await fetch(`${backendBaseUrl}/api/lessons/${slug}/complete`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', ...authHeaders() },
            body: JSON.stringify({ answers })
          });
          const data = await response.json().catch(() => ({}));
          if (!response.ok) throw new Error(data.error || 'No se pudo guardar la evaluación.');
          lesson.completed = true;
          runtime.serverResult = data;
          updateProgressDisplay(data, true);
          renderSkillCards();
          window.AndergoGamification?.recordLessonCompletion({
            slug: lesson.slug,
            language: learningPathState.language,
            ...getLessonGamificationContext(lesson),
            score: data.score,
            xpReward: lesson.xpReward || 20
          });
          window.AndergoGamification?.syncFromServer(data);
          if (data.newBadges?.length)
            data.newBadges.forEach((badge) => showCelebration(`🏅 ¡Insignia desbloqueada! ${badge.label}`));
          showHomeToast(`Evaluación completada. +${data.earnedXp || lesson.xpReward || 20} XP`);
        } catch (error) {
          runtime.error = error.message || 'No se pudo guardar la evaluación.';
        } finally {
          runtime.grading = false;
        }
      }
      const summaryView = getViewFromHash();
      if (SKILL_VIEWS.includes(summaryView)) {
        renderSkillView(summaryView);
      } else {
        renderLessonWorkspace();
      }
      return;

      /*
       * Legacy batch-grading fallback retained below for reference while
       * older cached clients age out. New clients grade each item on click.
       */
      runtime.grading = true;
      runtime.error = '';
      readingCompSubmitBtn.disabled = true;
      readingCompSubmitBtn.textContent = 'Calificando…';

      try {
        const gradedResults = await Promise.all(
          comprehensionEntries.map(async ({ item, exerciseIndex }) => {
            const selected = runtime.selections[exerciseIndex];
            const payload = item.id
              ? { exerciseId: item.id, selectedOptionId: selected }
              : { index: exerciseIndex, selectedOption: Number(selected) };
            const response = await fetch(`${backendBaseUrl}/api/lessons/${slug}/check-answer`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(payload)
            });
            const data = await response.json().catch(() => ({}));
            if (!response.ok) throw new Error(data.error || 'No se pudo calificar. Intenta de nuevo.');

            // Only the key of the correct option comes back from the server
            // (never the answer itself ahead of time) - the option's own
            // text is already public in the client bundle, so this just
            // looks up the matching option locally to build a human label.
            const correctKey = data.correctOption ?? data.correctOptionId ?? null;
            const correctOptionIndex = (item.options || []).findIndex(
              (option, optionIndex) => String(optionKey(option, optionIndex)) === String(correctKey)
            );
            const correctLabel =
              correctOptionIndex >= 0
                ? `${String.fromCharCode(65 + correctOptionIndex)}. ${optionLabel(item.options[correctOptionIndex])}`
                : '';

            return {
              exerciseIndex,
              correct: Boolean(data.correct),
              correctOption: correctKey,
              correctLabel,
              selectedOption: selected
            };
          })
        );

        gradedResults.forEach((result) => {
          runtime.results[result.exerciseIndex] = result;
          learningPathState.exerciseResults[slug] = learningPathState.exerciseResults[slug] || {};
          learningPathState.exerciseResults[slug][result.exerciseIndex] = {
            selectedOption: result.selectedOption,
            correct: result.correct
          };
        });
        runtime.graded = true;
        runtime.grading = false;

        const correctCount = gradedResults.filter((r) => r.correct).length;
        if (correctCount > 0) {
          window.AndergoGamification?.recordSkillTouched('reading', learningPathState.language);
        }
        for (let i = 0; i < correctCount; i += 1) window.AndergoGamification?.recordCorrectAnswer();
      } catch (error) {
        runtime.grading = false;
        runtime.error = error.message || 'No se pudo calificar. Intenta de nuevo.';
      }

      const currentView = getViewFromHash();
      if (SKILL_VIEWS.includes(currentView)) {
        renderSkillView(currentView);
      } else {
        renderLessonWorkspace();
      }
      return;
    }

    const readingCompSignupBtn = event.target.closest('.reading-comp-signup-btn');
    if (readingCompSignupBtn) {
      setAuthMessage('Crea tu cuenta gratis para guardar tu nota, XP y logros.');
      openModal('signup');
      return;
    }

    // "Intentar de nuevo": clears selections/results and returns the score
    // to zero without touching the questions themselves or re-fetching the
    // reading (see resetReadingComprehensionRuntime above).
    const readingCompRetryBtn = event.target.closest('.reading-comp-retry-btn');
    if (readingCompRetryBtn) {
      const slug = readingCompRetryBtn.dataset.lessonSlug;
      if (!slug) return;
      const lesson = learningPathState.lessons.find((item) => item.slug === slug);

      resetReadingComprehensionRuntime(slug);
      if (lesson && learningPathState.exerciseResults[slug]) {
        (lesson.exercises || []).forEach((item, exerciseIndex) => {
          if (item.type === 'mcq' && !isTrueFalseExercise(item)) {
            delete learningPathState.exerciseResults[slug][exerciseIndex];
          }
        });
      }

      const currentView = getViewFromHash();
      if (SKILL_VIEWS.includes(currentView)) {
        renderSkillView(currentView);
      } else {
        renderLessonWorkspace();
      }
      return;
    }

    // Scored Grammar test (see renderGrammarTestView and friends above).
    // Every handler below resolves the active lesson the same way the
    // Listening "regenerate" handler above does: via the enclosing
    // .skill-view-section's data-active-lesson-slug, not a slug stashed on
    // the clicked element itself.
    function getGrammarTestContext(target) {
      const skillSection = target.closest('.skill-view-section');
      const lesson = learningPathState.lessons.find(
        (item) => item.slug === skillSection?.dataset.activeLessonSlug
      );
      const content = skillSection?.querySelector('.skill-view-content');
      if (!lesson?.extra?.grammarTest?.questions?.length || !content) return null;
      return { lesson, content, test: lesson.extra.grammarTest, runtime: getGrammarTestRuntime(lesson) };
    }

    const grammarTestStartBtn = event.target.closest('.grammar-test-start-btn');
    if (grammarTestStartBtn) {
      const ctx = getGrammarTestContext(grammarTestStartBtn);
      if (!ctx) return;
      ctx.runtime.phase = 'question';
      ctx.runtime.currentIndex = 0;
      renderGrammarTestView(ctx.content, ctx.lesson);
      return;
    }

    const grammarTestOption = event.target.closest('.grammar-test-option');
    if (grammarTestOption) {
      const optionsWrap = grammarTestOption.closest('.grammar-test-options');
      optionsWrap?.querySelectorAll('.grammar-test-option').forEach((btn) => {
        btn.classList.remove('is-selected');
        btn.setAttribute('aria-pressed', 'false');
      });
      grammarTestOption.classList.add('is-selected');
      grammarTestOption.setAttribute('aria-pressed', 'true');
      const ctx = getGrammarTestContext(grammarTestOption);
      const questionId = grammarTestOption.closest('.grammar-test-question-item')?.dataset.questionId;
      if (ctx && questionId) {
        ctx.runtime.answers[questionId] = grammarTestOption.dataset.optionId;
        const answered = ctx.test.questions.filter((question) => ctx.runtime.answers[question.id] != null).length;
        const total = ctx.test.questions.length;
        const progress = total ? Math.round((answered / total) * 100) : 0;
        const counter = ctx.content.querySelector('.grammar-test-counter');
        const progressBar = ctx.content.querySelector('.grammar-test-progress-bar div');
        const warning = ctx.content.querySelector('.grammar-test-review-warning');
        const submit = ctx.content.querySelector('.grammar-test-submit-btn');
        if (counter) counter.textContent = `${answered} of ${total} answered`;
        if (progressBar) progressBar.style.width = `${progress}%`;
        if (warning) warning.hidden = answered === total;
        if (submit) submit.disabled = answered !== total;
      }
      return;
    }

    const grammarTestPrevBtn = event.target.closest('.grammar-test-prev-btn');
    if (grammarTestPrevBtn) {
      const ctx = getGrammarTestContext(grammarTestPrevBtn);
      if (!ctx) return;
      collectGrammarTestAnswer(ctx.content, ctx.test, ctx.runtime);
      ctx.runtime.currentIndex = Math.max(0, ctx.runtime.currentIndex - 1);
      renderGrammarTestView(ctx.content, ctx.lesson);
      return;
    }

    const grammarTestNextBtn = event.target.closest('.grammar-test-next-btn');
    if (grammarTestNextBtn) {
      const ctx = getGrammarTestContext(grammarTestNextBtn);
      if (!ctx) return;
      collectGrammarTestAnswer(ctx.content, ctx.test, ctx.runtime);
      if (ctx.runtime.currentIndex >= ctx.test.questions.length - 1) {
        ctx.runtime.phase = 'review';
      } else {
        ctx.runtime.currentIndex += 1;
      }
      renderGrammarTestView(ctx.content, ctx.lesson);
      return;
    }

    const grammarTestReviewEditBtn = event.target.closest('.grammar-test-review-edit-btn');
    if (grammarTestReviewEditBtn) {
      const ctx = getGrammarTestContext(grammarTestReviewEditBtn);
      if (!ctx) return;
      ctx.runtime.currentIndex = Number(grammarTestReviewEditBtn.dataset.questionIndex) || 0;
      ctx.runtime.phase = 'question';
      renderGrammarTestView(ctx.content, ctx.lesson);
      return;
    }

    const grammarTestRetryBtn = event.target.closest('.grammar-test-retry-btn');
    if (grammarTestRetryBtn) {
      const ctx = getGrammarTestContext(grammarTestRetryBtn);
      if (!ctx) return;
      grammarTestState.set(ctx.lesson.slug, {
        phase: 'question',
        currentIndex: 0,
        answers: {},
        lastResult: null
      });
      renderGrammarTestView(ctx.content, ctx.lesson);
      return;
    }

    const grammarTestSubmitBtn = event.target.closest('.grammar-test-submit-btn');
    if (grammarTestSubmitBtn) {
      const ctx = getGrammarTestContext(grammarTestSubmitBtn);
      if (!ctx || grammarTestSubmitBtn.disabled) return;

      if (!authStatus.session?.access_token) {
        setAuthMessage('Inicia sesión para guardar el resultado de tu prueba.');
        openModal('login');
        return;
      }

      const { lesson, content, test, runtime } = ctx;
      grammarTestSubmitBtn.disabled = true;
      grammarTestSubmitBtn.textContent = 'Enviando...';

      try {
        const answers = test.questions.map((q) => ({ questionId: q.id, answer: runtime.answers[q.id] }));
        const response = await authFetch(`${backendBaseUrl}/api/lessons/${lesson.slug}/complete`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ answers })
        });
        const data = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(data.error || 'No se pudo enviar la prueba.');

        lesson.completed = true;
        if (data.bestScore != null) lesson.bestScore = data.bestScore;
        updateProgressDisplay(data, true);
        renderSkillCards();
        window.AndergoGamification?.recordLessonCompletion({
          slug: lesson.slug,
          language: learningPathState.language,
          ...getLessonGamificationContext(lesson),
          score: data.score ?? 100,
          xpReward: lesson.xpReward || 20
        });
        window.AndergoGamification?.syncFromServer(data);
        if (data.newBadges?.length) {
          data.newBadges.forEach((badge) =>
            showCelebration(`🏅 ¡Insignia desbloqueada! ${badge.label}`)
          );
        }
        if (data.leveledUp) showCelebration(`🎉 ¡Subiste a nivel ${data.level}!`);
        showHomeToast(`Prueba completada. +${data.earnedXp || lesson.xpReward || 20} XP`);
        celebrateActivityCompletion();

        runtime.lastResult = data;
        runtime.phase = 'results';
        renderGrammarTestView(content, lesson);
      } catch (error) {
        grammarTestSubmitBtn.disabled = false;
        grammarTestSubmitBtn.textContent = 'Enviar prueba';
        showHomeToast(error.message || 'No se pudo enviar la prueba.');
      }
      return;
    }

    // Scored Listening Comprehension (see renderListeningComprehensionPanel
    // and friends above) - same shape/endpoint as the Grammar test handlers
    // just above, but resolves into .listening-mode-panel (one tab among
    // Escuchar/Diálogos/Dictado/Transcripción/Transcripción fonética)
    // instead of the whole .skill-view-content, and reads
    // lesson.extra.listeningComprehension instead of lesson.extra.grammarTest.
    function getListeningComprehensionContext(target) {
      const skillSection = target.closest('.skill-view-section');
      const lesson = learningPathState.lessons.find(
        (item) => item.slug === skillSection?.dataset.activeLessonSlug
      );
      const panel = skillSection?.querySelector('.listening-mode-panel');
      if (!lesson?.extra?.listeningComprehension?.questions?.length || !panel) return null;
      return {
        lesson,
        content: skillSection.querySelector('.skill-view-content'),
        panel,
        bank: lesson.extra.listeningComprehension,
        runtime: getListeningComprehensionRuntime(lesson)
      };
    }

    const listeningCompStartBtn = event.target.closest('.listening-comp-start-btn');
    if (listeningCompStartBtn) {
      const ctx = getListeningComprehensionContext(listeningCompStartBtn);
      if (!ctx) return;
      ctx.runtime.phase = 'question';
      ctx.runtime.currentIndex = 0;
      ctx.panel.innerHTML = renderListeningComprehensionPanel(ctx.lesson);
      return;
    }

    const listeningCompPrevBtn = event.target.closest('.listening-comp-prev-btn');
    if (listeningCompPrevBtn) {
      const ctx = getListeningComprehensionContext(listeningCompPrevBtn);
      if (!ctx) return;
      collectGrammarTestAnswer(ctx.panel, ctx.bank, ctx.runtime);
      ctx.runtime.currentIndex = Math.max(0, ctx.runtime.currentIndex - 1);
      ctx.panel.innerHTML = renderListeningComprehensionPanel(ctx.lesson);
      return;
    }

    const listeningCompNextBtn = event.target.closest('.listening-comp-next-btn');
    if (listeningCompNextBtn) {
      const ctx = getListeningComprehensionContext(listeningCompNextBtn);
      if (!ctx) return;
      collectGrammarTestAnswer(ctx.panel, ctx.bank, ctx.runtime);
      if (ctx.runtime.currentIndex >= ctx.bank.questions.length - 1) {
        ctx.runtime.phase = 'review';
      } else {
        ctx.runtime.currentIndex += 1;
      }
      ctx.panel.innerHTML = renderListeningComprehensionPanel(ctx.lesson);
      return;
    }

    const listeningCompReviewEditBtn = event.target.closest('.listening-comp-review-edit-btn');
    if (listeningCompReviewEditBtn) {
      const ctx = getListeningComprehensionContext(listeningCompReviewEditBtn);
      if (!ctx) return;
      ctx.runtime.currentIndex = Number(listeningCompReviewEditBtn.dataset.questionIndex) || 0;
      ctx.runtime.phase = 'question';
      ctx.panel.innerHTML = renderListeningComprehensionPanel(ctx.lesson);
      return;
    }

    const listeningCompRetryBtn = event.target.closest('.listening-comp-retry-btn');
    if (listeningCompRetryBtn) {
      const ctx = getListeningComprehensionContext(listeningCompRetryBtn);
      if (!ctx) return;
      listeningComprehensionState.set(ctx.lesson.slug, {
        phase: 'question',
        currentIndex: 0,
        answers: {},
        lastResult: null
      });
      ctx.panel.innerHTML = renderListeningComprehensionPanel(ctx.lesson);
      return;
    }

    const listeningCompSubmitBtn = event.target.closest('.listening-comp-submit-btn');
    if (listeningCompSubmitBtn) {
      const ctx = getListeningComprehensionContext(listeningCompSubmitBtn);
      if (!ctx || listeningCompSubmitBtn.disabled) return;

      if (!authStatus.session?.access_token) {
        setAuthMessage('Inicia sesión para guardar el resultado de esta prueba.');
        openModal('login');
        return;
      }

      const { lesson, panel, bank, runtime } = ctx;
      listeningCompSubmitBtn.disabled = true;
      listeningCompSubmitBtn.textContent = 'Enviando...';

      try {
        const answers = bank.questions.map((q) => ({ questionId: q.id, answer: runtime.answers[q.id] }));
        const response = await authFetch(`${backendBaseUrl}/api/lessons/${lesson.slug}/complete`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ answers })
        });
        const data = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(data.error || 'No se pudo enviar la prueba.');

        lesson.completed = true;
        if (data.bestScore != null) lesson.listeningComprehensionBestScore = data.bestScore;
        if (data.bestScore != null) lesson.bestScore = data.bestScore;
        updateProgressDisplay(data, true);
        renderSkillCards();
        window.AndergoGamification?.recordLessonCompletion({
          slug: lesson.slug,
          language: learningPathState.language,
          ...getLessonGamificationContext(lesson),
          score: data.score ?? 100,
          xpReward: lesson.xpReward || 20
        });
        window.AndergoGamification?.syncFromServer(data);
        if (data.newBadges?.length) {
          data.newBadges.forEach((badge) =>
            showCelebration(`🏅 ¡Insignia desbloqueada! ${badge.label}`)
          );
        }
        if (data.leveledUp) showCelebration(`🎉 ¡Subiste a nivel ${data.level}!`);
        showHomeToast(`Comprensión completada. +${data.earnedXp || lesson.xpReward || 20} XP`);
        celebrateActivityCompletion();

        runtime.lastResult = data;
        runtime.phase = 'results';
        panel.innerHTML = renderListeningComprehensionPanel(lesson);
      } catch (error) {
        listeningCompSubmitBtn.disabled = false;
        listeningCompSubmitBtn.textContent = 'Enviar';
        showHomeToast(error.message || 'No se pudo enviar la prueba.');
      }
      return;
    }

    const practiceButton = event.target.closest('.practice-mark-btn');
    if (practiceButton) {
      const exerciseBlock = practiceButton.closest('.open-exercise');
      const slug = exerciseBlock?.dataset.lessonSlug;
      if (practiceButton.disabled || !slug) return;

      const exerciseIndex = Number(exerciseBlock.dataset.exerciseIndex);
      learningPathState.exerciseResults[slug] = learningPathState.exerciseResults[slug] || {};
      learningPathState.exerciseResults[slug][exerciseIndex] = { practiced: true };

      window.AndergoGamification?.recordCorrectAnswer();
      window.AndergoGamification?.recordSkillTouched(
        exerciseBlock.dataset.skill,
        exerciseBlock.dataset.language || learningPathState.language
      );

      renderLessonWorkspace();
      return;
    }

    const tutorClearButton = event.target.closest('.tutor-clear-btn');
    if (tutorClearButton) {
      const conversation = document.getElementById('tutorConversation');
      if (conversation) {
        conversation.innerHTML =
          '<p class="tutor-welcome">👋 Soy el Tutor IA ANDERGO Academy. Pregúntame lo que quieras sobre esta habilidad, nivel o lección, y te ayudo con correcciones, ejemplos y práctica.</p>';
      }
      return;
    }

    const tutorButton = event.target.closest('.tutor-chat-btn');
    if (tutorButton) {
      primeTutorAudioForAutoplay();
      const card = tutorButton.closest('#tutor');
      const activeSkill =
        card?.querySelector('.skill-tab-button.active')?.dataset.skill || 'speaking';
      const activeLesson = getActiveLearningLesson();
      const selectedSuggestion = card
        ?.querySelector('.skill-panel.active .predictive-suggestion.selected')
        ?.textContent?.trim();
      const fallbackPrompt =
        {
          listening: 'Quiero practicar comprensión auditiva con un ejemplo corto y una pregunta.',
          speaking: 'Quiero practicar conversación con una respuesta modelo y una repregunta.',
          writing: 'Quiero practicar escritura con una corrección breve y un ejemplo mejorado.'
        }[activeSkill] || 'Quiero practicar esta habilidad.';

      await sendTutorMessage({
        conversationEl: document.getElementById('tutorConversation'),
        thinkingEl: document.getElementById('tutorThinking'),
        connectionStatusEl: document.getElementById('tutorConnectionStatus'),
        promptEl: document.getElementById('aiTutorPrompt'),
        sendBtn: tutorButton,
        skill: activeSkill,
        level: learningPathState.level || 'A1',
        language: learningPathState.language,
        bridgeLanguage: learningPathState.bridgeLanguage,
        lessonTitle: activeLesson?.title || '',
        lessonIntro: activeLesson?.intro || activeLesson?.description || '',
        lessonSlug: activeLesson?.slug || '',
        currentActivity: 'Viendo la vista Tutor IA',
        supportMode: 'practice',
        selectedSuggestion,
        fallbackPrompt
      });
      return;
    }

    const openTutorBtn = event.target.closest('.open-tutor-btn');
    if (openTutorBtn) {
      const skillSection = openTutorBtn.closest('.skill-view-section');
      const skill = skillSection?.dataset.skill || 'speaking';
      const lesson =
        learningPathState.lessons.find(
          (item) => item.slug === skillSection?.dataset.activeLessonSlug
        ) || getActiveLearningLesson();
      openTutorDrawer({
        skill,
        lessonTitle: lesson?.title || '',
        lessonIntro: lesson?.intro || lesson?.description || '',
        lessonSlug: lesson?.slug || '',
        supportMode: openTutorBtn.dataset.supportMode || 'practice',
        currentActivity: `Practicando ${getSkillLabel(skill)}`,
        prefill: openTutorBtn.dataset.tutorPrompt || '',
        transcript: openTutorBtn.dataset.tutorTranscript || '',
        vocabulary: openTutorBtn.dataset.tutorVocabulary || '',
        currentQuestion: openTutorBtn.dataset.tutorCurrentQuestion || '',
        selectedAnswer: openTutorBtn.dataset.tutorSelectedAnswer || ''
      });
      return;
    }

    // "Traducir" shortcuts from Reading/Grammar/Vocabulary/Speaking - see
    // openTranslator(). Always translates target-language content back into
    // the student's bridge language; data-return-label lets each view name
    // itself in "‹ Volver a ...".
    const openTranslatorBtn = event.target.closest('.open-translator-btn');
    if (openTranslatorBtn) {
      openTranslator({
        text: openTranslatorBtn.dataset.translateText || '',
        sourceLanguage: learningPathState.language,
        targetLanguage: learningPathState.bridgeLanguage,
        returnHash: window.location.hash || '#learn',
        returnLabel: openTranslatorBtn.dataset.returnLabel || 'Volver a la lección'
      });
      return;
    }

    // AI Tutor voice controls (Escuchar/Repetir share one button - see
    // renderTutorVoiceControls(); its label switches once played once).
    const tutorVoiceListenBtn = event.target.closest('.tutor-voice-listen');
    if (tutorVoiceListenBtn) {
      const messageEl = tutorVoiceListenBtn.closest('.tutor-message');
      if (messageEl) requestTutorSpeech(messageEl);
      return;
    }
    const tutorVoicePauseBtn = event.target.closest('.tutor-voice-pause');
    if (tutorVoicePauseBtn) {
      toggleTutorVoicePause(tutorVoicePauseBtn.closest('.tutor-message'));
      return;
    }
    const tutorVoiceRewindBtn = event.target.closest('.tutor-voice-rewind');
    if (tutorVoiceRewindBtn) {
      rewindTutorVoice(5);
      return;
    }
    const tutorVoiceStopBtn = event.target.closest('.tutor-voice-stop');
    if (tutorVoiceStopBtn) {
      stopAllTutorAudio();
      return;
    }
    const tutorVoiceSpeedBtn = event.target.closest('.tutor-voice-speed-btn');
    if (tutorVoiceSpeedBtn) {
      const messageEl = tutorVoiceSpeedBtn.closest('.tutor-message');
      const wasPlaying = messageEl && currentTutorAudio.messageEl === messageEl;
      tutorVoiceSpeedBtn
        .closest('.tutor-voice-speed-group')
        ?.querySelectorAll('.tutor-voice-speed-btn')
        .forEach((btn) => {
          const isActive = btn === tutorVoiceSpeedBtn;
          btn.classList.toggle('is-active', isActive);
          btn.setAttribute('aria-pressed', String(isActive));
        });
      // Spec §6: "al cambiar entre Normal y Lenta: detener la lectura
      // actual, reiniciar desde el comienzo con la nueva velocidad" -
      // requestTutorSpeech already calls stopAllTutorAudio() first thing,
      // so re-calling it here (only when this message was the one actually
      // speaking) restarts fresh at wordIndex -1 instead of resuming
      // mid-utterance at the old rate.
      if (wasPlaying) requestTutorSpeech(messageEl);
      return;
    }

    const changeComboBtn = event.target.closest('.change-combination-btn');
    if (changeComboBtn) {
      openChangeCombinationPopover();
      return;
    }
    if (event.target.closest('.change-combo-apply')) {
      applyChangeCombination();
      return;
    }
    if (event.target.closest('.change-combo-close') || event.target.id === 'changeComboPopover') {
      closeChangeCombinationPopover();
      return;
    }

    if (event.target.closest('[data-action="close-tutor-drawer"]')) {
      closeTutorDrawer();
      return;
    }

    const readingSizeButton = event.target.closest('.reading-size-btn');
    if (readingSizeButton) {
      const area = readingSizeButton.closest('.reading-print-area');
      const preferences = getReadingDisplayPreferences();
      preferences.size = readingSizeButton.dataset.readingSize;
      applyReadingDisplayPreferences(area, preferences);
      setReadingDisplayPreferences(preferences);
      return;
    }
    const readingAlignButton = event.target.closest('.reading-align-btn');
    if (readingAlignButton) {
      const area = readingAlignButton.closest('.reading-print-area');
      const preferences = getReadingDisplayPreferences();
      preferences.alignment = preferences.alignment === 'justify' ? 'left' : 'justify';
      applyReadingDisplayPreferences(area, preferences);
      setReadingDisplayPreferences(preferences);
      return;
    }
    const readingToggleVocab = event.target.closest('.reading-toggle-vocab');
    if (readingToggleVocab) {
      const list = readingToggleVocab
        .closest('.reading-vocab-section')
        ?.querySelector('.reading-vocab-list');
      if (list) {
        list.hidden = !list.hidden;
        readingToggleVocab.textContent = list.hidden ? 'Ver vocabulario' : 'Ocultar vocabulario';
        readingToggleVocab.setAttribute('aria-expanded', String(!list.hidden));
      }
      return;
    }
    const readingToggleSupport = event.target.closest('.reading-toggle-support');
    if (readingToggleSupport) {
      const area = readingToggleSupport.closest('.reading-print-area');
      const showSupport = readingToggleSupport.getAttribute('aria-pressed') !== 'true';
      const vocabList = area?.querySelector('.reading-vocab-list');
      area?.querySelectorAll('.reading-vocab-support').forEach((element) => {
        element.hidden = !showSupport;
      });
      if (showSupport && vocabList) {
        vocabList.hidden = false;
        const vocabButton = area.querySelector('.reading-toggle-vocab');
        if (vocabButton) {
          vocabButton.textContent = 'Ocultar vocabulario';
          vocabButton.setAttribute('aria-expanded', 'true');
        }
      }
      readingToggleSupport.setAttribute('aria-pressed', String(showSupport));
      readingToggleSupport.textContent = showSupport
        ? learningPathState.language === 'french'
          ? "Masquer l'aide en espagnol"
          : 'Ocultar ayuda en español'
        : learningPathState.language === 'french'
          ? "Afficher l'aide en espagnol"
          : 'Mostrar ayuda en español';
      return;
    }
    if (event.target.closest('.reading-word-btn')) {
      downloadReadingWord(getActiveLearningLesson());
      return;
    }
    if (event.target.closest('.reading-print-btn') || event.target.closest('.skill-print-btn')) {
      // window.print() itself rarely throws, but embedding contexts that
      // block it (some sandboxed iframes/webviews) do - never leave the
      // student with silent nothing-happened.
      try {
        window.print();
      } catch {
        showHomeToast('No pudimos generar el PDF. Inténtalo nuevamente.');
      }
      return;
    }

    const vocabTranslationButton = event.target.closest('.vocab-l1-translation-btn');
    if (vocabTranslationButton) {
      const activeSection = vocabTranslationButton.closest('.skill-view-section');
      const activeLesson = activeSection ? getActiveLearningLesson() : null;
      if (!activeSection || !activeLesson) return;
      vocabL1TranslationVisible = !vocabL1TranslationVisible;
      if (vocabL1TranslationVisible) {
        vocabTranslationButton.disabled = true;
        vocabTranslationButton.textContent = isFrenchAdvancedImmersion()
          ? 'Traduction en cours…'
          : 'Traduciendo…';
        await loadMissingAdvancedVocabTranslations(
          vocabPracticeSources.get(activeLesson.slug) || [],
          activeLesson.slug
        );
      }
      renderVocabularyView(activeSection, activeLesson);
      return;
    }

    if (event.target.closest('.vocab-shuffle-btn')) {
      // Fisher-Yates on the display-order array only - lesson.vocabulary
      // itself (and therefore the underlying test exercises' indices) never
      // changes, so "Mezclar tarjetas" only reorders what the student sees.
      for (let i = vocabCardOrder.length - 1; i > 0; i -= 1) {
        const j = Math.floor(Math.random() * (i + 1));
        [vocabCardOrder[i], vocabCardOrder[j]] = [vocabCardOrder[j], vocabCardOrder[i]];
      }
      const activeSection = event.target.closest('.skill-view-section');
      const activeLesson = activeSection ? getActiveLearningLesson() : null;
      if (activeSection && activeLesson) renderVocabularyView(activeSection, activeLesson);
      return;
    }

    // Full-reading audio player (spec section A/C) - the only controls that
    // move forward/back through a reading; they act on the audio only and
    // never touch which text is visible (no pagination, no part viewer). A
    // single toggle button cycles Reproducir -> Pausar -> Continuar ->
    // Pausar..., the rest are one-shot actions on the shared
    // readingSpeechPlayer singleton.
    const readingAudioPlayPauseBtn = event.target.closest('.reading-audio-playpause-btn');
    if (readingAudioPlayPauseBtn) {
      const snap = readingSpeechPlayer.getSnapshot();
      if (snap.state === 'playing') readingSpeechPlayer.pauseReading();
      else if (snap.state === 'paused') readingSpeechPlayer.resumeReading();
      else readingSpeechPlayer.playReading();
      return;
    }
    const readingAudioRewindBtn = event.target.closest('.reading-audio-rewind-btn');
    if (readingAudioRewindBtn) {
      readingSpeechPlayer.rewindReading(5);
      return;
    }
    const readingAudioStopBtn = event.target.closest('.reading-audio-stop-btn');
    if (readingAudioStopBtn) {
      readingSpeechPlayer.stopReading();
      return;
    }
    const readingAudioVoiceBtn = event.target.closest('.reading-audio-voice-btn');
    if (readingAudioVoiceBtn) {
      readingSpeechPlayer.changeReadingVoice();
      return;
    }
    const readingAudioRateBtn = event.target.closest('.reading-audio-rate-btn');
    if (readingAudioRateBtn) {
      readingSpeechPlayer.changeReadingRate(readingAudioRateBtn.dataset.rate);
      return;
    }

    const writingReviewBtn = event.target.closest('.writing-review-btn');
    if (writingReviewBtn) {
      const editor = document.getElementById('writingEditor');
      const editorText = editor?.value.trim() || '';
      if (!editorText) {
        showHomeToast('Escribe tu texto antes de pedir revisión.');
        return;
      }
      const mode = writingReviewBtn.dataset.supportMode;
      const prompts = {
        'review-grammar': `Revisa la gramática de este texto y explica los errores: ${editorText}`,
        'review-vocabulary': `Sugiere mejoras de vocabulario para este texto: ${editorText}`,
        'review-coherence': `Revisa la coherencia y organización de este texto: ${editorText}`,
        'explain-errors': `Explícame en español los errores de este texto: ${editorText}`,
        hint: `Dame una pista para mejorar este texto sin reescribirlo tú: ${editorText}`
      };
      const section = writingReviewBtn.closest('.skill-view-section');
      const lesson = learningPathState.lessons.find(
        (item) => item.slug === section?.dataset.activeLessonSlug
      );
      const panel = document.getElementById('writingTutorPanel');
      if (panel) {
        panel.hidden = false;
        panel.querySelector('.writing-tutor-original p').textContent = editorText;
        panel.querySelector('.writing-tutor-suggestion p').textContent = 'Consultando al Tutor IA…';
      }
      writingReviewBtn.disabled = true;
      const data = await sendTutorMessage({
        conversationEl: null,
        thinkingEl: null,
        connectionStatusEl: null,
        promptEl: null,
        sendBtn: null,
        skill: 'writing',
        level: learningPathState.level || 'A1',
        language: learningPathState.language,
        bridgeLanguage: learningPathState.bridgeLanguage,
        lessonTitle: lesson?.title || '',
        lessonIntro: lesson?.intro || lesson?.description || '',
        lessonSlug: lesson?.slug || '',
        currentActivity: 'Escribiendo un texto',
        supportMode: mode,
        fallbackPrompt: prompts[mode] || editorText
      });
      writingReviewBtn.disabled = false;
      if (panel)
        panel.querySelector('.writing-tutor-suggestion p').textContent =
          data?.reply || 'No se pudo obtener una respuesta del Tutor IA.';
      return;
    }
    if (event.target.closest('.writing-accept-btn')) {
      // Never auto-replaces the student's text - just acknowledges the
      // suggestion was reviewed and dismisses the panel.
      document.getElementById('writingTutorPanel')?.setAttribute('hidden', '');
      showHomeToast('Sugerencia aceptada. Tu texto no se modificó automáticamente.');
      return;
    }
    if (event.target.closest('.writing-reject-btn')) {
      document.getElementById('writingTutorPanel')?.setAttribute('hidden', '');
      showHomeToast('Sugerencia descartada.');
      return;
    }
    if (event.target.closest('.writing-compare-btn')) {
      const panel = document.getElementById('writingTutorPanel');
      const currentBlock = panel?.querySelector('.writing-tutor-current');
      if (currentBlock) {
        currentBlock.hidden = !currentBlock.hidden;
        if (!currentBlock.hidden)
          currentBlock.querySelector('p').textContent =
            document.getElementById('writingEditor')?.value.trim() || '';
      }
      return;
    }

    // Header speaker button - plays the target word without flipping the
    // card. stopPropagation keeps it from also falling through to the
    // "tap anywhere flips" handler below. Marks itself "is-playing" while
    // speaking (speakText's onEnd clears it) so the playing state is
    // visible, not just audible.
    const vocabAudioBtn = event.target.closest('.vocab-card-audio-btn');
    if (vocabAudioBtn) {
      event.stopPropagation();
      const card = vocabAudioBtn.closest('.vocab-card');
      if (card) {
        vocabAudioBtn.classList.add('is-playing');
        speakText(card.dataset.speakText, {
          locale: card.dataset.speakLocale,
          rate: Number(card.dataset.speakRate) || 1,
          onEnd: () => vocabAudioBtn.classList.remove('is-playing')
        });
      }
      return;
    }
    // Each context's own speaker button on the back of the card (only
    // rendered when there's a context sentence to speak).
    const vocabExampleAudioBtn = event.target.closest('.vocab-example-audio-btn');
    if (vocabExampleAudioBtn) {
      event.stopPropagation();
      vocabExampleAudioBtn.classList.add('is-playing');
      speakText(vocabExampleAudioBtn.dataset.speakText, {
        locale: vocabExampleAudioBtn.dataset.speakLocale,
        rate: Number(vocabExampleAudioBtn.dataset.speakRate) || 1,
        onEnd: () => vocabExampleAudioBtn.classList.remove('is-playing')
      });
      return;
    }
    const vocabKnowBtn = event.target.closest('.vocab-know-btn');
    if (vocabKnowBtn) {
      event.stopPropagation();
      setVocabCardMastery(vocabKnowBtn.closest('.vocab-card'), 'mastered');
      return;
    }
    const vocabRetryBtn = event.target.closest('.vocab-retry-btn');
    if (vocabRetryBtn) {
      event.stopPropagation();
      setVocabCardMastery(vocabRetryBtn.closest('.vocab-card'), 'practicing');
      return;
    }
    const vocabBackBtn = event.target.closest('.vocab-back-btn');
    if (vocabBackBtn) {
      event.stopPropagation();
      flipVocabCard(vocabBackBtn.closest('.vocab-card'), { toBack: false });
      return;
    }
    // Tapping any free area of the card flips it: front -> back speaks the
    // target word once (via flipVocabCard's speak option), back -> front
    // stays silent. Only fires when the click wasn't already handled by a
    // more specific control above.
    const vocabCardBody = event.target.closest('.vocab-card');
    if (vocabCardBody) {
      const isFlipped = vocabCardBody.dataset.flipped === 'true';
      flipVocabCard(vocabCardBody, { toBack: !isFlipped, speak: !isFlipped });
      return;
    }
  });

  document.getElementById('tutorFab')?.addEventListener('click', () => openTutorDrawer());

  document.getElementById('tutorDrawerSend')?.addEventListener('click', async () => {
    primeTutorAudioForAutoplay();
    const sendBtn = document.getElementById('tutorDrawerSend');
    await sendTutorMessage({
      conversationEl: document.getElementById('tutorDrawerConversation'),
      thinkingEl: document.getElementById('tutorDrawerThinking'),
      connectionStatusEl: document.getElementById('tutorDrawerConnectionStatus'),
      promptEl: document.getElementById('tutorDrawerPrompt'),
      sendBtn,
      skill: tutorDrawerContext.skill,
      level: learningPathState.level || 'A1',
      language: learningPathState.language,
      bridgeLanguage: learningPathState.bridgeLanguage,
      lessonTitle: tutorDrawerContext.lessonTitle,
      lessonIntro: tutorDrawerContext.lessonIntro,
      lessonSlug: tutorDrawerContext.lessonSlug,
      currentActivity:
        tutorDrawerContext.currentActivity ||
        `Practicando ${getSkillLabel(tutorDrawerContext.skill)}`,
      supportMode: tutorDrawerContext.supportMode,
      transcript: tutorDrawerContext.transcript,
      vocabulary: tutorDrawerContext.vocabulary,
      currentQuestion: tutorDrawerContext.currentQuestion,
      selectedAnswer: tutorDrawerContext.selectedAnswer,
      fallbackPrompt: 'Quiero practicar esta habilidad.'
    });
  });

  document.getElementById('tutorDrawerClear')?.addEventListener('click', () => {
    const conversation = document.getElementById('tutorDrawerConversation');
    if (conversation)
      conversation.innerHTML =
        '<p class="tutor-welcome">👋 Soy el Tutor IA ANDERGO Academy. Cuéntame qué quieres practicar.</p>';
  });

  document.getElementById('tutorDrawerPrompt')?.addEventListener('keydown', (event) => {
    // Any keystroke while a post-dictation auto-send is pending restarts its
    // 2s window (spec §5), letting the student finish an edit before it
    // fires - a no-op the rest of the time.
    restartTutorAutoSendIfPending('tutorDrawerPrompt');
    if (event.key !== 'Enter' || event.shiftKey) return;
    event.preventDefault();
    document.getElementById('tutorDrawerSend')?.click();
  });

  const autoplayToggle = document.getElementById('tutorAutoplayToggle');
  if (autoplayToggle) {
    autoplayToggle.checked = getTutorAutoplayPref();
    autoplayToggle.addEventListener('change', () => {
      setTutorAutoplayPref(autoplayToggle.checked);
    });
  }

  document.getElementById('tutorConversationToggle')?.addEventListener('click', () => {
    handleTutorConversationToggleClick();
  });
}

function setupLearningPathControls() {
  const languageSelect = document.getElementById('pathLanguageSelect');
  const levelSelect = document.getElementById('pathLevelSelect');
  const bridgeSelect = document.getElementById('pathBridgeSelect');

  languageSelect?.addEventListener('change', () => {
    const level = levelSelect?.value || learningPathState.level;
    if (!setTargetLanguage(languageSelect.value, { level })) {
      languageSelect.value = learningPathState.language;
    }
  });
  levelSelect?.addEventListener('change', () => {
    const language = languageSelect?.value || learningPathState.language;
    const level = levelSelect.value;
    loadLearningPath({ language, level });
    savePreferences(language, level);
  });
  bridgeSelect?.addEventListener('change', () => {
    setBridgeLanguage(bridgeSelect.value);
  });
  document
    .getElementById('pathSwapLanguagesBtn')
    ?.addEventListener('click', () => swapLearningPathLanguages());
  document.getElementById('pathStartLearningBtn')?.addEventListener('click', async () => {
    const language = languageSelect?.value || learningPathState.language;
    const level = levelSelect?.value || learningPathState.level;
    await loadLearningPath({ language, level });
    savePreferences(language, level);
    if (getViewFromHash() !== 'learn') {
      history.pushState(null, '', '#learn');
      showView('learn');
    }
    updateLearnHash('learn');
    document.getElementById('learning-path')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    document.querySelector('#learning-path h2')?.focus({ preventScroll: true });
  });
  updateStartLearningButton();
  updateLanguagePreviewSelection();
}

function initScrollReveal() {
  const elements = document.querySelectorAll(
    '.section-heading, .features-grid article, .plan, .missions-panel, .badges-panel, .goal-card, .download-box, .course-card, .how-it-works-step'
  );
  if (!elements.length) return;

  if (!('IntersectionObserver' in window)) {
    elements.forEach((el) => el.classList.add('is-visible'));
    return;
  }

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      });
    },
    { threshold: 0.15, rootMargin: '0px 0px -60px 0px' }
  );

  elements.forEach((el, index) => {
    el.classList.add('reveal-on-scroll');
    el.style.transitionDelay = `${(index % 4) * 60}ms`;
    observer.observe(el);
  });
}

// ---------------------------------------------------------------------
// Translator (#translator) - English/French/Spanish only, matching the rest
// of the public frontend. Always calls POST /api/translator (never Azure
// directly - see lib/translatorService.js); when that route reports
// configured:false this shows the pending-configuration message instead of
// ever fabricating a translation.
// Local-only translation history (never sent anywhere) - last
// TRANSLATOR_HISTORY_LIMIT entries, most recent first. Kept as a plain
// localStorage array rather than anything server-side, matching "historial
// local opcional" - it's a convenience for the student's own browser, not
// account data.
const TRANSLATOR_HISTORY_KEY = 'andergo_translator_history';
const TRANSLATOR_HISTORY_LIMIT = 20;

function loadTranslatorHistory() {
  try {
    const raw = localStorage.getItem(TRANSLATOR_HISTORY_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function saveTranslatorHistoryEntry(entry) {
  try {
    const history = [entry, ...loadTranslatorHistory()].slice(0, TRANSLATOR_HISTORY_LIMIT);
    localStorage.setItem(TRANSLATOR_HISTORY_KEY, JSON.stringify(history));
    return history;
  } catch {
    return loadTranslatorHistory();
  }
}

function clearTranslatorHistory() {
  try {
    localStorage.removeItem(TRANSLATOR_HISTORY_KEY);
  } catch {
    /* ignore - private browsing / storage disabled */
  }
}

// Prefills the Traductor's own source/target selects from the platform's
// current bridge/target pair the first time the student lands on #translator
// in a given session - see translatorUserAdjustedPair's comment for why this
// stops once the student has picked a pair inside the Traductor itself.
// bridge->target (not the other way) matches the rest of the app's "Puente
// -> Objetivo" framing: translate what I want to say FROM my own language
// INTO the one I'm learning.
function syncTranslatorLanguagesFromState() {
  if (translatorUserAdjustedPair) return;
  const sourceSelect = document.getElementById('translatorSourceLang');
  const targetSelect = document.getElementById('translatorTargetLang');
  if (!sourceSelect || !targetSelect) return;
  const bridge = learningPathState.bridgeLanguage;
  const target = learningPathState.language;
  if ([...sourceSelect.options].some((opt) => opt.value === bridge)) sourceSelect.value = bridge;
  if ([...targetSelect.options].some((opt) => opt.value === target)) targetSelect.value = target;
}

// Opens the Traductor pre-filled with context from another view (Reading/
// Grammar/Vocabulary/Speaking's "Traducir" shortcuts) - the sibling of
// openTutorDrawer() for the Traductor. Defaults to translating FROM the
// target language INTO the bridge language (the "explain this to me"
// direction those shortcuts need), overridable via overrides.sourceLanguage/
// targetLanguage. overrides.returnHash/returnLabel wire up
// #translatorReturnLink so the student can get back to exactly where they
// were instead of hunting through the nav.
function openTranslator(overrides = {}) {
  const sourceSelect = document.getElementById('translatorSourceLang');
  const targetSelect = document.getElementById('translatorTargetLang');
  const input = document.getElementById('translatorInput');
  const returnLink = document.getElementById('translatorReturnLink');

  const sourceLang = overrides.sourceLanguage || learningPathState.language;
  const targetLang = overrides.targetLanguage || learningPathState.bridgeLanguage;
  if (sourceSelect && [...sourceSelect.options].some((opt) => opt.value === sourceLang)) {
    sourceSelect.value = sourceLang;
  }
  if (targetSelect && [...targetSelect.options].some((opt) => opt.value === targetLang)) {
    targetSelect.value = targetLang;
  }
  // An explicit shortcut always wins over the generic sync for the rest of
  // this session - the student (or the lesson view on their behalf) just
  // chose this pair on purpose.
  translatorUserAdjustedPair = true;

  if (input && overrides.text) {
    const maxLength = Number(input.getAttribute('maxlength')) || 1000;
    input.value = String(overrides.text).slice(0, maxLength);
    input.dispatchEvent(new Event('input'));
  }

  if (returnLink) {
    if (overrides.returnHash) {
      translatorReturnContext = {
        hash: overrides.returnHash,
        label: overrides.returnLabel || 'Volver a la lección'
      };
      returnLink.textContent = `‹ ${translatorReturnContext.label}`;
      returnLink.hidden = false;
    } else {
      translatorReturnContext = null;
      returnLink.hidden = true;
    }
  }

  if (window.location.hash !== '#translator') history.pushState(null, '', '#translator');
  showView('translator');
}

// Builds the Traductor's source/target <option> lists from the central
// src/js/translator-languages.js list instead of two hand-duplicated
// <option> blocks in index.html (Fase 1 spec: "sustituye la lista rígida
// por una lista central de idiomas admitidos"). Only DeepL-supported
// languages appear - Haitian Creole/Hawaiian stay out of the selector
// entirely until a compatible provider exists (spec item 7, "fuera del
// selector" option). Idempotent (only (re)populates when empty), same
// pattern as verbs-view.js's ensureConjugatorSelectOptions - safe to call
// every time setupTranslator() runs without disturbing a live selection.
function populateTranslatorLanguageSelects() {
  const sourceSelect = document.getElementById('translatorSourceLang');
  const targetSelect = document.getElementById('translatorTargetLang');
  const languages = window.AndergoTranslatorLanguages?.getSelectableLanguages() || [];
  if (!languages.length) return;

  const optionHtml = (lang) => `<option value="${escapeHtml(lang.key)}">${lang.flag} ${escapeHtml(lang.label)}</option>`;

  if (sourceSelect && sourceSelect.options.length <= 1) {
    sourceSelect.innerHTML =
      '<option value="auto">Detectar idioma</option>' + languages.map(optionHtml).join('');
    sourceSelect.value = 'auto';
  }
  if (targetSelect && !targetSelect.options.length) {
    targetSelect.innerHTML = languages.map(optionHtml).join('');
    // 'spanish' matches the Traductor's long-standing default target
    // (English/French bridge students translating into Spanish) - falls
    // back to the first selectable language if that ever changes.
    targetSelect.value = languages.some((lang) => lang.key === 'spanish') ? 'spanish' : languages[0].key;
  }
}

function setupTranslator() {
  populateTranslatorLanguageSelects();
  const sourceSelect = document.getElementById('translatorSourceLang');
  const targetSelect = document.getElementById('translatorTargetLang');
  const swapBtn = document.getElementById('translatorSwapBtn');
  const input = document.getElementById('translatorInput');
  const output = document.getElementById('translatorOutput');
  const charCount = document.getElementById('translatorCharCount');
  const clearBtn = document.getElementById('translatorClearBtn');
  const copyBtn = document.getElementById('translatorCopyBtn');
  const listenSourceBtn = document.getElementById('translatorListenSourceBtn');
  const listenOutputBtn = document.getElementById('translatorListenOutputBtn');
  const submitBtn = document.getElementById('translatorSubmitBtn');
  const status = document.getElementById('translatorStatus');
  const detectedEl = document.getElementById('translatorDetected');
  const historyList = document.getElementById('translatorHistoryList');
  const historyClearBtn = document.getElementById('translatorHistoryClearBtn');
  const suggestionsList = document.getElementById('translatorSuggestions');
  const suggestionsToggle = document.getElementById('translatorSuggestionsToggle');
  if (!input || !output || !submitBtn || !status) return;

  const MAX_LENGTH = Number(input.getAttribute('maxlength')) || 1000;

  const setStatus = (text, mode) => {
    status.textContent = text;
    status.classList.remove('is-loading', 'is-success', 'is-unavailable');
    if (mode) status.classList.add(mode);
  };

  const updateCharCount = () => {
    if (charCount) charCount.textContent = `${input.value.length} / ${MAX_LENGTH}`;
  };

  const renderHistory = () => {
    if (!historyList) return;
    const history = loadTranslatorHistory();
    historyList.innerHTML = history.length
      ? history
          .map(
            (entry) => `
        <li class="translator-history-item">
          <span class="translator-history-pair">${escapeHtml(languageDisplayNames[entry.sourceLanguage] || entry.sourceLanguage || 'Auto')} → ${escapeHtml(languageDisplayNames[entry.targetLanguage] || entry.targetLanguage || '')}</span>
          <span class="translator-history-source">${escapeHtml(entry.source)}</span>
          <span class="translator-history-target">${escapeHtml(entry.target)}</span>
        </li>`
          )
          .join('')
      : '<li class="translator-history-empty">Sin traducciones recientes.</li>';
  };

  // ---------------------------------------------------------------------
  // Predictive text (Fase 4) - English/Spanish/French only, purely local
  // (src/js/translator-predictive.js: a curated word list + a handful of
  // common two-word sequences, never DeepL, never an AI call per
  // keystroke). Distinguishes three suggestion kinds via each item's
  // `type` (autocompletado/corrección ortográfica/predicción contextual -
  // see that module's getSuggestions()); tagged in the DOM
  // (data-type) so CSS can render them distinctly.
  // ---------------------------------------------------------------------
  const PREDICTIVE_ENABLED_KEY = 'andergo_translator_predictive_enabled';
  const PREDICTIVE_LANGUAGES = new Set(['english', 'spanish', 'french']);
  const SUGGESTIONS_DEBOUNCE_MS = 200;

  let suggestionItems = [];
  let activeSuggestionIndex = -1;
  let suggestionsDebounceId = null;

  function isPredictiveEnabled() {
    try {
      return localStorage.getItem(PREDICTIVE_ENABLED_KEY) !== 'false';
    } catch {
      return true;
    }
  }

  function renderSuggestions(items) {
    suggestionItems = items;
    activeSuggestionIndex = -1;
    if (!suggestionsList) return;
    if (!items.length) {
      suggestionsList.hidden = true;
      suggestionsList.innerHTML = '';
      input.setAttribute('aria-expanded', 'false');
      return;
    }
    // Small visual tag per suggestion kind - autocompletado has none (the
    // default/expected case), corrección ortográfica gets ✎, predicción
    // contextual gets →, so the three stay visually distinct as required.
    const typeGlyph = { spelling: '✎ ', contextual: '→ ' };
    suggestionsList.innerHTML = items
      .map(
        (item, index) => `
        <li class="translator-suggestion-item" data-index="${index}" data-type="${escapeHtml(item.type)}" role="option" aria-selected="false">${typeGlyph[item.type] || ''}${escapeHtml(item.text)}</li>`
      )
      .join('');
    suggestionsList.hidden = false;
    input.setAttribute('aria-expanded', 'true');
  }

  function hideSuggestions() {
    renderSuggestions([]);
  }

  function updateSuggestionHighlight() {
    if (!suggestionsList) return;
    suggestionsList.querySelectorAll('.translator-suggestion-item').forEach((el, index) => {
      const active = index === activeSuggestionIndex;
      el.classList.toggle('is-active', active);
      el.setAttribute('aria-selected', String(active));
    });
  }

  // Replaces only the word currently being typed (or, for a contextual
  // suggestion, inserts the next word right after the caret) - never
  // touches the rest of the text, and always leaves a trailing space so
  // the student can keep typing immediately.
  function acceptSuggestion(index) {
    const item = suggestionItems[index];
    if (!item) return;
    const caret = input.selectionStart ?? input.value.length;
    const before = input.value.slice(0, caret);
    const after = input.value.slice(caret);
    const wordMatch = /(\S*)$/.exec(before);
    const wordStart = caret - (wordMatch ? wordMatch[1].length : 0);
    const newBefore = `${before.slice(0, wordStart)}${item.text} `;
    input.value = newBefore + after;
    const newCaret = newBefore.length;
    input.setSelectionRange(newCaret, newCaret);
    hideSuggestions();
    input.dispatchEvent(new Event('input'));
    input.focus();
  }

  function scheduleSuggestions() {
    window.clearTimeout(suggestionsDebounceId);
    if (!isPredictiveEnabled()) {
      hideSuggestions();
      return;
    }
    const language = sourceSelect?.value;
    const engine = window.AndergoTranslatorPredictive;
    if (!engine || !language || !PREDICTIVE_LANGUAGES.has(language)) {
      hideSuggestions();
      return;
    }
    suggestionsDebounceId = window.setTimeout(() => {
      const caret = input.selectionStart ?? input.value.length;
      renderSuggestions(engine.getSuggestions(language, input.value.slice(0, caret)));
    }, SUGGESTIONS_DEBOUNCE_MS);
  }

  input.addEventListener('input', scheduleSuggestions);
  // A short delay (not an immediate hide) lets a mousedown on a suggestion
  // (see the delegated listener below, which itself preventDefault()s the
  // mousedown so focus never actually leaves the textarea) register before
  // any blur-driven hide could beat it to it.
  input.addEventListener('blur', () => {
    window.setTimeout(hideSuggestions, 100);
  });

  suggestionsList?.addEventListener('mousedown', (event) => {
    const item = event.target.closest('.translator-suggestion-item');
    if (!item) return;
    event.preventDefault(); // keep focus (and the caret) in the textarea
    acceptSuggestion(Number(item.dataset.index));
  });

  if (suggestionsToggle) {
    suggestionsToggle.checked = isPredictiveEnabled();
    suggestionsToggle.addEventListener('change', () => {
      try {
        localStorage.setItem(PREDICTIVE_ENABLED_KEY, String(suggestionsToggle.checked));
      } catch {
        // Storage unavailable - the toggle still works for this session,
        // it just won't be remembered next visit.
      }
      if (!suggestionsToggle.checked) hideSuggestions();
    });
  }

  input.addEventListener('input', updateCharCount);
  updateCharCount();
  renderHistory();

  // "Textos muy cortos" (Fase 2 spec): DeepL's own auto-detection is far
  // less reliable on a couple of words than on a full sentence - never
  // trust it blindly. Below this rough word-count threshold, the
  // detected-language line adds an explicit caution; either way, whenever
  // sourceLanguage was 'auto' this also renders a one-click way to pick the
  // real language and retranslate with it ("permitir corregirlo antes de
  // volver a traducir") instead of only ever showing the guess as plain
  // text.
  const SHORT_TEXT_WORD_THRESHOLD = 3;

  function renderTranslatorDetectedLanguage(detectedKey, originalText) {
    if (!detectedEl) return;
    const languages = window.AndergoTranslatorLanguages?.getSelectableLanguages() || [];
    const label = languageDisplayNames[detectedKey] || detectedKey;
    const wordCount = originalText.trim().split(/\s+/).filter(Boolean).length;
    const isShortText = wordCount > 0 && wordCount <= SHORT_TEXT_WORD_THRESHOLD;

    const cautionHtml = isShortText
      ? '<span class="translator-detected-caution">Los textos muy cortos pueden confundir la detección automática.</span> '
      : '';

    const optionsHtml = languages
      .map(
        (lang) =>
          `<option value="${escapeHtml(lang.key)}"${lang.key === detectedKey ? ' selected' : ''}>${lang.flag} ${escapeHtml(lang.label)}</option>`
      )
      .join('');

    detectedEl.innerHTML = `
      ${cautionHtml}<span>Idioma detectado: <strong>${escapeHtml(label)}</strong></span>
      <span class="translator-detected-correct">
        <label for="translatorDetectedCorrectSelect">¿No es correcto?</label>
        <select id="translatorDetectedCorrectSelect">${optionsHtml}</select>
        <button type="button" class="secondary-btn" id="translatorDetectedCorrectBtn">Volver a traducir</button>
      </span>`;
    detectedEl.hidden = false;
  }

  // Delegated (detectedEl's own innerHTML is rebuilt on every detection, so
  // a listener bound directly to the button would be orphaned each time).
  detectedEl?.addEventListener('click', (event) => {
    if (!event.target.closest('#translatorDetectedCorrectBtn')) return;
    const correctSelect = document.getElementById('translatorDetectedCorrectSelect');
    const chosen = correctSelect?.value;
    if (!chosen || !sourceSelect) return;
    // The student just told us the real source language - use it explicitly
    // from now on instead of leaving 'auto' to guess wrong again.
    sourceSelect.value = chosen;
    translatorUserAdjustedPair = true;
    runTranslation();
  });

  // recognition.lang is fixed for the life of a SpeechRecognition instance -
  // a source-language switch mid-dictation would otherwise keep listening
  // in the old language. Any manual change here also opts this session out
  // of syncTranslatorLanguagesFromState()'s auto-sync (see its comment) -
  // the student picked this pair on purpose.
  sourceSelect?.addEventListener('change', () => {
    stopTranslatorDictation();
    translatorUserAdjustedPair = true;
    // Suggestions are language-specific and tied to whatever was typed
    // under the old language - stale once the source changes; a fresh set
    // (if any) is computed on the next keystroke.
    hideSuggestions();
  });
  targetSelect?.addEventListener('change', () => {
    translatorUserAdjustedPair = true;
  });

  const returnLink = document.getElementById('translatorReturnLink');
  returnLink?.addEventListener('click', (event) => {
    event.preventDefault();
    if (!translatorReturnContext) return;
    const hash = translatorReturnContext.hash;
    translatorReturnContext = null;
    returnLink.hidden = true;
    if (window.location.hash !== hash) history.pushState(null, '', hash);
    showView(getViewFromHash());
  });

  swapBtn?.addEventListener('click', () => {
    stopTranslatorDictation();
    hideSuggestions();
    // Swapping the selects only makes sense when the source is a real
    // language - with 'auto' there is nothing known to place in the target
    // slot, so leave both selects as-is and just swap the text either way.
    if (sourceSelect.value !== 'auto' && targetSelect) {
      const sourceValue = sourceSelect.value;
      sourceSelect.value = targetSelect.value;
      targetSelect.value = sourceValue;
    }
    const inputValue = input.value;
    input.value = output.value;
    output.value = inputValue;
    updateCharCount();
  });

  clearBtn?.addEventListener('click', () => {
    // Otherwise the next dictation 'result' event would overwrite the
    // clear with the baseText captured when dictation started.
    stopTranslatorDictation();
    hideSuggestions();
    input.value = '';
    output.value = '';
    if (detectedEl) detectedEl.hidden = true;
    updateCharCount();
    setStatus('Listo');
  });

  copyBtn?.addEventListener('click', async () => {
    if (!output.value) return;
    try {
      await navigator.clipboard.writeText(output.value);
      showHomeToast('Traducción copiada.');
    } catch {
      showHomeToast('No se pudo copiar la traducción.');
    }
  });

  listenSourceBtn?.addEventListener('click', () => {
    const lang = sourceSelect?.value;
    speakText(input.value, { locale: lang && lang !== 'auto' ? LANGUAGE_LOCALES[lang] : undefined });
  });

  listenOutputBtn?.addEventListener('click', () => {
    speakText(output.value, { locale: LANGUAGE_LOCALES[targetSelect?.value] });
  });

  historyClearBtn?.addEventListener('click', () => {
    clearTranslatorHistory();
    renderHistory();
  });

  // Shared by the Traducir button, Enter-to-translate, and the ~2s
  // auto-translate after voice dictation (startTranslatorDictation) - one
  // place decides "can we translate right now", so none of those three
  // entry points can double-submit or send empty content.
  async function runTranslation() {
    if (submitBtn.disabled) return; // already in flight - never a second request
    hideSuggestions();

    // Manual translate (Enter or the Traducir button) while the mic is
    // still listening: grabs whatever's in the textarea right now (already
    // live-updated with interim results) and stops the recognizer, marking
    // its 'end' handler to skip its own auto-translate so this one is never
    // duplicated.
    if (translatorDictation.status === 'listening') {
      translatorDictationManualSendSuppressed = true;
      stopTranslatorDictationRecognizer();
    }

    // A stale dictation message (e.g. "No se entendió el audio.") from an
    // earlier voice attempt must never linger once the student translates
    // by any means (typing + Enter/Traducir included) - it reads as if the
    // translation that just succeeded had failed.
    setTranslatorDictateStatusText('');

    const text = input.value.trim();
    if (!text) {
      setStatus('Escribe un texto para traducir.', 'is-unavailable');
      return;
    }

    const sourceLanguage = sourceSelect?.value || 'auto';
    const targetLanguage = targetSelect?.value || 'spanish';
    // Mirrors the backend's own check (POST /api/translate rejects this the
    // same way) - checked here too so guessing/typing doesn't need a round
    // trip to find out. 'auto' is never blocked - the real detected
    // language isn't known until DeepL responds.
    if (sourceLanguage !== 'auto' && sourceLanguage === targetLanguage) {
      setStatus(LanguagePair.t('translatorSelectDifferent', learningPathState.bridgeLanguage), 'is-unavailable');
      return;
    }

    if (detectedEl) detectedEl.hidden = true;
    setStatus(LanguagePair.t('translatorTranslating', learningPathState.bridgeLanguage), 'is-loading');
    submitBtn.disabled = true;
    try {
      // auth: true - sends the session token when signed in, so the backend
      // can apply the Premium character limit instead of always treating
      // the request as a guest (see POST /api/translate's attachUserIfPresent).
      const data = await postJson(
        '/api/translate',
        { text, sourceLanguage, targetLanguage },
        { auth: true }
      );

      if (data.ok) {
        output.value = data.translatedText || '';
        setStatus('Completada', 'is-success');
        if (sourceLanguage === 'auto' && data.detectedLanguage) {
          renderTranslatorDetectedLanguage(data.detectedLanguage, text);
        }
        saveTranslatorHistoryEntry({
          source: text,
          target: output.value,
          sourceLanguage: sourceLanguage === 'auto' ? data.detectedLanguage || 'auto' : sourceLanguage,
          targetLanguage,
          timestamp: Date.now()
        });
        renderHistory();
        // Only when this translation was itself triggered by speaking (see
        // startTranslatorDictation's 'end' handler) - a manual Enter/Traducir
        // translation never auto-plays, only the voice path does.
        if (translatorAutoPlayAfterVoice && output.value) {
          speakText(output.value, { locale: LANGUAGE_LOCALES[targetLanguage] });
        }
      } else if (data.configured === false) {
        output.value = '';
        setStatus('El traductor está temporalmente en configuración.', 'is-unavailable');
      } else {
        output.value = '';
        setStatus(data.message || 'No disponible. Inténtalo de nuevo.', 'is-unavailable');
      }
    } catch (error) {
      output.value = '';
      setStatus(error.message || 'No disponible. Inténtalo de nuevo.', 'is-unavailable');
    } finally {
      translatorAutoPlayAfterVoice = false;
      submitBtn.disabled = false;
    }
  }

  submitBtn.addEventListener('click', runTranslation);

  // Enter translates immediately; Shift+Enter inserts a newline (the
  // textarea's own default behavior, so it's left alone). No separate
  // "double submit" guard needed here beyond runTranslation's own
  // submitBtn.disabled check - a held-down Enter key or a click landing
  // mid-request both just no-op against an already-disabled button.
  //
  // Fase 4 adds three things ahead of that: Up/Down move the highlighted
  // suggestion, Escape closes the list without touching the text, and
  // Enter accepts the highlighted suggestion INSTEAD of translating - only
  // when one is actually highlighted; otherwise Enter still translates,
  // exactly as before.
  input.addEventListener('keydown', (event) => {
    if (suggestionItems.length && (event.key === 'ArrowDown' || event.key === 'ArrowUp')) {
      event.preventDefault();
      if (event.key === 'ArrowDown') {
        activeSuggestionIndex = (activeSuggestionIndex + 1) % suggestionItems.length;
      } else {
        activeSuggestionIndex = (activeSuggestionIndex - 1 + suggestionItems.length) % suggestionItems.length;
      }
      updateSuggestionHighlight();
      return;
    }
    if (suggestionItems.length && event.key === 'Escape') {
      event.preventDefault();
      hideSuggestions();
      return;
    }
    if (event.key === 'Enter' && !event.shiftKey && suggestionItems.length && activeSuggestionIndex >= 0) {
      event.preventDefault();
      acceptSuggestion(activeSuggestionIndex);
      return;
    }

    if (event.key !== 'Enter' || event.shiftKey) return;
    event.preventDefault();
    runTranslation();
  });

  translateTranslatorInputNow = runTranslation;
}

// ---------------------------------------------------------------------
// Corrector (#translator's "Corrector" tab, Fase 3) - a distinct mode from
// the Traductor above, never a target language: it fixes grammar/spelling
// in the SAME language the student wrote in and never translates (POST
// /api/correct-text, the AI Tutor cascade - never DeepL). English/Spanish/
// French only, per spec. Shares the .skill-tabs markup/behavior with Verbos
// and Tutor (activateSkillTab/initSkillTabsAccessibility), so switching
// tabs here needs no extra wiring beyond this function's own controls.
// ---------------------------------------------------------------------
function renderCorrectorHighlighted(correctedText, changes) {
  if (!Array.isArray(changes) || !changes.length) return escapeHtml(correctedText);

  // Wraps each changed fragment in <mark> without corrupting HTML-escaping:
  // a placeholder token (a Private-Use-Area marker, never in real text) is
  // inserted into the RAW text first, the whole string is escaped once,
  // then each token is swapped for its escaped, <mark>-wrapped fragment.
  const MARKER = String.fromCharCode(0xe000); // Private Use Area - never in real text
  let working = correctedText;
  const placeholders = [];
  changes.forEach((change, index) => {
    if (!change.corrected) return;
    const idx = working.indexOf(change.corrected);
    if (idx === -1) return;
    const token = `${MARKER}${index}${MARKER}`;
    working = working.slice(0, idx) + token + working.slice(idx + change.corrected.length);
    placeholders.push({ token, text: change.corrected });
  });

  let escaped = escapeHtml(working);
  placeholders.forEach(({ token, text }) => {
    escaped = escaped.split(token).join(`<mark>${escapeHtml(text)}</mark>`);
  });
  return escaped;
}

function setupCorrector() {
  const langSelect = document.getElementById('correctorLangSelect');
  const input = document.getElementById('correctorInput');
  const output = document.getElementById('correctorOutput');
  const charCount = document.getElementById('correctorCharCount');
  const clearBtn = document.getElementById('correctorClearBtn');
  const copyBtn = document.getElementById('correctorCopyBtn');
  const listenBtn = document.getElementById('correctorListenBtn');
  const applyBtn = document.getElementById('correctorApplyBtn');
  const submitBtn = document.getElementById('correctorSubmitBtn');
  const status = document.getElementById('correctorStatus');
  if (!input || !output || !submitBtn || !status) return;

  const MAX_LENGTH = Number(input.getAttribute('maxlength')) || 1000;
  let lastCorrection = null; // { correctedText, explanation, changes } from the last successful call

  const setStatus = (text, mode) => {
    status.textContent = text;
    status.classList.remove('is-loading', 'is-success', 'is-unavailable');
    if (mode) status.classList.add(mode);
  };

  const updateCharCount = () => {
    if (charCount) charCount.textContent = `${input.value.length} / ${MAX_LENGTH}`;
  };

  const setResultActionsEnabled = (enabled) => {
    if (copyBtn) copyBtn.disabled = !enabled;
    if (listenBtn) listenBtn.disabled = !enabled;
    if (applyBtn) applyBtn.disabled = !enabled;
  };

  const resetOutput = () => {
    output.innerHTML = '<p class="skill-graph-empty">La corrección aparecerá aquí.</p>';
    lastCorrection = null;
    setResultActionsEnabled(false);
  };

  input.addEventListener('input', updateCharCount);
  updateCharCount();

  // A new language or a freshly-edited text invalidates whatever correction
  // is currently shown - never let a stale "Aplicar corrección"/"Escuchar"
  // apply text from a previous language or a previous version of the input.
  langSelect?.addEventListener('change', resetOutput);
  input.addEventListener('input', () => {
    if (lastCorrection) resetOutput();
  });

  async function runCorrection() {
    if (submitBtn.disabled) return; // already in flight - never a second request

    const text = input.value.trim();
    if (!text) {
      setStatus('Escribe un texto para corregir.', 'is-unavailable');
      return;
    }

    const language = langSelect?.value || 'english';
    setStatus('Corrigiendo…', 'is-loading');
    submitBtn.disabled = true;
    try {
      // auth: true, same as the Traductor's own call - lets the backend
      // apply Premium limits instead of always treating the request as a
      // guest (see POST /api/correct-text's attachUserIfPresent).
      const data = await postJson('/api/correct-text', { text, language }, { auth: true });

      if (data.ok) {
        lastCorrection = {
          originalText: text,
          correctedText: data.correctedText || '',
          explanation: data.explanation || '',
          changes: data.changes || []
        };
        output.innerHTML = `
          <div class="corrector-original">
            <span class="corrector-result-label">Original</span>
            <p>${escapeHtml(text)}</p>
          </div>
          <div class="corrector-corrected">
            <span class="corrector-result-label">Corrección</span>
            <p>${renderCorrectorHighlighted(lastCorrection.correctedText, lastCorrection.changes)}</p>
          </div>
          ${lastCorrection.explanation ? `<p class="corrector-explanation">${escapeHtml(lastCorrection.explanation)}</p>` : ''}
        `;
        setResultActionsEnabled(true);
        setStatus('Completada', 'is-success');
      } else if (data.configured === false) {
        resetOutput();
        setStatus('El corrector está temporalmente en configuración.', 'is-unavailable');
      } else {
        resetOutput();
        setStatus(data.message || 'No disponible. Inténtalo de nuevo.', 'is-unavailable');
      }
    } catch (error) {
      resetOutput();
      setStatus(error.message || 'No disponible. Inténtalo de nuevo.', 'is-unavailable');
    } finally {
      submitBtn.disabled = false;
    }
  }

  submitBtn.addEventListener('click', runCorrection);

  clearBtn?.addEventListener('click', () => {
    input.value = '';
    updateCharCount();
    resetOutput();
    setStatus('Listo');
  });

  copyBtn?.addEventListener('click', async () => {
    if (!lastCorrection?.correctedText) return;
    try {
      await navigator.clipboard.writeText(lastCorrection.correctedText);
      showHomeToast('Corrección copiada.');
    } catch {
      showHomeToast('No se pudo copiar la corrección.');
    }
  });

  listenBtn?.addEventListener('click', () => {
    if (!lastCorrection?.correctedText) return;
    speakText(lastCorrection.correctedText, { locale: LANGUAGE_LOCALES[langSelect?.value] });
  });

  // "Aplicar corrección": replaces the student's own draft with the
  // corrected version, same direct-field-mutation pattern the Traductor's
  // own swap button already uses - lets the student keep editing or
  // re-submit from the corrected text.
  applyBtn?.addEventListener('click', () => {
    if (!lastCorrection?.correctedText) return;
    input.value = lastCorrection.correctedText;
    updateCharCount();
    resetOutput();
    setStatus('Corrección aplicada. Puedes seguir editando.', 'is-success');
  });
}

function initHeroCopyCarousel() {
  const carousel = document.querySelector('.hero-copy-carousel');
  if (!carousel) return;

  const slides = [...carousel.querySelectorAll('[data-hero-slide]')];
  const controls = [...carousel.querySelectorAll('[data-hero-carousel]')];
  if (slides.length < 2) return;

  let activeIndex = slides.findIndex((slide) => slide.classList.contains('is-active'));
  activeIndex = activeIndex < 0 ? 0 : activeIndex;
  let rotationId = null;

  const activateSlide = (nextIndex) => {
    activeIndex = (nextIndex + slides.length) % slides.length;
    slides.forEach((slide, index) => {
      const isActive = index === activeIndex;
      slide.classList.toggle('is-active', isActive);
      slide.setAttribute('aria-hidden', String(!isActive));
    });
    controls.forEach((control) => {
      const target = Number(control.dataset.heroCarousel);
      if (Number.isNaN(target)) return;
      const isActive = target === activeIndex;
      control.classList.toggle('is-active', isActive);
      control.setAttribute('aria-selected', String(isActive));
    });
  };

  const stopRotation = () => {
    if (rotationId) window.clearInterval(rotationId);
    rotationId = null;
  };
  const startRotation = () => {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    stopRotation();
    rotationId = window.setInterval(() => activateSlide(activeIndex + 1), 6500);
  };

  controls.forEach((control) => {
    control.addEventListener('click', () => {
      const action = control.dataset.heroCarousel;
      if (action === 'previous') activateSlide(activeIndex - 1);
      else if (action === 'next') activateSlide(activeIndex + 1);
      else activateSlide(Number(action));
      startRotation();
    });
  });

  carousel.addEventListener('mouseenter', stopRotation);
  carousel.addEventListener('mouseleave', startRotation);
  carousel.addEventListener('focusin', stopRotation);
  carousel.addEventListener('focusout', (event) => {
    if (!carousel.contains(event.relatedTarget)) startRotation();
  });
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) stopRotation();
    else startRotation();
  });
  startRotation();
}

document.addEventListener('change', (event) => {
  const fontSelect = event.target.closest?.('.reading-font-select');
  if (!fontSelect) return;
  const area = fontSelect.closest('.reading-print-area');
  const preferences = getReadingDisplayPreferences();
  preferences.font = fontSelect.value === 'times' ? 'times' : 'arial';
  applyReadingDisplayPreferences(area, preferences);
  setReadingDisplayPreferences(preferences);
});

enableHomepageActions();
initHeroCopyCarousel();
loadProgress();
setupLearningPathControls();
setupTranslator();
setupCorrector();
setupReadingSelectionTranslator();
initScrollReveal();

// Reached only via the link Supabase emails (authService's
// PASSWORD_RESET_REDIRECT_URL = '/?auth=recovery') - it overrides the normal
// hash-based view for this one load, regardless of whatever hash Supabase
// also appended to it. The legacy /reset-password path is also recognized
// for any links sent before that redirect URL changed.
const isPasswordRecoveryLink =
  window.location.pathname === '/reset-password' ||
  new URLSearchParams(window.location.search).get('auth') === 'recovery';

// Reached via the confirmation-LINK variant of Supabase's "Confirm signup"
// email (authService's EMAIL_CONFIRM_REDIRECT_URL = '/?auth=confirmed') -
// the 6-digit OTP in showSignupPending() is still the primary confirmation
// path; this only covers an account confirming via the email's link instead.
// Supabase's own error redirect (expired/already-used link) still lands here
// with `auth=confirmed` intact plus `error`/`error_code`/`error_description`
// appended - it redirects to the full redirect_to it was given, not a
// stripped-down version of it - so this one check already covers both the
// success and error cases; initEmailConfirmedPage() branches on the error
// params once it's here.
const isEmailConfirmedLink = new URLSearchParams(window.location.search).get('auth') === 'confirmed';

if (isPasswordRecoveryLink) {
  showView('reset-password');
  initResetPasswordPage();
} else if (isEmailConfirmedLink) {
  showView('email-confirmed');
  initEmailConfirmedPage();
} else {
  showView(getViewFromHash());
  // Direct/bookmarked load of #premium: resolves to the home view (see
  // getViewFromHash), so land on the plans section instead of the hero.
  if (window.location.hash === '#premium') {
    window.setTimeout(() => {
      document.getElementById('premium')?.scrollIntoView({ behavior: 'auto', block: 'start' });
    }, 50);
  }
}

// Checked once at load, not only on click - "oculta o desactiva el botón"
// applies from the start on browsers without the Web Speech API, not just
// after a failed attempt.
if (!getSpeechRecognitionCtor()) {
  document.querySelectorAll('.tutor-dictate-btn').forEach((btn) => {
    btn.disabled = true;
    setDictationStatusText(
      btn.dataset.dictateTarget,
      'El dictado por voz no está disponible en este navegador. Puedes escribir tu mensaje.'
    );
  });
  document.querySelectorAll('.tutor-dictate-stop-btn').forEach((btn) => {
    btn.hidden = true;
  });
  document.querySelectorAll('.translator-dictate-btn').forEach((btn) => {
    btn.disabled = true;
  });
  setTranslatorDictateStatusText(
    'El dictado por voz no está disponible en este navegador. Puedes escribir tu texto.'
  );
  document.querySelectorAll('.translator-dictate-stop-btn').forEach((btn) => {
    btn.hidden = true;
  });
}

document.querySelectorAll('.nav-group a[data-scroll-target]').forEach((link) => {
  link.addEventListener('click', () => {
    const targetId = link.dataset.scrollTarget;
    window.setTimeout(() => {
      document.getElementById(targetId)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 50);
  });
});

// Waits for the signed-in user's saved language/level (if any) before the
// first render, so the learning path never flashes English A1 and then
// jumps to the real preference a moment later.
(async function bootstrapLearningPath() {
  // A hash carrying /<language>/<level>/... (see parseLearnHashState) wins
  // over the account's saved preferences on load - a reloaded or shared
  // #reading/french/A1/... link should open exactly that, not silently
  // revert to whatever language/level the account had saved.
  const hashState = parseLearnHashState();
  const preferences = await loadPreferences();
  // Guests (loadPreferences() is Supabase-only - see its own comment above -
  // and returns null without a session) have no account to restore from:
  // fall back to the localStorage mirror savePreferences() keeps updated on
  // every change, so a signed-out visitor's L1/L2/level choice survives a
  // reload too, the same guarantee signed-in students get from Supabase.
  const localPair = preferences ? null : getSavedLanguagePairLocally();
  const effectivePreferences =
    hashState.language || hashState.level
      ? {
          language:
            hashState.language || preferences?.language || localPair?.language || learningPathState.language,
          level: hashState.level || preferences?.level || localPair?.level || learningPathState.level,
          bridgeLanguage: preferences?.bridgeLanguage || localPair?.bridgeLanguage
        }
      : preferences || localPair;
  applyPreferencesToSelects(effectivePreferences);
  // Guests (no saved preferences) skip applyPreferencesToSelects' own
  // applyInterfaceLanguage call - run it unconditionally so the interface
  // language is always in sync with learningPathState.bridgeLanguage
  // (default 'spanish') on first paint, not just for signed-in students.
  applyInterfaceLanguage(learningPathState.bridgeLanguage);
  await loadLearningPath({
    ...(effectivePreferences || {}),
    restoreUnitId: hashState.unitId,
    restoreSlug: hashState.lessonSlug
  });
  updatePathPairPreview();
  // renderSkillView's own loading-guard branch (see above) already fires an
  // equivalent load if the user landed cold on a skill view (lessons were
  // still empty then) - this re-render is what applies the final restored
  // unit/lesson to that view once this load has actually finished, in case
  // that earlier branch resolved first with an incomplete/default state.
  const resolvedView = getViewFromHash();
  if (SKILL_VIEWS.includes(resolvedView)) renderSkillView(resolvedView);
})();

document.getElementById('aiTutorPrompt')?.addEventListener('keydown', (event) => {
  restartTutorAutoSendIfPending('aiTutorPrompt');
  if (event.key !== 'Enter' || event.shiftKey) return;
  event.preventDefault();
  event.target.closest('.tutor-action')?.querySelector('.tutor-chat-btn')?.click();
});
